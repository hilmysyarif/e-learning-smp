-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 02, 2014 at 07:07 
-- Server version: 5.6.12
-- PHP Version: 5.5.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `rtl_alatpesta`
--
CREATE DATABASE IF NOT EXISTS `rtl_alatpesta` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `rtl_alatpesta`;

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE IF NOT EXISTS `bank` (
  `id_bank` int(11) NOT NULL AUTO_INCREMENT,
  `nama_bank` varchar(10) NOT NULL,
  PRIMARY KEY (`id_bank`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`id_bank`, `nama_bank`) VALUES
(1, 'BRI'),
(2, 'Mandiri');

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE IF NOT EXISTS `barang` (
  `id_barang` bigint(20) NOT NULL AUTO_INCREMENT,
  `nama_barang` varchar(300) NOT NULL,
  `des_barang` text NOT NULL,
  `id_kat_barang` int(11) NOT NULL,
  `stok_total` int(11) NOT NULL,
  `disewa` int(11) NOT NULL,
  `stok_sisa` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `pic_brg` varchar(500) NOT NULL,
  PRIMARY KEY (`id_barang`),
  KEY `id_kat_brg` (`id_kat_barang`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `nama_barang`, `des_barang`, `id_kat_barang`, `stok_total`, `disewa`, `stok_sisa`, `harga`, `pic_brg`) VALUES
(22, 'Kanopi VVIP Putih Marun 4x10 ', 'Ukuran 4 x 10 (m)', 7, 50, 0, 50, 400000, 'Kanopi_VVIP_Putih_Marun.JPG'),
(23, 'Kursi Hotel Cover Pita', 'Kursi Hotel Cover Pita', 8, 10000, 0, 10000, 5000, 'K_Hotel_Cover_Pita_@_10000.JPG'),
(24, 'Meja Ukir', 'Ukiran asli Jepara', 9, 300, 0, 300, 15000, 'meja_ukir.JPG'),
(25, 'Mimbar', 'Mimbar kayu', 8, 10, 0, 10, 15000, 'Mimbar.JPG'),
(26, 'Gong Peresmian', 'Gong untuk acara peresmian', 12, 5, 0, 5, 150000, 'Gong_Peresmian.JPG'),
(28, 'Kursi Sofa Lengkung', 'Kursi Sofa Lengkung\nWarna Coklat', 8, 20, 0, 20, 50000, 'Kursi_Sofa.JPG'),
(29, 'Kursi Ukir', 'Ukiran asli dari Jepara', 8, 20, 0, 20, 15000, 'Kursi_Ukir.JPG'),
(30, 'Kursi VVIP ', 'Warna Biru', 8, 10, 0, 10, 75000, 'Kursi_VVIP.JPG'),
(31, 'Rample Sketing Perlembar', 'Berbagai Warna, dihitung perlembar', 9, 200, 0, 200, 75000, 'Macam_Skreting_meja.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE IF NOT EXISTS `berita` (
  `id_berita` int(11) NOT NULL AUTO_INCREMENT,
  `judul_berita` varchar(200) NOT NULL,
  `tgl_buat` date NOT NULL,
  `tgl_update` date NOT NULL,
  `id_user` bigint(11) NOT NULL,
  `berita` text NOT NULL,
  `id_kat_post` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '1 = posted | 0 = drafted',
  PRIMARY KEY (`id_berita`),
  KEY `id_usr` (`id_user`),
  KEY `id_kat_post` (`id_kat_post`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `berita`
--

INSERT INTO `berita` (`id_berita`, `judul_berita`, `tgl_buat`, `tgl_update`, `id_user`, `berita`, `id_kat_post`, `status`) VALUES
(1, 'Tenda Baru', '2014-02-01', '2014-05-02', 2, '<p style="text-align: justify; line-height: 14px; margin: 0px 0px 14px; padding: 0px; font-family: Arial, Helvetica, sans;">Kami telah menyediakan beberapa tenda baru asli import dari India dengan spesifikasi yang kuat, tahan angin dan api.<br />Warna Beragam, untuk lihat lebih detail silahkan cek di halaman produk.</p>', 2, 1),
(8, 'Tentang Kami', '2014-02-02', '2014-05-02', 2, '<p>Sejarah berdirinya perusahaan WK Group pada tahun 1985 dengan perlengkapan yang masih seadanya, dengan kita hanya membeli 1 kali perlengkapan persewaan maka kita akan mendapatkan keuntungan yang besar dari kita menyewakan tenda. Pada awal tahun 1990-an pendiri sekaligus ayah dari pemilik perusahaan sekarang &ldquo;Agung Prasetyo&rdquo; ingin menyewa tenda untuk khitanan anaknya dengan acara yang cukup besar maka beliau menyewa persewaan tenda lain seharga 3 juta rupiah untuk acara selama 3 hari, dari mahalnya harga tersebut maka orang tua dari saudara Agung Prasetyo berusaha mengembangkan perusahaannya yang masih seadanya.</p>\n<p>Dengan berdirinya perusahaan WK Group maka semakin lengkap lembaga penyewaan dibidang properti di wilayah Yogyakarta. Hal ini diharapkan semakin mampu meningkatkan kualitas sumber daya manusia Indonesia khususnya di wilayah Yogyakarta.&nbsp;</p>\n<p>Perusahaan WK Group secara geografis terletak di jl. Rajawali Raya No.4, Manukan Kidul, Condongcatur, Yogyakarta, sekitar 1 KM kearah utara dari terminal Condongcatur. Perusahaan WK Group ini merupakan salah satu penyewaan properti ternama di wilayah Condongcatur dan sekitarnya.</p>\n<p>&nbsp;</p>', 2, 1),
(10, 'Cara Pemesanan', '2014-02-24', '2014-05-02', 2, '<p>Agar transaksi lancar, silahkan baca petunjuk dibawah ini dengan seksama, agar barang dan transaksi yang dilakukan bisa sesuai dengan prosedur sehingga tidak ada pihak yang merasa disusahkan. Ada beberapa yang bisa anda gunakan untuk bertransaksi sesuai dengan rekening yang anda miliki</p>\n<p><strong>Pemilihan Barang</strong></p>\n<p>Silahkan pilih barang yang ingin anda sewa, untuk kemudian silahkan masuk daftar keranjang untuk memasukan ke halaman tagihan anda (untuk memasukan kehalaman tagihan loginterlebih dahulu)</p>\n<p><strong>Pembayaran</strong></p>\n<p>Setelah data anda masuk di halaman tagihan, seilahkan cek detail untuk melakukan pembayaran Transfer Total biaya sewa ke rekening BCA 0372685831 a/n Rahmad Wijaya&nbsp;</p>\n<p>Setelah transfer SMS ke nomor :&nbsp;<a style="box-sizing: border-box; color: #333333; text-decoration: none; font-family: ubuntu; font-size: 12px; line-height: 17.142858505249023px; background-color: #eeeeee;" href="../../public/home/single/8/tentang-kami">0858 6856060</a>, dengan format :&nbsp;CEK[spasi]id-tagihan[spasi]tanggal transfer[spasi]no rek[spasi]atas nama</p>\n<p>Jika data valid, maka status anda menjadi lunas dalam waktu 1X24 jam</p>\n<p>Jika belum, silahkan verifikasi ulang menggunakan SMS</p>\n<p>Jika Status Lunas, silahkan cetak detail tagihan untuk mengambil barang di tempat kami, terimakasih</p>', 1, 1),
(11, 'test', '2014-03-07', '2014-05-02', 2, '<p>ini adalah berita saya</p>', 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `guestbook`
--

CREATE TABLE IF NOT EXISTS `guestbook` (
  `id_gb` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pesan` varchar(500) NOT NULL,
  `tanggal` datetime NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id_gb`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `kat_barang`
--

CREATE TABLE IF NOT EXISTS `kat_barang` (
  `id_kat_barang` int(11) NOT NULL AUTO_INCREMENT,
  `des_kat_brg` varchar(50) NOT NULL,
  `det_kat_brg` varchar(100) NOT NULL,
  `link_kat_brg` varchar(100) NOT NULL,
  PRIMARY KEY (`id_kat_barang`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `kat_barang`
--

INSERT INTO `kat_barang` (`id_kat_barang`, `des_kat_brg`, `det_kat_brg`, `link_kat_brg`) VALUES
(7, 'Tenda', 'Tenda', ''),
(8, 'Kursi', 'kursi', ''),
(9, 'Meja', 'meja', ''),
(10, 'Panggung', 'Panggung', ''),
(11, 'Tata Suara', 'Tata Suara', ''),
(12, 'Lain - lain', 'Lain - lain', '');

-- --------------------------------------------------------

--
-- Table structure for table `kat_berita`
--

CREATE TABLE IF NOT EXISTS `kat_berita` (
  `id_kat_berita` int(11) NOT NULL AUTO_INCREMENT,
  `kat_berita` varchar(100) NOT NULL,
  PRIMARY KEY (`id_kat_berita`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `kat_berita`
--

INSERT INTO `kat_berita` (`id_kat_berita`, `kat_berita`) VALUES
(1, 'news'),
(2, 'customer');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
  `id_profile` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('sosmed','pembayaran','contact','') NOT NULL,
  `nama` varchar(50) NOT NULL,
  `deskripsi` varchar(50) NOT NULL,
  `link` varchar(50) NOT NULL,
  PRIMARY KEY (`id_profile`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`id_profile`, `type`, `nama`, `deskripsi`, `link`) VALUES
(1, 'sosmed', 'facebook', 'fb : WKG', 'http://facebook.com/wk_groups'),
(2, 'sosmed', 'twitter', '@wk_group', 'http://twitter.com/wk_group'),
(3, 'sosmed', 'g+', '', ''),
(4, 'sosmed', 'bbm', '123457A', '#'),
(5, 'contact', 'Telp', 'No. Telp', ' (0274) 719 0660 | 0813 92220660 | 0858 6856060'),
(6, 'contact', 'email', 'email', 'cs@wkgroup.com'),
(7, 'pembayaran', 'mandiri', '', ''),
(8, 'pembayaran', 'bca', '', '0372685831'),
(9, 'pembayaran', 'bri', '', ''),
(10, 'pembayaran', 'bukopin', '', ''),
(11, 'pembayaran', 'bni', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `sewa`
--

CREATE TABLE IF NOT EXISTS `sewa` (
  `id_sewa` int(11) NOT NULL AUTO_INCREMENT,
  `tgl_transaksi` datetime NOT NULL,
  `tgl_jatuhtempo` date NOT NULL,
  `lewat_batas` int(11) NOT NULL,
  `tgl_sewa` date NOT NULL,
  `tgl_kembali` date NOT NULL,
  `lama` int(11) NOT NULL,
  `id_user` bigint(20) NOT NULL,
  `harga_sewa` int(11) NOT NULL,
  `harga_hari` int(11) NOT NULL,
  `denda` int(11) NOT NULL,
  `harga_total` int(11) NOT NULL,
  `bayar` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `batal` int(11) NOT NULL COMMENT '0 = false | 1 = true',
  PRIMARY KEY (`id_sewa`),
  KEY `id_usr` (`id_user`),
  KEY `id_sewa` (`id_sewa`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `sewa_item`
--

CREATE TABLE IF NOT EXISTS `sewa_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_sewa` int(11) NOT NULL,
  `id_barang` bigint(11) NOT NULL,
  `jumlah_brg` int(11) NOT NULL,
  `subtotal` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0 = digudang | 1 = dipinjam | 2 = digudang | 3 = dipinjam',
  PRIMARY KEY (`id`),
  KEY `id_sewa` (`id_sewa`,`id_barang`),
  KEY `id_brg` (`id_barang`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `slidder`
--

CREATE TABLE IF NOT EXISTS `slidder` (
  `id_slidder` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(6) NOT NULL,
  `url` varchar(200) NOT NULL,
  `img_path` varchar(500) NOT NULL,
  `content` varchar(200) NOT NULL,
  KEY `id_slidder` (`id_slidder`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `slidder`
--

INSERT INTO `slidder` (`id_slidder`, `name`, `url`, `img_path`, `content`) VALUES
(1, 'slide1', 'http://localhost/2014-Project/sewakamiCI/index.php/public/home/item/17/lampu-gantung-hias', 'lampu_arab.jpg', ''),
(2, 'slide2', '#', 'tempat.jpg', ''),
(3, 'slide3', '#', 'tenda.jpg', ''),
(4, 'slide4', '#', 'Kursiputih.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id_user` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nama_leng` varchar(100) NOT NULL COMMENT 'nama lengkap sesuai rekening bank',
  `alamat_leng` text NOT NULL,
  `kota` varchar(100) NOT NULL,
  `id_bank` int(11) NOT NULL,
  `no_rek` varchar(30) NOT NULL,
  `status` enum('banned','aktif') NOT NULL COMMENT 'status akun penggan',
  `level` enum('admin','pelanggan') NOT NULL,
  PRIMARY KEY (`id_user`),
  KEY `id_bank` (`id_bank`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `email`, `nama_leng`, `alamat_leng`, `kota`, `id_bank`, `no_rek`, `status`, `level`) VALUES
(1, 'yussan', 'ac43724f16e9241d990427ab7c8f4228', 'yussan@gmail.com', 'yussan', 'disini', 'disanan', 2, '1', 'aktif', 'pelanggan'),
(2, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin@sk.com', '', '', '', 1, '123', 'aktif', 'admin');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `barang`
--
ALTER TABLE `barang`
  ADD CONSTRAINT `barang_ibfk_1` FOREIGN KEY (`id_kat_barang`) REFERENCES `kat_barang` (`id_kat_barang`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `berita`
--
ALTER TABLE `berita`
  ADD CONSTRAINT `berita_ibfk_1` FOREIGN KEY (`id_kat_post`) REFERENCES `kat_berita` (`id_kat_berita`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `berita_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `sewa`
--
ALTER TABLE `sewa`
  ADD CONSTRAINT `sewa_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sewa_item`
--
ALTER TABLE `sewa_item`
  ADD CONSTRAINT `sewa_item_ibfk_1` FOREIGN KEY (`id_sewa`) REFERENCES `sewa` (`id_sewa`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `sewa_item_ibfk_2` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`id_bank`) REFERENCES `bank` (`id_bank`) ON DELETE NO ACTION ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
