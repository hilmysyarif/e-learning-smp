<div class="top-menu-search">

	<strong style="color:#fff" >BERITA BARU</strong> 

</div>
<table  class="table table-hover">
	<?php foreach ($post as $news) {?>
	<?php $newspost = substr($news['berita'], 0, 200) ;
	$lower = str_replace(" ", "-", $news['judul_berita']);
							//merubah nama file menjadi lowercase
	$lower_link = strtolower($lower);	
	?>
	<tr>
		<td style="padding:2px">
			<h5 style="margin-bottom:2px"><a href="<?php echo site_url('public/home/single/'.$news['id_berita'].'/'.$lower_link);  ?>"><?php echo $news['judul_berita']?></a></h4>
				<p style="color:gray;font-size:10px">Dibuat : <?php echo $news['tgl_buat']?></p>
				<p><?php echo $newspost ?> ...</p>
			</td>
		</tr>
		<?php } ?>
	</table>