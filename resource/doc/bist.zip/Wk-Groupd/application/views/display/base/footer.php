<div class="col-md-offset-1 col-md-10" >
					<hr style="border : 1px gray solid" />

				<h5><strong>WK-Group - Memberikan Pelayanan Prima Untuk Acara Pesta Anda</strong></h5>
					<p>WK Grup merupakan perusahaan yang didirikan pada tahun 1985. Dengan berdirinya Perusahaan WK Grup maka semakin lengkap lembaga penyewaan dibidang properti di wilayah Yogyakarta. Hal ini diharapkan semakin mampu meningkatkan kualitas sumber daya manusia Indonesia khususnya di wilayah Yogyakarta. Perusahaan WK Grup secara geografis terletak di jl. Rajawali Raya No.4, Manukan Kidul, Condongcatur, Yogyakarta, sekitar 1 KM kearah utara dari terminal Condongcatur. Perusahaan WK Grup ini merupakan salah satu penyewaan property ternama di wilayah Condongcatur dan sekitarnya.</p>

						<hr style="border : 1px gray solid" />
					</div>
				</div>
			</div>

		</body>
<footer>
	<div class="row bottom-menu">
		<div class="container">	
			<nav>
				<div class="row">			  	
					<div class="col-md-offset-1 col-md-10" >
						<div class="col-md-3">
							<strong>Temukan Kami</strong>
							<ul class="menu">
								<?php foreach ($sosmed as $sm) { 
									if(($sm['link'] != NULL)) {  //jika link sudah diatur di sosmed ?>
									<?php switch ($sm['nama']) {
										case 'facebook':
										echo '<li><a href="'.$sm['link'].'"><img style="width:25px;margin-right:2px" src="'.base_url('images/icon/fb.png').'" />'.$sm['deskripsi'].'</li>';
										break;

										case 'twitter' :
										echo '<li><a href="'.$sm['link'].'"><img style="width:25px;margin-right:2px" src="'.base_url('images/icon/twitter.png').'" />'.$sm['deskripsi'].'</li>';
										break;

										case 'g+' :
										echo '<li><a href="'.$sm['link'].'"><img style="width:25px;margin-right:2px" src="'.base_url('images/icon/g+.png').'" />'.$sm['deskripsi'].'</li>';
										break;

										case 'bbm' :
										echo '<li><a href="'.$sm['link'].'"><img style="width:25px;margin-right:2px" src="'.base_url('images/icon/bbm.png').'" />'.$sm['deskripsi'].'</li>';
										break;

										default:
													# code...
										break;
									}?>
									<?php	}
									?>
									<?php } ?>
								</ul>
							</div>

							<div class="col-md-3">
								<strong>Kontak</strong>
								<ul class="menu"><?php foreach($kontak as $kt) { ?>
									<li><a href="#"><?php echo $kt['nama']?> : <?php echo $kt['link']?></a></li>
									<?php } ?></ul>
								</div>

								<div class="col-md-3">
									<strong>Pembayaran Via</strong>
									<ul class="menu">
										<?php foreach ($bank as $b) { 
											if(($b['link'] != NULL)) {  //jika link sudah diatur di sosmed ?>
											<?php switch ($b['nama']) {
												case 'bri':
												echo '<li><a href="#"><img style="float:left;padding:5px; background-color:#fff" src="'.base_url('images/icon/bri.png').'" /></li> </br>';
												break;
												
												case 'bukopin' :
												echo '<li><a href="#"><img style="float:left;padding:5px; background-color:#fff" src="'.base_url('images/icon/bukopin.png').'" /></li> </br>';
												break;

												case 'bni' :
												echo '<li><a href="#"><img style="float:left;padding:5px; background-color:#fff" src="'.base_url('images/icon/bukopin.png').'" /></li> </br>';
												break;

												case 'mandiri' :
												echo '<li><a href="#"><img style="float:left;padding:5px; background-color:#fff" src="'.base_url('images/icon/mandiri.png').'" /></li> </br>';
												break;

												case 'bca' :
												echo '<li><a href="#"><img style="float:left;padding:5px; background-color:#fff" src="'.base_url('images/icon/bca.png').'" /></li> </br>';
												break;

												default:
													# code...
												break;
											}?>

											<?php	}
											?>
											<?php } ?>
										</ul>
									</div>

									<div class="col-md-3">
										
									</div>
								</div>			  	
							</div>
						</nav>
					</div>
				</div>
				<center>Copyright &copy; 2014 WK-Group</center>

				<script type="text/javascript" src="<?php echo base_url();?>bootstrap/js/bootstrap.js?>"></script>	

			</footer>


		</body>		
		</html>