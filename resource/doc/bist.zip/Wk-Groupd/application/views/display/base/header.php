<!DOCTYPE HTML>
<html>
<head>
	<title><?php echo $title.'WK-Group'?></title>
	<link href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>" media="screen" rel="stylesheet">
	<link href="<?php echo base_url('bootstrap/css/publik.css') ?>" media="screen" rel="stylesheet">
	<link rel="shortcut icon" href="<?php echo base_url('images/favicon.png') ?>" >
	<meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport"/>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js')?>"></script>
	<script type="text/javascript">
		$( document ).ready(function(){
			var item = <?php echo $this->cart->total_items(); ?>;
			if(item > 0) {
				$('.cart').show(); //jika item di keranjang lebih dari nol, maka keranjang akan tampil	
			} else {
				$('.cart').hide(); //jika item di keranjang lebih kecil dari nol, maka keranjang tidak tampil
			}
		});
	</script>
</head>

<body>
	<div class="row top-navbar">
		<div class="container">	
			<nav>
				<div style="padding:5px" class="row">			  	
					<div class="col-md-offset-10 col-md-3">
						<p style="font-size:10px">Info lebih lanjut, hubungi 0274-719 0660</p></div>			  	
					</div>
				</nav>
			</div>
		</div>

		<div class="container">
			<header>
				<div class="row">
					<div class="col-md-offset-1 col-md-3 logo" >
						<img style="float:left" src="<?php echo base_url('images/logo.png')?>"/>
						<div class="logo-text">
							<h3>WK-Group</h3>
							<p>Persewaan Tenda,Panggung,Kursi</p>
						</div>
					</div>
					<div class="col-md-offset-1 col-md-5 logo" >
						<div class="level">
							<a title="Lihat Produk Kami" href="#"><img  src="<?php echo base_url('images/icon/level-1.png')?>" /></a>
						</div>
						<div class="level">
							<a title="Sewa Dengan Cara Mudah" href="#"><img  src="<?php echo base_url('images/icon/level-2.png')?>" /></a>
						</div>
						<div class="level">
							<a title="Proses Pengambilan Mudah" href="#"><img  src="<?php echo base_url('images/icon/level-3.png')?>" /></a>
						</div>
					</div>
				</div>


				<div class="row">				
					<div  class="col-md-offset-1 col-md-10 top-menu" >
						<ul class="menu top">
							<li><a href="<?php echo site_url()?>">Home</a></li>
							<li>|</li>
							<li><a href="<?php echo site_url('public/home/produk')?>">Produk</a></li>
							<li>|</li>
							<li><a href="<?php echo site_url('public/home/news')?>">Berita</a></li>
							<li>|</li>
							<li><a href="<?php echo site_url('public/home/single/8/tentang-kami')?>">Tentang Kami</a></li>
							<li>|</li>
							<li><a href="<?php echo site_url('public/home/single/10/cara-pemesanan')?>">PanduanPemesanan</a></li>
							<li>|</li>
							<li><a href="<?php echo site_url('public/home/bukutamu')?>">Buku Tamu</a></li>

							<?php 
								$data = $this->session->userdata('is_logged_in'); //jika user sudah login
								if(empty($data)) {
									?>	

									<li style="float:right"><?php echo validation_errors();//jika terjadi error saat login?></li>
									<li style="float:right">

										<div class="dropdown pull-right">
											<a href="#login"  id="dLabel" role="button" data-toggle="dropdown" data-target="#">
												Login <span class="caret"></span>
											</a>
											<ul style="float:left;padding:10px" class="dropdown-menu" role="menu" aria-labelledby="dLabel">
												
												<form role="form" class="form-group" action="<?php echo site_url('public/home/login_validation');?>" method="post">
													<div class="form-group">
														<label class="sr-only" for="Username">Username</label>
														<input name="username" type="text" class="form-control" id="exampleInputEmail2" placeholder="Username">
													</div>
													<div class="form-group">
														<label class="sr-only" for="exampleInputPassword2">Password</label>
														<input name="password" type="password" class="form-control" id="exampleInputPassword2" placeholder="Password">
													</div>
													<div class="form-group">
														<input class="form-control" type="submit" class="btn btn-default" value="Login" name="save[login]">
													</div>
												</form>
											</ul>
										</div></li>										
										<li style="float:right"> | </li>
										<li style="float:right"><a href="#register" data-toggle="modal">Register</a></li>

										<?php } else { ?>

										<div style="float:right" class="dropdown pull-right">
											
											<li style="float:right">
												<a href="#login"  id="dLabel" role="button" data-toggle="dropdown" data-target="#user">
													Welcome, <?php echo $this->session->userdata('username') ?> <span class="caret"></span>
												</a>

												<ul style="min-width:0" class="dropdown-menu" role="menu" aria-labelledby="dLabel">												
													<li style="float:right"><a href="<?php echo site_url('pelanggan/pelanggan/tagihan') ?>">Tagihan </a></li>
													<li style="float:right"><a href="<?php echo site_url('public/home/logout') ?>">Logout</a></li>
												</ul>
											</li>
											<li style="float:right">| </li>
											<li style="float:right"><a href="<?php echo site_url('pelanggan/pelanggan/tagihan') ?>">Tagihan </a></li>										

										</div>

										<?php }	?>								
									</ul>
								</div>
							</div>

							<div class="row">
								<div style="background-color:#fff"  class="col-md-offset-1 col-md-10 top-menu" >
								</div>
							</div>

							<div class="row">
								<div class="col-md-offset-1 col-md-10 top-menu-search" >
									<div class="row">
										<div class="col-md-2">
											<div style="width:110%" class="btn-group">
												<button style="color:#fff; background-color:#ff8c3f" type="button" class="col-md-12 btn btn-default dropdown-toggle" data-toggle="dropdown">
													<strong>KATEGORI</strong> <span class="glyphicon glyphicon-chevron-down"></span>
												</button>
												<ul class="dropdown-menu" role="menu">

													<?php foreach ($kat as $ktg) { ?>
													<li><a href="<?php echo site_url('public/home/kategori/'.$ktg['id_kat_barang'].'/'.$ktg['des_kat_brg']); ?>" title="<?php echo $ktg['des_kat_brg'];?>"><?php echo $ktg['des_kat_brg']; ?></a></li>
													<?php } ?>
													<!--  -->
												</ul>
											</div>
										</div>

										<div class="col-md-5">
											<div class="col-lg-13">
												<form method="GET" action="<?php echo site_url('public/home/search') ?>">
													<div class="input-group">

														<input name="q" type="text" class="form-control" placeholder="pencarian produk">
														<span class="input-group-btn">
															<button class="btn btn-default" type="submit"><span class="glyphicon glyphicon-search"></span></button>
														</span>

													</div><!-- /input-group -->
												</form>
											</div><!-- /.col-lg-6 -->
										</div>

										<div  class="cart col-md-5">
											<a name="lihat keranjang" type="button" href="<?php echo site_url('public/home/pelanggan') ?>" style="background-color:#336cff;color:#fff;width:90%;text-align:left" href="#" class="btn btn-default"><span class="glyphicon glyphicon-shopping-cart"> </span> Total Rp.<?php echo $this->cart->format_number($this->cart->total()); ?>,- (<?php echo $this->cart->total_items(); ?> item) <span style="float:right" class="glyphicon glyphicon-chevron-right"> </span> </a>
											<a name="reset keranjang" class="btn btn-default"type="button" style="background-color:#336cff;color:#fff;" href="<?php echo site_url('public/home/remove/all')?>"><strong>X</strong></a>

										</div>
									</div>
								</div>
							</div>

						</header>
					</div>
					<div class="row" style="height:5px;background-color:#009cff">
					</div>


					<!--register modal-->
					<div class="modal fade" id="register" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
						<div class="modal-dialog">
							<div class="modal-content">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
									<h4 class="modal-title">Register Wk-Group</h4>
								</div>
								<div class="modal-body">
									<form class="form" action="<?php echo site_url('public/home/register_validation');?>" method="post">
										<input class="form-control" type="text" name="nama" placeholder="nama sesuai rekening bank" required/>
										<br/>
										<input class="form-control" type="text" name="email" placeholder="email" required/>
										<br/>
										<input class="form-control" type="text" name="kota" placeholder="Kota/Kabupaten" required/>
										<br/>
										<textarea class="form-control" required name="alamat" placeholder="alamat lengkap"></textarea>
										<br/>
										<p class="text-small">Pilih Bank Untuk Melakukan Transfer</p>

										<select class="form-control" name="bank" required>
											<option value="1">BRI</option>
											<option value="2">Mandiri</option>
										</select>
										<br/>
										<input class="form-control" type="text" name="rekening" placeholder="nomor rekening.." required/>
										<br/>
										<input class="form-control" type="text" name="username" placeholder="username.." required/>
										<br/>
										<input class="form-control" type="password" name="password1" placeholder="password.." required/>
										<br/>
										<input class="form-control" type="password" name="password2" placeholder="masukan password lagi.." required/>
										<br/>
										<label class="checkbox" required>
											<input type="checkbox" value="1" required>
											<p class="small-text">saya menyetujui <a href="#">syarat dan ketentuan</a> dan data ini saya ini dengan sesungguhnya</p>
										</label>
										<br/>
										<input type="submit" class="btn" value="Register">
									</form>
								</div>
							</div><!-- /.modal-content -->
						</div><!-- /.modal-dialog -->
					</div><!-- /.modal -->