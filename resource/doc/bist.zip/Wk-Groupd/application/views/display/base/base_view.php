<?php $this->load->view('display/base/header')?>
<?php $this->load->view($template_anak); ?>
<?php $this->load->view('display/base/footer')?>