
<body>	

	<div class="container">
		<br/>
		<div class="row">

			<div class="col-md-offset-1 col-md-10" >
				<div class="row">
					<div class="col-md-6">
						<a href="#" target="blank"><img src="<?php echo base_url()?>images/barang/<?php echo $view['pic_brg']?>" width="100%" /></a>
					</div>

					<div class="col-md-6">
						<?php echo form_open('public/home/add_to_cart'); ?>
							<h1><?php echo $view['nama_barang']?></h1>
							<p><?php echo $view['des_barang']?></p>
							<hr/>
							<h4>Stok : <?php echo $view['stok_sisa']?></h4>
							<h3 style="color:#ff8c3f"><strong>Rp.<?php echo $view['harga']?> / item</strong></h3>
							<div class="col-lg-5">
									<div class="input-group">
										<input type="hidden" name="id_brg" value="<?php echo $view['id_barang']; ?>"/>
										<input name="jumlah" min="1" max="<?php echo $view['stok_sisa']?>" type="number"  class="form-control" placeholder="jumlah" required>
										<span class="input-group-btn">
											<input type="submit" class="btn" name="cart" action="public/home/add_to_cart" value="+sewa">
										</span>
									</div><!-- /input-group -->
								</form>
							</div><!-- /.col-lg-6 -->
						<?php echo form_close(); ?>
					</div>
				</div>
			</div>

			<!--tampilan produk lainnya-->
			<div class="col-md-offset-1 col-md-10" >
				<h3 class="menu">Produk Lainnya</h3>
				<div class="row">

					<?php foreach ($all as $key) { ?>
					<?php
					//merubah spasi menjadi -
					$lower = str_replace(" ", "-", $key['nama_barang']);
					//merubah nama file menjadi lowercase
					$lower_link = strtolower($lower);?>	

					<div class="produk-thumb col-md-3">
						<center>
							<div class="img-thumb">
								<a href="<?php echo site_url('public/home/item/'.$key['id_barang'].'/'.$lower_link);  ?>"><img src="<?php echo base_url()?>images/barang/<?php echo $key['pic_brg']?>" alt="" /></a>
							</div>

							<a href="<?php echo site_url('public/home/item/'.$key['id_barang'].'/'.$lower_link);  ?>"><?php echo $key['nama_barang'];?></a>
							<p>Stok <?php echo $key['stok_sisa'];?></p>
							<p><strong style="color:#ff8c3f;font-size:15px">Rp.<?php echo $key['harga']; ?> / unit</strong></p>
							<a style="border-radius:none; border : 1px solid rgb(233, 233, 233);background-color: rgb(233, 233, 233);width:100%;"class="btn btn-default" href="#">Sewa</a>
						</center>
					</div>

					<?php } ?>


				</div>

			</div>
		</div>

	</div>

	<div class="container">
		<div class="row">
