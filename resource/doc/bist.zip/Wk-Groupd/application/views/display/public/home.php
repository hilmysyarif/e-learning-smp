<?php $kami['berita'] = substr($kami['berita'], 0, 800);
		$intro = substr($kami['berita'], 0, 500);
?>


<body>
	<div  class="konten container">
		<div class="row">
			<div class="col-md-offset-1 col-md-10" >
				<div class="row">
					<!--kategori view on deskotop -->
					<div  class="sidebar col-md-2">
						<table class="table table-hover">
							<?php foreach ($kat as $ktg) { ?>
								<tr><td><a href="<?php echo site_url('public/home/kategori/'.$ktg['id_kat_barang'].'/'.$ktg['des_kat_brg']); ?>"><?php echo $ktg['des_kat_brg']; ?></a></td></tr>
							<?php } ?>
							
						</table>						
					</div>

					<!--slidder view-->
					<div  class="col-md-6">
						<div class="row">
							<div class="col-md-12">
								<div id="carousel-example-generic" class="carousel slide">
									<!-- Indicators -->
									<ol class="carousel-indicators">
										<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
										<li data-target="#carousel-example-generic" data-slide-to="1"></li>
										<li data-target="#carousel-example-generic" data-slide-to="2"></li>
									</ol>

									<!-- Wrapper for slides -->
									<div style="height:100%" class="carousel-inner">

										<?php foreach ($slidder as $s ) { 
									    	$fold = base_url()."/images/slidder/";
											$img = str_replace("%", "_", $s['img_path']); 
									    ?>

									     <div class=" <?php switch ($s['id_slidder']) { //gambar pertama adalah defaul yang ditampilkan
									    	case '1':
									    		echo "item  active";
									    		break;
									    	
									    	default:
									    		echo "item";
									    		break;
									    }?>">
									    	<a href="<?php echo $s['url']?>">
									    	<img style="width:100%;height:300px" src="<?php echo $fold.$img?>" alt="<?php echo $s['content']?>">
											<div class="carousel-caption">
												<?php echo $s['content']?>
											</div>
											</a>

									    </div>

									    <?php } ?>
									</div>

									<!-- Controls -->
									<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
										<span class="icon-prev"></span>
									</a>
									<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
										<span class="icon-next"></span>
									</a>
								</div>
							</div>								
						</div>
						<br/>
						<div class="row">
							<div class="col-md-12">									
								<p><strong>WK-Group </strong> <?php echo $intro ?> </p>
							</div>
						</div>

					</div>

					<!--berita baru view-->
					<div  class="col-md-4">
						<div class="top-menu-search">
							
								<strong style="color:#fff" >BERITA BARU</strong> 

						</div>
						<table  class="table table-hover">
							<?php foreach ($post as $news) {?>
							<?php $newspost = substr($news['berita'], 0, 200) ;
							$lower = str_replace(" ", "-", $news['judul_berita']);
							//merubah nama file menjadi lowercase
							$lower_link = strtolower($lower);	
							?>
							<tr>
								<td style="padding:2px">
									<h5 style="margin-bottom:2px"><a href="<?php echo site_url('public/home/single/'.$news['id_berita'].'/'.$lower_link);  ?>"><?php echo $news['judul_berita']?></a></h4>
									<p style="color:gray;font-size:10px">Dibuat : <?php echo $news['tgl_buat']?></p>
									<p><?php echo $newspost ?> ...</p>
								</td>
							</tr>
							<?php } ?>
						</table>
						<a class="btn" style="float:right;font-size:12px" href="<?php echo site_url('public/home/news')?>">Lihat Semua Berita ...</a>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="container">
		<div class="row">

			<div class="col-md-offset-1 col-md-10" >
				<h3 class="menu">Produk kami</h3>
				<div class="row">
					
						<!--tampilan produk yang dijual-->
						<?php foreach ($view as $kamiey) {?>
						<?php
						//merubah spasi menjadi -
						$lower = str_replace(" ", "-", $kamiey['nama_barang']);
						//merubah nama file menjadi lowercase
						$lower_link = strtolower($lower);?>		
						<div class="produk-thumb col-md-3">
						<center>
							<div class="img-thumb">
								<a href="<?php echo site_url('public/home/item/'.$kamiey['id_barang'].'/'.$lower_link);  ?>"><img src="<?php echo base_url()?>images/barang/<?php echo $kamiey['pic_brg']?>" alt="" /></a>
							</div>

							<div style="height:50px">
								<a href="<?php echo site_url('public/home/item/'.$kamiey['id_barang'].'/'.$lower_link);  ?>"><?php echo $kamiey['nama_barang'];?></a>
							</div>
							
							<p>Stok : <?php echo $kamiey['stok_sisa'];?> item</p>
							<p><strong style="color:#ff8c3f;font-size:15px">Rp.<?php echo $kamiey['harga']; ?>,- / unit</strong></p>
							<a style="border-radius:none; border : 1px solid rgb(233, 233, 233);background-color: rgb(233, 233, 233);width:100%;"class="btn btn-default" href="<?php echo site_url('public/home/item/'.$kamiey['id_barang'].'/'.$lower_link);  ?>">Sewa</a>
						</center>
						</div>
						<?php } ?>
					


				</div>

				<br/>
				<a style="float:right" href="<?php echo site_url('public/home/produk') ?>">Produk Lainnya ...</a>

			</div>
		</div>

	</div>

	<div class="container">
		<div class="row">