	<body>
		<div class="container">
			<div class="row">
				
				<div class="col-md-offset-1 col-md-10" >
					<h3 class="menu">Halaman Pembayaran</h3>
					<table class="table table-hover">
						<thead>
							<tr>
								<th><strong>No.</strong></th>
								<th><strong>Barang</strong></th>
								<th><strong>Jumlah</strong></th>
								
								<th><strong>Harga</strong></th>
								<th><strong>Sub-Total</strong></th>
								<th><strong>Status</strong></th>
								<th></th>
							</tr>
						</thead>
						<tbody>
							<?php $i = 1; ?>
							<?php foreach ($this->cart->contents() as $items): ?>
								<?php echo form_hidden($i.'[rowid]', $items['rowid']); ?>
								<tr>
									<td><?php echo $i; ?></td>
									<td><?php echo $items['name']; ?></td>
									<td><?php echo $items['qty']; ?></td>
									
									<td><?php echo $this->cart->format_number($items['price']); ?></td>
									<td>Rp. <?php echo $this->cart->format_number($items['subtotal']); ?></td>
									<td>
									<a href="<?php echo site_url('public/home/remove/'.$items['rowid']); ?>" title="">Batal</a>
									</td>
									<td> 
									<a href="<?php echo site_url('public/home/item/'.$items['id'].'/'.$items['name']) ?>" title="">Edit</a></td>
								</tr>
								<?php $i++; ?>
							<?php endforeach; ?>
						</tbody>
					</table>	

				<form class="form-group" action="<?php echo site_url('public/home/save_sewa'); ?>" method="post" accept-charset="utf-8">
				<a href="<?php echo site_url('public/home/produk'); ?>" title="">
					<input class="btn" type="button" name="" value="+ Tambah Barang"> <br/>
				</a>
				<br/>
				<p><strong>Biaya pembayaran = </strong> total ((harga barang x jumlah)) x hari + denda(jika ada)</p>
				<p><strong>Denda = </strong>Rp.20.000,- / hari, dihitung ketika telat bayar welewati jatuh tempo</p>
				
				<?php
				//tanggal sekarang
				$now = date('Y-m-d');
				?>


				
				<div class="row">
					<div class="col-md-3">
						<label><strong>Tanggal Sewa :</strong> </label>
						<input onchange="autoclose()" min="<?php echo $now?>" class="form-control" style="margin-top:10px;" type="date" name="tglsewa" placeholder="tanggal sewa" required/>
					</div>

					<div class="col-md-3">
						<label><strong>Tanggal Kembali :</strong></label>
						<input min="<?php echo $now?>" class="form-control" style="margin-top:10px;" type="date" name="tglkembali" required/>
					</div>
				</div>
				


				<br/>
				<br/>
				<a href="<?php echo site_url('public/home/save_sewa'); ?>" title="">					
					<input type="hidden" name="id_user" value="<?php echo $this->session->userdata('id_user'); ?>">					
					<input class="btn" type="submit" name="" value="+ Masukan Tagihan">
				</a>
				</form>		

		</div>
	</div>
	</div>
</body>