
<body>

	<!--tampilan untuk detail tagihan-->
	<div class="container">
		<div class="row">
			<div class="col-md-offset-1 col-md-10" >
				<div class="row">
					<div class="col-md-6">
						<h3 class="menu">Tagihan User</h3>
						<p>Gunakan Halaman ini untuk cek total dan statu tagihan anda, kunjungi link dibawah ini mengetahui metode pembayaran lebih detail <a href="#">Cara pembayaran</a> </p>
					</div>

					<div class="col-md-6">
						<h3 class="menu">Edit Data</h3>

						<form class="form" action="<?php echo site_url('pelanggan/pelanggan/edit_usr'); ?>" method="post" accept-charset="utf-8">
							<input name="id_user" class="input-xlarge" type="hidden" id="inputEmail" value="<?php echo $user['id_user']?>" placeholder="">
							<div class="control-group">
								<label class="control-label" for="inputEmail">Nama Lengkap</label>
								<div class="controls">
									<input name="nama_leng" class="form-control input-xlarge" type="text" id="inputEmail" value="<?php echo $user['nama_leng']?>" placeholder="">
								</div>
							</div>
							<br/>
							<div class="control-group">
								<label class="control-label" for="inputEmail" >Kota/Kabupaten</label>
								<div class="controls">
									<input name="kota" class="form-control input-xlarge" type="text" id="inputEmail" value="<?php echo $user['kota']?>" placeholder="">
								</div>
							</div>
							<br/>
							<div class="control-group">
								<label class="control-label" for="inputEmail">Alamat Lengkap</label>
								<div class="controls">
									<textarea name="alamat_leng" class="form-control input-xlarge" ><?php echo $user['alamat_leng']?></textarea>
								</div>
							</div>
							<br/>
							<div class="control-group">
								<label class="control-label" for="inputEmail">Email</label>
								<div class="controls">
									<input name="email" class="form-control input-xlarge" type="text" id="inputEmail" placeholder="" value="<?php echo $user['email']?>">
								</div>
							</div>
							<br/>
							<div class="control-group">
								<label class="control-label" for="inputEmail">id Bank</label>
								<p>1 = BRI | 2 = Mandri </p>
								<div class="controls">
									<input name="id_bank" class="form-control input-xlarge" type="text" id="inputEmail" placeholder="" value="<?php echo $user['id_bank']?>">
								</div>
							</div>
							<br/>
							<div class="control-group">
								<label class="control-label" for="inputEmail">No. Rekening</label>
								<div class="controls">
									<input name="no_rek" class="form-control input-xlarge" type="text" id="inputEmail" placeholder="" value="<?php echo $user['no_rek']?>">
								</div>
							</div>
							<br/>
							<input type="submit" class="btn btn-default" value="Update Data">
						</form>
					</div>

				</div>
			</div>
		</div>
	</div>
	<br/>
	<!--tampilan tabel tagihan-->
	<div class="container">
		<div class="row">
			<div class="col-md-offset-1 col-md-10" >
				<h3 class="menu">Daftar Tagihan</h3>
				<div class="row">
					<div class="col-md-12">
						<table class="table table-hover">
							<thead>
								<tr>
									<th><strong>No.</strong></th>
									<th><strong>Id-sewa</strong></th>
									<th><strong>Transaksi</strong></th>
									<th><strong>Jatuh Tempo</strong></th>
									<th><strong>Tanggal Sewa</strong></th>
									<th><strong>Tanggal Kembali</strong></th>
									<th><strong>Lama(hari)</strong></th> 				
									<th><strong>Status Pembayaran</strong></th>
									<th></th>
								</tr>
							</thead>
							<tbody>
								<?php $i = 1; ?>
								<?php foreach($tagihan as $t) { ?> 
								<tr>
									<td><?php echo $i?></td>
									<td><?php echo $t['id_sewa'];?></td>
									<td><?php echo $t['tgl_transaksi'];?></td>
									<td><?php echo $t['tgl_jatuhtempo'];?></td>
									<td><?php echo $t['tgl_sewa'];?></td>
									<td><?php echo $t['tgl_kembali'];?></td>
									<td><?php echo $t['lama'];?></td>			
									<td>
										<?php 
				  						//jika 0 belum lunas, jika 1 lunas
										switch ($t['status']) {
											case '0':
											echo '<p style="color:red">BELUM LUNAS</p>';
											break;
											case '1' :
											echo '<p style="color:green">LUNAS</p>';
											break;
											default:
											echo "Belum lunas";
											break;
										}
										?>
									</td>
									<td><a target="_blank" style="padding:2px" class="btn-primary" href="<?php echo site_url('pelanggan/pelanggan/detailtagihan?id=')?><?php echo /*$this->encrypt->encode(*/$t['id_sewa']/*)*/;?>"><span class="glyphicon glyphicon-chevron-right"></span></a></td>
								</tr>

								<?php $i++; ?>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>


	<div class="container">
		<div class="row">