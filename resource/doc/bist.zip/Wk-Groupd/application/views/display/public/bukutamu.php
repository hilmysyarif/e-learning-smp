	<body>
		<div class="container">
			<div class="row">
				
				<div class="col-md-offset-1 col-md-7" >
					<h3 class="menu">Buku Tamu</h3>
					<p>Ada pertanya, kritik dan saran tentang pelayanan kami, silahkan kirimkan lewat buku tamu ini</p>
					<form class="form-horizontal" method="post" action="<?php echo site_url('public/home/guestbook')?>">
						<div class="control-control">
							<label class="control-label" for="nama">Nama :</label>
							<div class="controls">
								<input class="form-control" style="width:80%" type="text" id="nama" name="nama" placeholder="Nama" required>
							</div>
						</div>
						<div class="control-control">
							<label class="control-label" for="email">Email :</label>
							<div class="controls">
								<input class="form-control" style="width:80%" type="email" id="email" name="email" placeholder="Email" required>
							</div>
						</div>
						<div class="control-control">
							<label class="control-label" for="email">Pesan :</label>
							<div class="controls">
								<textarea class="form-control" style="width:80%" rows="5" id="pesan" name="pesan" placeholder="Pesan" required></textarea>
							</div>
						</div>
						<div class="control-control">
							<label class="control-label" for="email">Keamanan :</label>
							<div class="controls">
							<p><?php echo $image;?> <input style="width:200px" class="form-control" type="text" placeholder="masukan teks kode kemanan" name="security_code"></p>
							</div>
						</div>



						<div class="control-control">
							<div class="controls">
								<button type="submit" class="btn">Kirim</button>
							</div>
						</div>
					</form>
				</div>


			</div>

		</div>

		<div class="container">
			<div class="row">