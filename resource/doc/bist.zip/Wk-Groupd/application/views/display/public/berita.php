	<body>
		<div class="container">
			<div class="row">
				
				<div class="col-md-offset-1 col-md-7" >
					<h3 class="menu">Berita</h3>
					<?php foreach ($view as $news) { ?>
					<?php $newspost = substr($news['berita'], 0, 400) ;
					$lower = str_replace(" ", "-", $news['judul_berita']);
					//merubah nama file menjadi lowercase
					$lower_link = strtolower($lower);	
					?>

					<div class="col-md-12">
						<div class="post-title"><h1 style="font-size:20px"><a href="<?php echo site_url('public/home/single/'.$news['id_berita'].'/'.$lower_link);  ?>"><?php echo $news['judul_berita']?></a></h1></div>
						<div class="post-date"><p>dibuat : <?php echo $news['tgl_buat']?></p></div>
						<div class="post-content">					

							<?php echo $newspost ?> ...

						</div>
						<a href="<?php echo site_url('public/home/single/'.$news['id_berita'].'/'.$lower_link);  ?>">Selengkapnya >></a>
					</div>
					<hr/>

					<? } ?>

					
				</div>

				<div class="col-md-3" >
					<br/>
					<div class="row">
						<div class="col-md-12">
							<?php $this->load->view('display/sidebar/berita_baru')?>
						</div>
					</div>
				</div>

			</div>

			<div class="row">				
				<div class="col-md-offset-1 col-md-10" >
					<center><strong>Halaman Ke : </strong><?php echo $page?></center>
				</div>
			</div>

		</div>

		<div class="container">
			<div class="row">
				