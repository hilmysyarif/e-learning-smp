	<body>
		<div class="container">
			<div class="row">
				
				<div class="col-md-offset-1 col-md-7" >
					<br/>
					<div class="post-title"><h2><a href="#"><?php echo $view['judul_berita']?></h2></a></div>
					<div class="post-date"><p>dibuat : <?php echo $view['tgl_buat']?></p></div>
					<div class="post-content">					

						<?php echo $view['berita'] ?>

					</div>				
				</div>

				<div class="col-md-3" >
					<br/>
					<div class="row">
						<div class="col-md-12">
							<?php $this->load->view('display/sidebar/berita_baru')?>
						</div>
					</div>
				</div>

			</div>

		</div>

		<div class="container">
			<div class="row">