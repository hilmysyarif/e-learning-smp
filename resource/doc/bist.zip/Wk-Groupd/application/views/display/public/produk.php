	<body>
		<div class="container">
			<div class="row">
				
				<div class="col-md-offset-1 col-md-10" >
					<h3 class="menu">Produk Kami</h3>
					<div class="row">
						<?php foreach ($view as $key) {?>
						<?php
						//merubah spasi menjadi -
						$lower = str_replace(" ", "-", $key['nama_barang']);
						//merubah nama file menjadi lowercase
						$lower_link = strtolower($lower);?>

						<div class="produk-thumb col-md-3">
							<center>
								<div class="img-thumb">
									<a href="<?php echo site_url('public/home/item/'.$key['id_barang'].'/'.$lower_link);  ?>"><img  src="<?php echo base_url()?>images/barang/<?php echo $key['pic_brg']?>" alt="" /></a>
								</div>

								<div style="height:50px">
								<a href="<?php echo site_url('public/home/item/'.$key['id_barang'].'/'.$lower_link);  ?>"><?php echo $key['nama_barang'];?></a>
								</div>

								<p>Stok <?php echo $key['stok_sisa'];?></p>
								<p><strong style="color:#ff8c3f;font-size:15px">Rp.<?php echo $key['harga']; ?> / unit</strong></p>
								<a style="border-radius:none; border : 1px solid rgb(233, 233, 233);background-color: rgb(233, 233, 233);width:100%;"class="btn btn-default" href="<?php echo site_url('public/home/item/'.$key['id_barang'].'/'.$lower_link);  ?>">Sewa</a>
							</center>
						</div>

						<?php } ?>
						<!--end of items-->



					</div>

				</div>
			</div>

			<div class="row">				
				<div class="col-md-offset-1 col-md-10" >
					<center><strong>Halaman Ke : </strong><?php echo $page?></center>
				</div>
			</div>

		</div>

		<div class="container">
			<div class="row">