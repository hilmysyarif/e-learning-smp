<?php
	if(isset($this->session->userdata['status_admin'])){
	redirect(site_url('admin/dashboard/welcome'));
	}
?>

	<div class="row">
		<div class="col-md-offset-1 col-md-3" >

			<form class="form-horizontal form-group" method="post" action="<?php echo site_url('admin/dashboard/login_validation')?>">
				<div class="control-group">
					<h4 >WK-Group Administrator Login Page</h4>
					<br/>
					<div ><?php echo validation_errors();?></div>
					<br/>
					<label class="control-label" for="inputusername">Username</label>
					<div class="controls">
						<input class="form-control" type="text" name="username" id="inputusername" placeholder="username">
					</div>
				</div>
				<div class="control-group">
					<label class="control-label" for="inputPassword">Password</label>
					<div class="controls">
						<input class="form-control" type="password" name="password" id="inputPassword" placeholder="Password">
					</div>
				</div>
				<br/>
				<div class="control-group">
					<div class="controls">
						<button type="submit" class="btn">Sign in</button>
					</div>
				</div>
			</form>
		</div>
	</div>