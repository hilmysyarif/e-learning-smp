<div class="row-fluid">
	<div style="background-color: rgb(247, 245, 245)" class="col-md-2">
		<ul class="nav nav-pills nav-stacked">
			<li class="nav-header"><div style="background-color:#ff8c3f" class="top-menu-search">
			<strong style="color:#fff">Admin Menu</strong>
			</div></li>
			<li class="active" ><a href="<?php echo site_url()?>/admin/dashboard/welcome">Homepage</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/post">Berita</a></li>
			
			<li><a href="<?php echo site_url()?>/admin/dashboard/bukutamu">Buku Tamu</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/barang">Barang</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/tagihan">Tagihan</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/pelanggan">Pelanggan</a></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/user">User</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/footer">Footer</a></li>
		</ul>
	</div>
	<div class="col-md-10">
		<div class="widget-title"><h2>Administrator Dashboard</h2></div>	
		<h4>Slidder</h4>
		<div class="row-fluid">
			<?php foreach($slidder as $s) {
				$folder = "images/slidder/";
				$img = str_replace("%", "_", $s['img_path']);
			?>
			<div class="col-md-3">
			<strong><?php echo $s['name']?></strong>

			<form enctype="multipart/form-data" method="post" action="<?php echo site_url('admin/dashboard/update_slidder')?>">
				<input class="form-control" type="hidden" name="id" value="<?php echo $s['id_slidder']?>">
				<img class="col-md-3" src="<?php echo base_url().$folder.$img?>">
				<p>*ukuran 600x300 px , support : png, jpg, jpeg</p>
				<input class="form-control" type="file" name="img" value="gambar">
				<p>*maksimal 200 karakter</p>
				<textarea class="form-control" name="content"><?php echo $s['content']?></textarea>
				<p>Url tujuan</p>
				<input class="form-control" type="text" name="url" value="<?php echo $s['url'] ?>">
				<input class="form-control" type="submit" value="update" class="btn">
			</form>
			</div>
			<?php } ?>

	</div>
</div>