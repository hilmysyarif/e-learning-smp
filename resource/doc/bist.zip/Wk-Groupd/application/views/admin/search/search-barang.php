<div class="row-fluid">
		<div style="background-color: rgb(247, 245, 245)" class="col-md-2">
		<ul class="nav nav-pills nav-stacked">
			<li class="nav-header"><div class="top-menu-search">
				<strong style="color:#fff">Admin Menu</strong>
			</div></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/welcome">Homepage</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/post">Berita</a></li>
			
			<li><a href="<?php echo site_url()?>/admin/dashboard/bukutamu">Buku Tamu</a></li>
			<li class="active"><a href="#">Barang</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/tagihan">Tagihan</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/pelanggan">Pelanggan</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/footer">Footer</a></li>
		</ul>
	</div>
	
	<div class="col-md-10">
		<div class="widget-title"><h2>Pencarian</h2></div>	
		


		<table class="table">
			
			<thead>
				<tr>
					<td><strong>No</strong></td>
					<td><strong>Id</strong></td>
					<td><strong>Nama Barang</strong></td>
					<td><strong>Deskripsi Barang</strong></td>
					<td><strong>Id Kategori</strong></td>
					<td><strong>Stok Total</strong></td>
					<td><strong>disewa</strong></td>
					<td><strong>Stok Sisa</strong></td>
					<td><strong>Harga / unit</strong></td>
					<td><strong>Image</strong></td>
					<td></td>
					<td></td>
				</tr>
			</thead>
			<tbody>
				<?php 
				$i =1; 
				if($view == null){
					echo '<tr><td colcol-md-="11"><h2>Data Yang Anda Cari Tidak Ditemukan</h2><td></tr>';
				} else {
				?>

				<?php foreach($view as $key) {?>
				<tr>
					<td><?php echo $i?></td>
					<td><?php echo $key['id_barang']?></td>
					<td><?php echo $key['nama_barang']?></td>
					<td><?php echo $key['des_barang']?></td>
					<td><?php echo $key['id_kat_barang']?></td>
					<td><?php echo $key['stok_total']?></td>
					<td><?php echo $key['disewa']?></td>
					<td><?php echo $key['stok_sisa']?></td>
					<td><?php echo $key['harga']?></td>
					<td>
						<a class="btn" href="<?php echo base_url()?>images/barang/<?php echo $key['pic_brg']?>">Lihat Gambar</a>
						<a class="btn" href="#edit_<?php echo $key['id_barang']?>" data-toggle="modal">Edit</a>
						<a class="btn" onclick="return confirm('Yakin hapus : <?php echo $key['nama_barang']; ?>?')" href="<?php echo site_url()?>/admin/dashboard/status_barang?id_barang=<?php echo $key['id_barang']?>" >Hapus</a>
					</td>
				</tr>
				<!--modal edit barang-->
							<!-- Modal -->
							<div id="edit_<?php echo $key['id_barang']?>" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
									<h3 id="myModalLabel">Edit barang id : <?php echo $key['id_barang']?></h3>
								</div>

								<div class="modal-body">
									
									<form enctype="multipart/form-data" class="form-horizontal" method="post" action="<?php echo site_url('admin/dashboard/upd_brg?id=')?><?php echo $key['id_barang']?>">
										
										<div class="control-group">
											<label class="control-label">Kategori :</label> 
											<div class="controls"><select name="kat" class="input-xlarge" required>
												<?php foreach ($kat as $ktg) { ?>							
												<option value='<?php echo $ktg['id_kat_barang']; ?>'><?php echo $ktg['des_kat_brg']; ?></option>
												<?php } ?>	</select>
											</div>
										</div>

										<div class="control-group">
											<label class="control-label">Nama Barang :</label>
											<div class="controls">
												<input style="width:95%" type="text" name="nama_barang" class="input-xlarge" value="<?php echo $key['nama_barang'] ?>" required>
											</div>										
										</div>

										<div class="control-group">
											<label class="control-label">Deskripsi Barang :</label>
											<div class="controls">
											<textarea style="width:95%" name="des_barang" class="input-xlarge"  required><?php echo $key['des_barang'] ?></textarea>
											</div>
										</div>

										<div class="control-group">
											<label class="control-label">Stok Total :</label>
											<div class="controls">
											<input type="text" name="stok" class="input-xlarge" value="<?php echo $key['stok_total'] ?>" required>
											</div>
										</div>

										<div class="control-group">
											<label class="control-label">Stok Disewa :</label>
											<div class="controls">
											<input type="text" name="disewa" class="input-xlarge" value="<?php echo $key['disewa']?>" required>
											</div>
										</div>

										<div class="control-group ">
											<div class="input-prepend input-append">
												<div class="controls"><col-md- class="add-on">Rp.</col-md-><input style="width:95%" type="text" name="harga" value="<?php echo $key['harga'] ?>" required><col-md- class="add-on">/ unit</col-md-></div>
											</div>
										</div>

										<!-- <div class="control-group">
											<label class="control-label">Upload foto :</label>
											<div class="controls"><input type="file" name="pic_brg" value="<?php echo $key['pic_brg'] ?>" class="input-xlarge" ></div>			
										</div> -->

										<div class="control-group">
											<label class="control-label"></label>
											<div class="controls"><input type="submit" value="Update Barang" class="btn"></div>		
										</div>

									</form>

									</div>

									<div class="modal-footer">

									</div>
								</div>
								<!--end of modal edit barang-->
				<?php } } ?>
				</tbody>
			</table>		     	




	</div>