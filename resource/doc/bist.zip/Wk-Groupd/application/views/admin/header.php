<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="id">
<header>
	<title>Sewa Kami | administrator</title>
	<link href="<?php echo base_url('bootstrap/css/bootstrap.css') ?>" media="screen" rel="stylesheet">
	<link href="<?php echo base_url('bootstrap/css/publik.css') ?>" media="screen" rel="stylesheet">
	<link rel="shortcut icon" href="<?php echo base_url('images/favicon.png') ?>" >
	<meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport"/>
	<script type="text/javascript" src="<?php echo base_url('bootstrap/js/jquery.js')?>"></script>
	<style type="text/css">
		.header-nav{
			background-color: #009cff;
			color : #fff;
			border-bottom: 3px solid #ff8c3f;
		}

		.header-nav a {
			color : #fff;
		}
	</style>
</header>

<body>
	<header id="header">
		
		<div class="row">
			<div class="col-md-12">
				<nav  class="header-nav navbar navbar-default" role="navigation">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a style="color:#fff" class="navbar-brand" href="#"><img style="height:50px;width:53px;border-radius:200px" style="float:left" src="<?php echo base_url('images/logo.png')?>"/> Wk-Group Administrator</a>
						</div>
						<ul style="float:right" class="nav navbar-nav">
						<?php if(isset($this->session->userdata['status_admin'])){ ?>
						<li><a style="color:#fff" href="<?php echo site_url('admin/dashboard/logout')?>"><?php echo $this->session->userdata('username_admin')?> | Logout</a></li>
						<?php } ?>
							<!-- <li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">Dropdown <b class="caret"></b></a>
								<ul class="dropdown-menu">
									<li><a href="#">Action</a></li>
									<li><a href="#">Another action</a></li>
									<li><a href="#">Something else here</a></li>
									<li><a href="#">Separated link</a></li>
								</ul>
							</li> -->
						</ul>
					</div>

					
				</nav>
			</div>
		</div>



	</header>
</div>
<body>