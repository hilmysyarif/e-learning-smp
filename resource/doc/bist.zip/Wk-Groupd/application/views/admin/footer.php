
	</body>

		<footer>
		<div class="row">
				<div class="row">
				<hr/>
				</div>
				<div class="row">
					<div class="container">
					<div class="col-md-12" style="padding:5px">
						<center>Copyright &copy; 2014 WK-Group</center>
					</div>
					</div>
				</div>
		</footer>

	<footer>
		<script type="text/javascript" src="<?php echo base_url();?>bootstrap/js/bootstrap.js?>"></script>		
	</footer>
</html>