<div class="row-fluid">
	<div style="background-color: rgb(247, 245, 245)" class="col-md-2">
		<ul class="nav nav-pills nav-stacked">
			<li class="nav-header"><div style="background-color:#ff8c3f" class="top-menu-search">
			<strong style="color:#fff">Admin Menu</strong>
			</div></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/welcome">Homepage</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/post">Berita</a></li>
			
			<li class="active"><a href="<?php echo site_url()?>/admin/dashboard/bukutamu">Buku Tamu</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/barang">Barang</a></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/tagihan">Tagihan</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/pelanggan">Pelanggan</a></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/user">User</a></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/footer">Footer</a></li>
		</ul>
	</ul>
</div>
<div class="col-md-10">
	<div class="widget-title">
		<h2>Buku tamu</h2>
	</div>	
	<div class="tabbable" > <!-- Only required for left/right tabs -->
		<ul class="nav nav-tabs">
			<li class="active"><a href="#baru" data-toggle="tab">Baru</a></li>
			<!-- <li ><a href="#aktif" data-toggle="tab">Terbaca</a></li> -->
		</ul>
		<div class="tab-content">

			<!--pesan baru-->
			<div class="tab-pane active" id="baru">
				<h4>Pesan Baru</h4>   
				<table class="table">
					<thead>
						<tr>
							<td><strong>No</strong></td>	
							<td><strong>Waktu</strong></td>	
							<td><strong>Pengirim</strong></td>
							<td><strong>Email</strong></td>
							<td></td>						
						</tr>
					</thead>
					<tbody>
						<?php 
						$i =1;
						foreach($blmterbaca as $belum) { 
						?>
						<tr>
							<?php $id_gb = $belum['id_gb']; ?>
							<td><?php echo $i?></td>	
							<td><?php echo $belum['tanggal']?></td>
							<td><?php echo $belum['nama']?></td>
							<td><?php echo $belum['email']?></td>
							<form method="post" action="">
								<input type="hidden" name="id" value="<?php echo $id_gb ?>">
								<td><btn class="btn btn-default" name="baca" type="submit" href="#belum_<?php echo $belum['id_gb']?>" data-toggle="modal" class="btn">Baca</btn>
								<a onclick="return confirm('Anda Yakin')" href="<?php echo site_url('admin/dashboard/delete_guestbook?id=').$belum['id_gb']?>" class="btn btn-default">Hapus</a>
								</td>

							</form>						
						</tr>
						<!--modal-->
						<div id="belum_<?php echo $belum['id_gb']?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
						  <?php 
						  	if(isset($_POST['baca'])) {
						  		$id =$_POST['id'];
						  		$sql = "UPDATE guestbook set status = 1 WHERE id_gb = '$id'";
						  		$this->db->query($sql);
						  	}
						  ?>
						  <div style="color:#fff" class="modal-header">
						    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
						    <h3 id="myModalLabel">Buku Tamu</h3>
						  </div>
						  <div style="background-color:#ECECEC;height:auto"  class="modal-body">
						    <p> Pesan dari : <?php echo $belum['nama']?> <br/>
						    	Email : <?php echo $belum['pesan']?> <br/>
						    	Dikirim : <?php echo $belum['tanggal']?> <br/>
						    	Pesan : <?php echo $belum['pesan']?>
						    </p>
						  </div>
						  </div>
						</div>
						<?php $i++; } ?>
					</tbody>
				</table>	 
				
			</div>
			<!--end of new-->

			<!--terbaca-->
			<div class="tab-pane"  id="aktif">
				<h4>Pesan terbaca</h4>   
				<table class="table">
					<thead>
						<tr>
							<td><strong>No</strong></td>	
							<td><strong>Waktu</strong></td>	
							<td><strong>Pengirim</strong></td>
							<td><strong>Email</strong></td>
							<td></td>						
						</tr>
					</thead>
					<tbody>
						<?php 
						$i =1;
						foreach($terbaca as $sudah) { 
						?>
						<tr>
							<td><?php echo $i?></td>	
							<td><?php echo $sudah['tanggal']?></td>
							<td><?php echo $sudah['nama']?></td>
							<td><?php echo $sudah['email']?></td>
							<td><a href="#sudah_<?php echo $sudah['id_gb']?>" data-toggle="modal" class="btn">Baca</a></td>						
						</tr>
						<!--modal-->
						<div id="sudah_<?php echo $sudah['id_gb']?>" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
						  <div class="modal-header">
						    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
						    <h3 id="myModalLabel">Buku Tamu</h3>
						  </div>
						  <div class="modal-body">
						    <p> Pesan dari : <?php echo $sudah['nama']?> <br/>
						    	Email : <?php echo $sudah['pesan']?> <br/>
						    	Dikirim : <?php echo $sudah['tanggal']?> <br/>
						    	Pesan : <?php echo $sudah['pesan']?>
						    </p>
						  </div>
						</div>
						<?php $i++; } ?>
					</tbody>
				</table>		     	
			</div>
			<!--end of terbaca-->

			

		</div>
	</div>

</div>