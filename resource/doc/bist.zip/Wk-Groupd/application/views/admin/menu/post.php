<script type="text/javascript" src="<?php echo base_url()?>tinymce/js/tinymce/tinymce.min.js"></script>
<script type="text/javascript">
	tinyMCE.init({
		selector : "textareas",
		menubar:false,
		statusbar: true
	});
</script>

<div class="row-fluid">
	<div style="background-color: rgb(247, 245, 245)" class="col-md-2">
		<ul class="nav nav-pills nav-stacked">
			<li class="nav-header"><div style="background-color:#ff8c3f" class="top-menu-search">
				<strong style="color:#fff">Admin Menu</strong>
			</div></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/welcome">Homepage</a></li>
			<li class="active"><a href="<?php echo site_url()?>/admin/dashboard/post">Berita</a></li>
			
			<li><a href="<?php echo site_url()?>/admin/dashboard/bukutamu">Buku Tamu</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/barang">Barang</a></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/tagihan">Tagihan</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/pelanggan">Pelanggan</a></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/user">User</a></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/footer">Footer</a></li>
		</ul>
	</ul>
</div>
<div class="col-md-10">
	<div class="widget-title">
		<h2>POST</h2>
	</div>	

	
	<div class="tabbable" > <!-- Only required for left/right tabs -->
		<ul class="nav nav-tabs">
			<li class="active"><a href="#baru" data-toggle="tab">Baru</a></li>
			<li ><a href="#aktif" data-toggle="tab">Aktif</a></li>
			<li><a href="#draft" data-toggle="tab">Draft</a></li>
			<li><a href="#kategori" data-toggle="tab">Kategori</a></li>
		</ul>
		<div class="tab-content">

			<!--new-->
			<div class="col-md-9 tab-pane active" id="baru">
				<h4>Post Baru</h4>    
				<form class="form" action="<?php echo site_url('admin/dashboard/create_post')?>" method="post" enctype="multipart/form-data">
					<label>Judul</label>
					<input class="form-control col-md-8" type="text" name="title">
					<br/>
					<label>Kategori</label>
					<select class="form-control" name="kategori" required>
						<?php foreach($kategori as $kat) {?>
						<option value="<?php echo $kat['id_kat_berita']?>"><?php echo $kat['kat_berita']?></option>
						<?php } ?>
					</select>
					<label>Konten</label>
					<div style="margin-left:0">
						<textarea class="form-control" name="content" rows="20"></textarea>
						<!-- <label>Upload Gambar</label>
						<input class="col-md-8" type="file" name="image"> -->
					</div>
					

					<div style="padding:10px;margin-left:0">
						<input type="submit" name="publish" value="Publish" class="btn  btn-primary">
						<input type="submit" name="draft" value="Draft" class="btn">
					</div>
				</form>
			</div>
			<!--end of new-->

			<!--posted-->
			<div class="tab-pane"  id="aktif">
				<table class="table">
					<thead>
						<tr>
							<td><strong>No</strong></td>	
							<td><strong>Judul</strong></td>
							<td><strong>Last Edit</strong></td>	
							<td><strong>Author</strong></td>
							<td></td>						
						</tr>
					</thead>
					<tbody>
						<?php 
						$i =1;
						foreach($aktif as $akt) { 
							?>
							<tr>
								<td><?php echo $i ?></td>	
								<td><?php echo $akt['judul_berita'] ?></td>
								<td><?php echo $akt['tgl_update'] ?></td>	
								<td><?php echo $akt['id_user'] ?></td> <td><a href="#akt_<?php echo $akt['id_berita'] ?>" class="btn" data-toggle="modal">Edit</a>
								<a class="btn" href="<?php echo site_url();?><? echo '/admin/dashboard/del_post?id='.$akt['id_berita'] ?>" onclick="return confirm('Yakin hapus ?')">Hapus</a></td>	
							</tr>
							<!---->
								<div style="height:800px" class="modal fade" id="akt_<?php echo $akt['id_berita'] ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
							    <div class="modal-dialog">
							      <div class="modal-content">
							        <div class="modal-header">
							          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							          <h4 class="modal-title">Edit News</h4>
							        </div>
							        <div style="height:400px" class="modal-body">
							           <form class="form" action="<?php echo site_url('admin/dashboard/edit_post')?>" method="post" enctype="multipart/form-data">
										<input type="hidden" value="<?php echo $akt['id_berita'] ?>" name="id_berita">
										<label>Judul</label><br/>
										<input class="col-md-8" type="text" value="<?php echo $akt['judul_berita'] ?>" name="title"><br/><br/>
										<label>Kategori</label><br/>
										<select name="kategori" required>
											<?php foreach($kategori as $kat) {?>
											<option value="<?php echo $kat['id_kat_berita']?>"><?php echo $kat['kat_berita']?></option>
											<?php } ?>
										</select><br/><br/>
										<label>Konten</label><br/>
										<div style="margin-left:0" class="col-md-8">
											<textarea name="content" rows="20"><?php echo $akt['berita'] ?></textarea>
											<!-- <label>Upload Gambar</label>
											<input class="col-md-8" type="file" name="image"> -->
										</div>
										<div style="padding:10px;margin-left:0" class="col-md-8">
											<input type="submit" name="publish" value="Update" class="btn  btn-primary">
											<input type="submit" name="draft" value="Draft" class="btn">
										</div>
										</form>
										</br>
							        </div>
							        
							      </div><!-- /.modal-content -->
							    </div><!-- /.modal-dialog -->
							  </div><!-- /.modal -->
							<!---->
			<?php $i++; } ?>
		</tbody>
	</table>		     	
</div>
<!--end of posted-->

<!--draft-->
<div class="tab-pane" id="draft">
	<table class="table">
		<thead>
			<tr>
				<td><strong>No</strong></td>	
				<td><strong>Judul</strong></td>
				<td><strong>Last Edit</strong></td>	
				<td><strong>Author</strong></td>
				<td></td>						
			</tr>
		</thead>
		<tbody>
			<?php 
			$i =1;
			foreach($draft as $dra) { 
				?>
				<tr>
					<td><?php echo $i ?></td>	
					<td><?php echo $dra['judul_berita'] ?></td>
					<td><?php echo $dra['tgl_update'] ?></td>	
					<td><?php echo $dra['id_user'] ?></td>
					<td>
						<a href="#dras_<?php echo $dra['id_berita'] ?>" class="btn" data-toggle="modal">Edit</a>
						<a class="btn" href="<?php echo site_url();?><? echo '/admin/dashboard/del_post?id='.$dra['id_berita'] ?>" onclick="return confirm('Yakin hapus ?')">Hapus</a>
					</td>	
				</tr>
				<!---->
								<div style="height:800px" class="modal fade" id="dras_<?php echo $dra['id_berita'] ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
							    <div class="modal-dialog">
							      <div class="modal-content">
							        <div class="modal-header">
							          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							          <h4 class="modal-title">Edit News</h4>
							        </div>
							        <div style="height:400px" class="modal-body">
							           <form class="form" action="<?php echo site_url('admin/dashboard/edit_post')?>" method="post" enctype="multipart/form-data">
										<input type="hidden" value="<?php echo $dra['id_berita'] ?>" name="id_berita">
										<label>Judul</label><br/>
										<input class="col-md-8" type="text" value="<?php echo $dra['judul_berita'] ?>" name="title"><br/><br/>
										<label>Kategori</label><br/>
										<select name="kategori" required>
											<?php foreach($kategori as $kat) {?>
											<option value="<?php echo $kat['id_kat_berita']?>"><?php echo $kat['kat_berita']?></option>
											<?php } ?>
										</select><br/><br/>
										<label>Konten</label><br/>
										<div style="margin-left:0" class="col-md-8">
											<textarea name="content" rows="20"><?php echo $dra['berita'] ?></textarea>
											<!-- <label>Upload Gambar</label>
											<input class="col-md-8" type="file" name="image"> -->
										</div>
										<div style="padding:10px;margin-left:0" class="col-md-8">
											<input type="submit" name="publish" value="Update" class="btn  btn-primary">
											<input type="submit" name="draft" value="Draft" class="btn">
										</div>
										</form>
										</br>
							        </div>
							        
							      </div><!-- /.modal-content -->
							    </div><!-- /.modal-dialog -->
							  </div><!-- /.modal -->
							<!---->



					<?php $i++; } ?>
				</tbody>
			</table>
		</div>
		<!--end of draft-->

		<!--kategori-->
		<div class="col-md-9 tab-pane " id="kategori">
			<h4>Kategori</h4>    
			<hr/>
			<a data-toggle="modal" href="#addcategory">+tambah kategori</a>
			<table class="table">
				<thead>
					<tr>
						<td><strong>No.</strong></td>
						<td><strong>Kategori</strong></td>
						<td></td>
					</tr>
				</thead>
				<tbody>
					<?php $n=1; foreach($kategori AS $k) {?>
					<tr>
						<td><?php echo $n?></td>
						<td><?php echo $k['kat_berita']?></td>
						<td>
							<a data-toggle="modal" href="#editcategory-<?php echo $k['kat_berita']?>" class="btn btn-default">Edit</a>
							<a onclick="return confirm('Anda Yakin')" href="<?php echo site_url('admin/dashboard/deletepostcategory?id='.$k['id_kat_berita'])?>" class="btn btn-default">Delete</a>

						</td>
					</tr>

					<!--modal add kategori-->
					<div class="modal fade" id="editcategory-<?php echo $k['kat_berita']?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
						<div class="modal-dialog">
							<div class="modal-content">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
									<h4 class="modal-title">Edit Kategori</h4>
								</div>
								<div class="modal-body">

									<form method="POST" action="<?php echo site_url('admin/dashboard/editpostcategory')?>" role="form">
										<div class="form-group">
											<label for="exampleInputEmail1">Nama Kategori</label>
											<input name="nama" type="text" class="form-control" value="<?php echo $k['kat_berita']?>" required>
											<input name="id" type="hidden" value="<?php echo $k['id_kat_berita']?>">
										</div>

										<button type="submit" class="btn btn-default">Edit Kategori</button>
									</form>
								</div>
								<div class="modal-footer">
									<center><h6>Wk-Group</h6></center>
								</div>
							</div><!-- /.modal-content -->
						</div><!-- /.modal-dialog -->
					</div><!-- /.modal -->

					<?php $n++; } ?>
				</tbody>
			</table>
			<!--modal add kategori-->
			<div class="modal fade" id="addcategory" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							<h4 class="modal-title">Tambah Kategori</h4>
						</div>
						<div class="modal-body">
							
							<form method="POST" action="<?php echo site_url('admin/dashboard/addpostcategory')?>" role="form">
								<div class="form-group">
									<label for="exampleInputEmail1">Nama Kategori</label>
									<input name="nama" type="text" class="form-control" id="exampleInputEmail1" placeholder="Masukan Nama Kategori">
								</div>
								
								<button type="submit" class="btn btn-default">+ Tambah Kategori</button>
							</form>
						</div>
						<div class="modal-footer">
							<center><h6>Wk-Group</h6></center>
						</div>
					</div><!-- /.modal-content -->
				</div><!-- /.modal-dialog -->
			</div><!-- /.modal -->
			<!--end modal add kategori-->
		</div>
		<!--end of kategori-->

	</div>
</div>

</div>