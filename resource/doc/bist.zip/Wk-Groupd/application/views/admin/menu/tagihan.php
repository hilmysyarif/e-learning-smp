<div class="row-fluid">
	<div style="background-color: rgb(247, 245, 245)" class="col-md-2">
		<ul class="nav nav-pills nav-stacked">
			<li class="nav-header"><div style="background-color:#ff8c3f" class="top-menu-search">
				<strong style="color:#fff">Admin Menu</strong>
			</div></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/welcome">Homepage</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/post">Berita</a></li>
			
			<li><a href="<?php echo site_url()?>/admin/dashboard/bukutamu">Buku Tamu</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/barang">Barang</a></li>
			<li class="active"><a href="<?php echo site_url()?>/admin/dashboard/tagihan">Tagihan</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/pelanggan">Pelanggan</a></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/user">User</a></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/footer">Footer</a></li>
		</ul>
	</div>
	<div class="col-md-10">
		<div class="widget-title">
			<h2>data tagihan</h2>
			<p>Denda, tiap keterlambatan pembayaran Rp.20.000,- / hari</p>
		</div>	
		<div class="tabbable" > <!-- Only required for left/right tabs -->
			<ul class="nav nav-tabs">
				<li class="active"><a href="#barang" data-toggle="tab">Tagihan Belum Lunas</a></li>
				<li><a href="#kategori" data-toggle="tab">Tagihan Lunas</a></li>
			</ul>

			<!--search-->
			<br/>
			<div class="row">

				<div class="col-lg-6">
					<form method="post" action="<?php echo site_url()?>/admin/dashboard/tagihan">
						<div class="input-group">
						<input class="form-control input-xxlarge" id="appendedInputButton" name="keyword" type="text" placeholder="masukan id sewa / username">
							<span class="input-group-btn">
								<button class="btn" name="btn_search" type="submit">Cari</button>
							</span>

						</div><!-- /input-group -->
					</form>
				</div><!-- /.col-lg-6 -->
			</div><!-- /.row -->
			<br/>



			<div class="tab-content">

				<!-- daftar list tagihan
				yang belum lunas -->

				<div class="tab-pane active" id="barang">
					
					<table class="table">
						<thead>
							<tr>
								<td><strong>No</strong></td>
								<td><strong>Id Sewa</strong></td>
								<td><strong>Nama</strong></td>
								<td><strong>Id User</strong></td>
								<td><strong>Transaksi</strong></td>
								<td><strong>Jatuh Tempo</strong></td>
								<td><strong>Tgl Sewa</strong></td>
								<td><strong>Tgl Kembali</strong></td>
								<td><strong>Lama</strong></td>
								<td><strong>Status Pembayaran</strong></td>
								<td><strong>Harga Sewa</strong></td>
								<td><strong>Harga Denda</strong></td>
								<td></td>
								<td></td>
							</tr>
						</thead>
						<tbody>
							<?php 
							$i =1; 
							?>
							<?php foreach ($belumlunas as $bl): ?>
								<tr>
									<td><?php echo $i?></td>
									<td><?php echo $bl['id_sewa']?></td>
									<td><?php echo $bl['username']?></td>
									<td><?php echo $bl['id_user']?></td>
									<td><?php echo $bl['tgl_transaksi']?></td>
									<td><?php echo $bl['tgl_jatuhtempo']?></td>
									<td><?php echo $bl['tgl_sewa']?></td>
									<td><?php echo $bl['tgl_kembali']?></td>
									<td><?php echo $bl['lama']?></td>
									<td><?php 
										switch ($bl['status']) {
											case '0':
											echo '<p style="color:red">BELUM LUNAS</p>';
											break;
											case '1':
											echo '<p style="color:green">LUNAS</p>';
											break;
											default:
											echo "tidak ada status";
											break;
										}?></td>
										<td><?php echo $bl['harga_sewa']?></td>
										<td><?php echo $bl['denda']?></td>
										<td>
											<a class="btn" onclick="return confirm('Yakin id sewa : <?php echo $bl['id_sewa']; ?> sudah lunas?')" href="<?php echo site_url('admin/dashboard/jadi_lunas?id=')?><?php echo $bl['id_sewa'];?>">Lunas</a>
											<a class="btn" onclick="return confirm('Yakin Delete id sewa : <?php echo $bl['id_sewa']; ?>')" href="<?php echo site_url('admin/dashboard/deletetagihan?id=')?><?php echo $bl['id_sewa'];?>">Delete</a>
											
										</td>	
										</tr>
										<?php $i++; endforeach ?>
									</tbody>
								</table>		     	
							</div>


					<!-- daftar list tagihan 
					yang belum lunas -->

					<div class="tab-pane" id="kategori">
						
						<table class="table">
							<thead>
								<tr>
									<td><strong>No</strong></td>
									<td><strong>Id Sewa</strong></td>
									<td><strong>Nama</strong></td>
									<td><strong>Id User</strong></td>
									<td><strong>Transaksi</strong></td>
									<td><strong>Jatuh Tempo</strong></td>
									<td><strong>Tgl Sewa</strong></td>
									<td><strong>Tgl Kembali</strong></td>
									<td><strong>Lama</strong></td>
									<td><strong>Status Pembayaran</strong></td>
									<td><strong>Harga Sewa</strong></td>
									<td><strong>Harga Denda</strong></td>
									<td></td>
									<td></td>
								</tr>
							</thead>
							<tbody>
								<?php 
								$i =1; 
								?>
								<?php foreach ($sudahlunas as $bl): ?>
									<tr>
										<td><?php echo $i?></td>
										<td><?php echo $bl['id_sewa']?></td>
										<td><?php echo $bl['username']?></td>
										<td><?php echo $bl['id_user']?></td>
										<td><?php echo $bl['tgl_transaksi']?></td>
										<td><?php echo $bl['tgl_jatuhtempo']?></td>
										<td><?php echo $bl['tgl_sewa']?></td>
										<td><?php echo $bl['tgl_kembali']?></td>
										<td><?php echo $bl['lama']?></td>
										<td><?php 
											switch ($bl['status']) {
												case '0':
												echo '<p style="color:red">BELUM LUNAS</p>';
												break;
												case '1':
												echo '<p style="color:green">LUNAS</p>';
												break;
												default:
												echo "tidak ada status";
												break;
											}?></td>			
											<td><?php echo $bl['harga_sewa']?></td>
											<td><?php echo $bl['denda']?></td>								
											<td><a class="btn" onclick="return confirm('Yakin id sewa : <?php echo $bl['id_sewa']; ?> belum lunas?')" href="<?php echo site_url('admin/dashboard/batal_lunas?id=')?><?php echo $bl['id_sewa'];?>">Batal Lunas</a>
												<!-- <a class="btn" href="#">Pembatalan</a> -->
												<a class="btn" onclick="return confirm('Yakin Delete id sewa : <?php echo $bl['id_sewa']; ?>')" href="<?php echo site_url('admin/dashboard/deletetagihan?id=')?><?php echo $bl['id_sewa'];?>">Delete</a>
												<a class="btn" target="_blank" href="<?php echo site_url('pelanggan/pelanggan/detailtagihan_adm?id=')?><?php echo $bl['id_sewa'];?>&id_user=<?php echo $bl['id_user']?>">></a></td> 
												
											</tr>

											<?php $i++; endforeach ?>
										</tbody>
									</table>	
								</div>
							</div>



						</div>
					</div>
				</div>