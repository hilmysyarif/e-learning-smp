<div class="row-fluid">
	<div style="background-color: rgb(247, 245, 245)" class="col-md-2">
		<ul class="nav nav-pills nav-stacked">
			<li class="nav-header"><div style="background-color:#ff8c3f" class="top-menu-search">
				<strong style="color:#fff">Admin Menu</strong>
			</div></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/welcome">Homepage</a></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/post">Berita</a></li>
			
			<li><a href="<?php echo site_url()?>/admin/dashboard/bukutamu">Buku Tamu</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/barang">Barang</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/tagihan">Tagihan</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/pelanggan">Pelanggan</a></li>
			<li class="active" ><a href="<?php echo site_url()?>/admin/dashboard/user">User</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/footer">Footer</a></li>
		</ul>
	</ul>
</div>
<div class="col-md-10">
	<div class="widget-title">
		<h2>USER</h2>
	</div>	
	<div class="tabbable" > <!-- Only required for left/right tabs -->
		<ul class="nav nav-tabs">
			<li class="active"><a href="#aktif" data-toggle="tab">Aktif</a></li>
			<li ><a href="#banned" data-toggle="tab">Banned</a></li>
		</ul>
		<div class="tab-content">

		</br>
		<!-- Button trigger modal -->
		<?php if($this->session->userdata('username_admin') == 'admin') {
			echo '<a data-toggle="modal" href="#addadmin">+ Add User</a>';
		}
		?>	

		<!-- Modal -->
		<div class="modal fade" id="addadmin" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h4 class="modal-title">Add User</h4>
					</div>
					<div class="modal-body">
						<form method="post" action="<?php echo site_url('admin/dashboard/addadmin')?>">
							<div class="form-group">
								<label>username</label>
								<input name="username" class="form-control" type="text" >
							</div>
							<div class="form-group">
								<label>Fullname</label>
								<input name="fullname" class="form-control" type="text" >
							</div>
							<div class="form-group">
								<label>Email</label>
								<input name="email" class="form-control" type="email" >
							</div>
							<div class="form-group">
								<label>Password</label>
								<input name="password1" class="form-control" type="password" >
							</div>
							
							<center><button class="btn btn-defalt">+ Tambah User</button></center>
						</form>
					</div>

				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div><!-- /.modal -->

		<!--posted-->
		<div class="tab-pane active"  id="aktif">
			<table class="table">
				<thead>
					<tr>
						<td><strong>No</strong></td>
						<td><strong>Id</strong></td>
						<td><strong>Username</strong></td>		
						<td><strong>Nama</strong></td>
						<td><strong>Email</strong></td>								
						<td></td>						
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>1</td>
						<td>2</td>
						<td>admin</td>
						<td>admin</td>
						<td>admin@wkgroup.com</td>
						<td></td>
					</tr>
					<?php $i = 2; 
					foreach($aktif as $a) {?>
					<tr>
						<td><?php echo $i?></td>
						<td><?php echo $a['id_user']?></td>	
						<td><?php echo $a['username']?></td>		
						<td><?php echo $a['nama_leng']?></td>
						<td><?php echo $a['email']?></td>
						<?php if($this->session->userdata('username_admin') == 'admin') {?>
						<td>
							<a href="<?php echo site_url()?>/admin/dashboard/changeadmin?id=<?php echo $a['id_user']?>&status=banned" >Set Banned</a>
							|
							<a href="#editdata_<?php echo $a['id_user']?>" data-toggle="modal">Edit Data</a>

							<!--modal-->
							<!-- Modal -->
							<div class="modal fade" id="editdata_<?php echo $a['id_user']?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
								<div class="modal-dialog">
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
											<h4 class="modal-title">Edit Data User</h4>
										</div>
										<div class="modal-body">
											<form method="POST" class="form" action="<?php echo site_url('admin/dashboard/update_admin')?>">
												<div class="form-group">
													<label>username</label>
													<input name="username" class="form-control" type="text" value="<?php echo $a['username'] ?>">
												</div>
												<div class="form-group">
													<label>Fullname</label>
													<input name="fullname" class="form-control" type="text" value="<?php echo $a['nama_leng'] ?>">
												</div>
												<div class="form-group">
													<label>Email</label>
													<input name="email" class="form-control" type="email" value="<?php echo $a['email'] ?>">
												</div>
												<div class="form-group">
													<label>Password</label>
													<h5>*kosongkan jika tidak ingin ganti password</h5>
													<input name="new_password" class="form-control" type="password">
												</div>
												<input name="id_user" type="hidden" value="<?php echo $a['id_user']?>">
												<input name="old_password" type="hidden" value="<?php echo $a['password']?>">
												<center><button class="btn btn-defalt">Update data</button></center>
											</form>
										</div>
									</div><!-- /.modal-content -->
								</div><!-- /.modal-dialog -->
							</div><!-- /.modal -->
						</td>	
						<?php } ?>
					</tr>
					<?php $i++; } ?>
				</tbody>
			</table>		     	
		</div>
		<!--end of posted-->

		<!--draft-->
		<div class="tab-pane" id="banned">
			<table class="table">
				<thead>
					<tr>
						<td><strong>No</strong></td>
						<td><strong>Id</strong></td>
						<td><strong>Username</strong></td>		
						<td><strong>Nama</strong></td>
						<td><strong>Email</strong></td>								
						<td></td>					
					</tr>
				</thead>
				<tbody>						
					<?php $i = 1; 
					foreach($banned as $b) {?>
					<tr>
						<td><?php echo $i?></td>
						<td><?php echo $b['id_user']?></td>	
						<td><?php echo $b['username']?></td>		
						<td><?php echo $b['nama_leng']?></td>
						<td><?php echo $b['email']?></td>
						<?php if($this->session->userdata('username_admin') == 'admin') {?>
						<td>
							<a href="<?php echo site_url()?>/admin/dashboard/changeadmin?id=<?php echo $b['id_user']?>&status=aktif" >Set Aktif
							</a>
							|
							<a href="<?php echo site_url()?>/admin/dashboard/del_admin?id=<?php echo $b['id_user']?>" >Delete</a>
						</td>	
						<?php } ?>
					</tr>
					<?php $i++; } ?>
				</tbody>
			</table>
		</div>
		<!--end of draft-->

	</div>
</div>

</div>