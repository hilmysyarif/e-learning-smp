<div class="row-fluid">
	<div style="background-color: rgb(247, 245, 245)" class="col-md-2">
		<ul class="nav nav-pills nav-stacked">
			<li class="nav-header"><div style="background-color:#ff8c3f" class="top-menu-search">
			<strong style="color:#fff">Admin Menu</strong>
			</div></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/welcome">Homepage</a></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/post">Berita</a></li>
			
			<li><a href="<?php echo site_url()?>/admin/dashboard/bukutamu">Buku Tamu</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/barang">Barang</a></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/tagihan">Tagihan</a></li>
			<li class="active"><a href="<?php echo site_url()?>/admin/dashboard/pelanggan">Pelanggan</a></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/user">User</a></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/footer">Footer</a></li>
		</ul>
	</ul>
</div>
<div class="col-md-10">
	<div class="widget-title">
		<h2>PELANGGAN</h2>
	</div>	
	<div class="tabbable" > <!-- Only required for left/right tabs -->
		<ul class="nav nav-tabs">
			<li class="active"><a href="#aktif" data-toggle="tab">Aktif</a></li>
			<li ><a href="#banned" data-toggle="tab">Banned</a></li>
		</ul>
		<div class="tab-content">

			<!--posted-->
			<div class="tab-pane active"  id="aktif">
				<table class="table">
					<thead>
						<tr>
							<td><strong>No</strong></td>
							<td><strong>Id</strong></td>
							<td><strong>Username</strong></td>		
							<td><strong>Nama</strong></td>
							<td><strong>Email</strong></td>	
							<td><strong>Kota</strong></td>
							<td><strong>Alamat lengkap</strong></td>
							<td><strong>Id bank</strong></td>
							<td><strong>No Rek.</strong></td>
							<td></td>						
						</tr>
					</thead>
					<tbody>
						<?php $i = 1; 
						foreach($aktif as $a) {?>
						<tr>
							<td><?php echo $i?></td>
							<td><?php echo $a['id_user']?></td>	
							<td><?php echo $a['username']?></td>		
							<td><?php echo $a['nama_leng']?></td>
							<td><?php echo $a['email']?></td>
							<td><?php echo $a['kota']?></td>
							<td><?php echo $a['alamat_leng']?></td>
							<td><?php echo $a['id_bank']?></td>
							<td><?php echo $a['no_rek']?></td>
							<td>
							<a href="<?php echo site_url()?>/admin/dashboard/changeuser?id=<?php echo $a['id_user']?>&status=banned" class="btn">set banned
							</a></td>	
						</tr>
						<?php $i++; } ?>
					</tbody>
				</table>		     	
			</div>
			<!--end of posted-->

			<!--draft-->
			<div class="tab-pane" id="banned">
				<table class="table">
					<thead>
						<tr>
							<td><strong>No</strong></td>
							<td><strong>Id</strong></td>
							<td><strong>Username</strong></td>		
							<td><strong>Nama</strong></td>
							<td><strong>Email</strong></td>	
							<td><strong>Kota</strong></td>
							<td><strong>Alamat lengkap</strong></td>
							<td><strong>Id bank</strong></td>
							<td><strong>No Rek.</strong></td>
							<td></td>						
						</tr>
					</thead>
					<tbody>
						<?php $i = 1; 
						foreach($banned as $b) {?>
						<tr>
							<td><?php echo $i?></td>
							<td><?php echo $b['id_user']?></td>	
							<td><?php echo $b['username']?></td>		
							<td><?php echo $b['nama_leng']?></td>
							<td><?php echo $b['email']?></td>
							<td><?php echo $b['kota']?></td>
							<td><?php echo $b['alamat_leng']?></td>
							<td><?php echo $b['id_bank']?></td>
							<td><?php echo $b['no_rek']?></td>
							<td>
							<a href="<?php echo site_url()?>/admin/dashboard/changeuser?id=<?php echo $b['id_user']?>&status=aktif" class="btn">Set aktif</a>
							<a onclick="return confirm('Anda Yakin')" href="<?php echo site_url()?>/admin/dashboard/deleteuser?id=<?php echo $b['id_user']?>&status=aktif" class="btn">Delete</a>
							</td>	
						</tr>
						<?php $i++; } ?>
					</tbody>
				</table>
			</div>
			<!--end of draft-->

		</div>
	</div>

</div>