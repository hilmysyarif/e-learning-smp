<div class="row-fluid">
	<div style="background-color: rgb(247, 245, 245)" class="col-md-2">
		<ul class="nav nav-pills nav-stacked">
			<li class="nav-header"><div style="background-color:#ff8c3f" class="top-menu-search">
				<strong style="color:#fff">Admin Menu</strong>
			</div></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/welcome">Homepage</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/post">Berita</a></li>
			
			<li><a href="<?php echo site_url()?>/admin/dashboard/bukutamu">Buku Tamu</a></li>
			<li class="active"><a href="#">Barang</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/tagihan">Tagihan</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/pelanggan">Pelanggan</a></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/user">User</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/footer">Footer</a></li>
		</ul>
	</div>
	
	<div class="col-md-10">
		<div class="widget-title"><h2>data barang</h2></div>	
		<div class="tabbable" > <!-- Only required for left/right tabs -->
			<ul class="nav nav-tabs">
				<li class="active"><a href="#barang" data-toggle="tab">Semua Produk</a></li>
				<li><a href="#kategori" data-toggle="tab">Kategori Produk</a></li>
			</ul>

			<!--search-->
			<br/>
			<div class="row">
			
				<div class="col-lg-6">
					<form method="post" action="<?php echo site_url()?>/admin/dashboard/barang">
					<div class="input-group">
						
							<input class="form-control" id="appendedInputButton" name="keyword" type="text" class="form-control" placeholder="masukan id barang atau nama barang">
							<span class="input-group-btn">
								<button type="submit" name="btn_search" class="btn btn-default" type="button">Cari</button>
							</span>
						
					</div><!-- /input-group -->
					</form>
				</div><!-- /.col-lg-6 -->
			</div><!-- /.row -->
			<br/>
			<div class="tab-content">
				<!--data barang-->
				<div class="tab-pane active" id="barang">

					<table class="table">
						<thead>
							<tr>
								<td><strong>No</strong></td>
								<td><strong>Id</strong></td>
								<td><strong>Nama Barang</strong></td>
								<td><strong>Deskripsi Barang</strong></td>
								<td><strong>Id Kategori</strong></td>
								<td><strong>Stok Total</strong></td>
								<td><strong>disewa</strong></td>
								<td><strong>Stok Sisa</strong></td>
								<td><strong>Harga / unit</strong></td>
								<td><strong>Image</strong></td>
								<td></td>
								<td></td>
							</tr>
						</thead>
						<tbody>
							<?php 
							$i =1; 
							?>
							<a href="#tambahbarang" data-toggle="modal">+ Tambah Barang</a>
							<?php foreach($view as $key) {?>
							<tr>
								<td><?php echo $i?></td>
								<td><?php echo $key['id_barang']?></td>
								<td><?php echo $key['nama_barang']?></td>
								<td><?php echo $key['des_barang']?></td>
								<td><?php echo $key['id_kat_barang']?></td>
								<td><?php echo $key['stok_total']?></td>
								<td><?php echo $key['disewa']?></td>
								<td><?php echo $key['stok_sisa']?></td>
								<td><?php echo $key['harga']?></td>
								<td><a class="btn" href="<?php echo base_url()?>images/barang/<?php echo $key['pic_brg']?>">Lihat Gambar</a>
									<a class="btn" href="#edit_<?php echo $key['id_barang']?>" data-toggle="modal">Edit</a>
									<a class="btn" onclick="return confirm('Yakin hapus : <?php echo $key['nama_barang']; ?>?')" href="<?php echo site_url()?>/admin/dashboard/del_brg?id_brg=<?php echo $key['id_barang']?>" >Hapus</a></td>
								</tr>

								<!--modal edit barang-->
								<!-- Modal -->
								<div id="edit_<?php echo $key['id_barang']?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
									<div style="color:#fff" class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
										<h3 id="myModalLabel">Edit barang id : <?php echo $key['id_barang']?></h3>
									</div>

									<div style="background-color:#ECECEC;height:auto" class="modal-body">

										<div style="width:60%">
										<form style="60%" enctype="multipart/form-data" class="form-horizontal" method="post" action="<?php echo site_url('admin/dashboard/upd_brg?id=')?><?php echo $key['id_barang']?>">

											<div class="control-group">
												<label class="control-label">Kategori :</label> 
												<div class="controls"><select name="kat" class="form-control input-xlarge" required>
													<?php foreach ($kat as $ktg) { ?>							
													<option value='<?php echo $ktg['id_kat_barang']; ?>'><?php echo $ktg['des_kat_brg']; ?></option>
													<?php } ?>	</select>
												</div>
											</div>

											<div class="control-group">
												<label class="control-label">Nama Barang :</label>
												<div class="controls">
													<input style="width:95%" type="text" name="nama_brg" class="form-control input-xlarge" value="<?php echo $key['nama_barang'] ?>" required>
												</div>										
											</div>

											<div class="control-group">
												<label class="control-label">Deskripsi Barang :</label>
												<div class="controls">
													<textarea style="width:95%" name="des_brg" class="form-control input-xlarge"  required><?php echo $key['des_barang'] ?></textarea>
												</div>
											</div>

											<div class="control-group">
												<label class="control-label">Stok Total :</label>
												<div class="controls">
													<input type="text" name="stok" class="form-control input-xlarge" value="<?php echo $key['stok_total'] ?>" required>
												</div>
											</div>

											<div class="control-group">
												<label class="control-label">Stok Disewa :</label>
												<div class="controls">
													<input type="text" name="disewa" class="form-control input-xlarge" value="<?php echo $key['disewa']?>" required>
												</div>
											</div>

											<div class="control-group ">
												<div class="input-prepend input-append">
													<div class="controls"><col-md- class="add-on">Rp.</col-md-><input class="form-control" style="width:95%" type="text" name="harga" value="<?php echo $key['harga'] ?>" required><col-md- class="add-on">/ unit</col-md-></div>
												</div>
											</div>

											<div >
												<img style="width:200px" src="<?php echo base_url('images/barang/'.$key['pic_brg'])?>" />
											</div>
											<br/>
											<p>Ubah gambar : </p>
											<div class="control-group ">
												<div class="input-prepend input-append">
													<div class="controls"><input class="form-control" style="width:95%" type="file" name="gambar"></div>
												</div>
											</div>
											<input type="hidden" name="gambarlama" value="<?php echo $key['pic_brg'] ?>" />

										<!-- <div class="control-group">
											<label class="control-label">Upload foto :</label>
											<div class="controls"><input type="file" name="pic_brg" value="<?php echo $key['pic_brg'] ?>" class="input-xlarge" ></div>			
										</div> -->

											<div class="control-group">
												<label class="control-label"></label>
												<div class="controls"><input type="submit" value="Update Barang" class="btn"></div>		
											</div>

									</form>
									</div>

								</div>
							</div>
							<!--end of modal edit barang-->
							<?php $i++?>
							<?php } ?>
						</tbody>
					</table>		     	
				</div>


				<!--data kategori-->
				<div class="tab-pane" id="kategori">
					<a style="float:left" href="#addkat" data-toggle="modal" >+ Tambah Kategori</a>
					<table style="float:left" class="table">						
						<thead>
							<tr>
								<td><strong>No</strong></td>
								<td><strong>Id Kategori</strong></td>
								<td><strong>Nama Kategori</strong></td>
								<td><strong>Deskripsi</strong></td>
								<td></td>
								<td></td>
							</tr>
						</thead>
						<tbody>
							<?php $j=1;?>
							<?php foreach ($kat as $ktg) { ?>
							<tr>
								<td><?php echo $j ?></td>
								<td><?php echo $ktg['id_kat_barang'] ?></td>
								<td><?php echo $ktg['des_kat_brg'] ?></td>
								<td><?php echo $ktg['det_kat_brg'] ?></td>
								<td><a class="btn" href="#editkat_<?php echo $ktg['id_kat_barang'] ?>" data-toggle="modal">edit</a></td>
								<td><a onclick="return confirm('Anda Yakin')" class="btn" href="<?php echo site_url('admin/dashboard/delcatbrg?id='.$ktg['id_kat_barang'])?> " data-toggle="modal">delete</a></td>
							</tr>
							<!-- Modal Edit Kategori -->
							<div id="editkat_<?php echo $ktg['id_kat_barang'] ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
								<div style="color:#fff" class="modal-header">
									<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
									<h3 id="myModalLabel">Edit kategori, id : <?php echo $ktg['id_kat_barang'] ?></h3>
								</div>
								<div style="background-color:#ECECEC;height:auto"  class="modal-body">

									<div style="width:60%">
									<form class="form-horizontal" method="post" action="<?php echo site_url('admin/dashboard/upd_kat')?>">
										<div class="control-group">
											<input name="id" type="hidden" value="<?php echo $ktg['id_kat_barang']?>" required>
											<label class="control-label" for="inputEmail">Kategori :</label>
											<div class="controls">
												<input class="form-control" style="width:95%" name="nama_kat" type="text" value="<?php echo $ktg['des_kat_brg']?>" required>
											</div>
										</div>
										<div class="control-group">
											<label class="control-label" for="inputPassword">Deskripsi Kategori :</label>
											<div class="controls">
												<textarea class="form-control" style="width:95%" name="des_kat" required><?php echo $ktg['det_kat_brg']?></textarea>
											</div>
										</div>
										<div class="control-group">
											<div class="controls">
												<button type="submit" class="btn">Update Kategori</button>
											</div>
										</div>
									</form>
									</div>

								</div>
								
							</div>
							<?php $j++ ?>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>

			<!--modal tambah kategori-->
			<div id="addkat" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				<div style="color:#ffffff" class="modal-header">
					<button style="color:#ffffff" type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
					<h3 id="myModalLabel">Tambah Kategori</h3>
				</div>
				<div style="background-color:#ECECEC;height:auto" class="modal-body">

					<form style="width:60%" class="form-horizontal" method="post" action="<?php echo site_url('admin/dashboard/add_kat')?>">
						<div  class="control-group">
							<label class="control-label" for="inputEmail">Kategori :</label>
							<div class="controls">
								<input class="form-control" style="width:95%" name="nama_kat" type="text" placeholder="nama kategori" required>
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="inputPassword">Deskripsi Kategori :</label>
							<div class="controls">
								<textarea class="form-control" style="width:95%" name="des_kat" placeholder="deskripsi kategori" required></textarea>
							</div>
						</div>
						<br/>
						<div class="control-group">
							<div class="controls">
								<button type="submit" class="btn">+ tambah kategori</button>
							</div>
						</div>
					</form>

				</div>
			</div>

			<!-- Modal Tambah Barang -->


			<div id="tambahbarang" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				<div style="color:#ffffff" class="modal-header">
					<button style="color:#ffffff" type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
					<h3 id="myModalLabel">Tambah Barang</h3>
				</div>
				<div style="background-color:#ECECEC;height:auto" class="modal-body">
					
					<form style="width:60%" enctype="multipart/form-data" class="form-horizontal" method="post" action="<?php echo site_url('admin/dashboard/add_brg')?>">
						<div class="control-group">
							<label class="control-label">Kategori :</label> 
								<div class="controls"><select name="kat" class="form-control input-xlarge" required>
								<?php foreach ($kat as $ktg) {
									?>							
									<option value='<?php echo $ktg['id_kat_barang']; ?>'><?php echo $ktg['des_kat_brg']; ?></option>
									<?php } ?>	</select></div>
								</div>

									<div class="control-group">
										<label class="control-label">Nama Barang :</label>
										<div class="controls">
										<input class="form-control" type="text" name="nama_brg" class="input-xlarge" required></div>
									</div>

									<div class="control-group">
										<label class="control-label">Deskripsi Barang :</label>
										<div class="controls"><textarea  name="des_brg" class="form-control input-xlarge" required></textarea></div>
									</div>

									<div class="control-group">
										<label class="control-label">Stok Total :</label>
										<div class="controls"><input min="0" type="number" name="stok_total" class=" form-control input-xlarge" required></div>
									</div>

									<div class="control-group ">
										<div class="input-prepend input-append">
											<div class="controls"><col-md- class="add-on">Rp.</col-md-><input class="form-control" type="text" name="harga" required><col-md- class="add-on">/ unit</col-md-></div>
										</div>
									</div>

									<div class="control-group">
										<label class="control-label">Upload foto :</label>
										<div class="controls"><input type="file" name="pic_brg" class="form-control input-xlarge"></div>			
									</div>

									<div class="control-group">
										<label class="control-label"></label>
										<div class="controls"><input type="submit" value="+ tambah barang" class="btn"></div>		
									</div>

								</form>


							</div>
							<div style="color:#fff">
								<center> Sewa kami | Rajanya Sewa</center>
							</div>
						</div>



					</div>
				</div>
			</div>