<div class="row-fluid">
	<div style="background-color: rgb(247, 245, 245)" class="col-md-2">
		<ul class="nav nav-pills nav-stacked">
			<li class="nav-header"><div style="background-color:#ff8c3f" class="top-menu-search">
			<strong style="color:#fff">Admin Menu</strong>
			</div></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/welcome">Homepage</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/post">Berita</a></li>
			
			<li><a href="<?php echo site_url()?>/admin/dashboard/bukutamu">Buku Tamu</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/barang">Barang</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/tagihan">Tagihan</a></li>
			<li><a href="<?php echo site_url()?>/admin/dashboard/pelanggan">Pelanggan</a></li>
			<li ><a href="<?php echo site_url()?>/admin/dashboard/user">User</a></li>
			<li class="active" ><a href="<?php echo site_url()?>/admin/dashboard/footer">Footer</a></li>
		</ul>
	</div>
	<div class="col-md-10">
		
		<div class="widget-title"><h2>Footer Management</h2></div>	
		<div class="row">
			<h5>Sosial Media</h5>
			<?php foreach($sosmed as $sm) { ?>
			<div class="col-md-3">
				<form method="POST" action="<?php echo site_url('admin/dashboard/edit_sosmed')?>">
				<strong><?php echo $sm['nama']?></strong>
				<input class="form-control" name="id" type="hidden" value="<?php echo $sm['id_profile']?>">
				<label>Nama : </label><input class="form-control" name="des" type="text" value="<?php echo $sm['deskripsi']?>">
				<label>Link : </label><input class="form-control" name="link" type="text" value="<?php echo $sm['link']?>">
				<button name="btn" value="edit" type="submit" class="btn btn-primary">edit</button>
				</form>
			</div>
			<?php } ?>
		</div>
		<hr width="80%"/>
		<div class="row">
			<h5>Kontak</h5>
			<?php foreach ($kontak as $k) { ?>
				<div class="col-md-3">
					<form method="POST" action="<?php echo site_url('admin/dashboard/edit_kontak')?>">
					<strong><?php echo $k['nama']?></strong>
					<input class="form-control" name="id" type="hidden" value="<?php echo $k['id_profile']?>">
					<label>Jenis : </label><input class="form-control" name="des" type="text" value="<?php echo $k['deskripsi']?>">
					<label>Detail : </label><input class="form-control" name="link" type="text" value="<?php echo $k['link']?>">
					<button name="btn" value="edit" type="submit" class="btn btn-primary">edit</button>
					</form>
				</div>
			<?php } ?>
		</div>
		<hr width="80%"/>
		<div class="row">
			<h5>Metode Pembayaran</h5>
			<?php foreach ($bank as $b) { ?>
				<div class="col-md-3">
					<form method="POST" action="<?php echo site_url('admin/dashboard/edit_pembayaran')?>">
					<input class="form-control" name="id" type="hidden" value="<?php echo $b['id_profile']?>">
					<strong><?php echo $b['nama']?></strong>
					<label>No.Rek : </label><input class="form-control" name="link" type="text" value="<?php echo $b['link']?>">
					<button name="btn" value="edit" type="submit" class="btn btn-primary">edit</button>
					</form>
				</div>
			<?php } ?>
		</div>
	</div>
</div>