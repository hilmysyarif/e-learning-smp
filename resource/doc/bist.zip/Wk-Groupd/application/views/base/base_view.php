<?php $this->load->view('public/header')?>
<?php $this->load->view($template_anak); ?>
<?php $this->load->view('public/footer')?>