<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="id">
<header>
<title>Detail Sewa</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>bootstrap/css/bootstrap.css" media="screen"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>bootstrap/css/bootstrap-responsive.css"media="screen" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>style/public.css"media="screen" />
	<script type="text/javascript" src="<?php echo base_url();?>bootstrap/js/jquery.js?>"></script>		
</header>

	<body>
		<div class="container">
			<div style="border-top : 20px solid #0088cc"   class="row">
				<div class="col-md-9"><h3>Tagihan Sewakami</h3></div>
				<div class="col-md-3"><p style="margin-top:5px">tagihan dibuat pada : <?php echo date('d-m-Y');?> | <a onclick="window.print();" href="#print">Cetak</a></p></div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<p>Tagihan ini kami berikan kepada saudara/i <strong><?php echo $user['nama_leng']?></strong>, dengan detail sebagai berikut :</p>
				</div>
			</div>

			<div class="row">
				<div class="col-md-6">
					<?php
					// //perintah otomatis untuk menghitung denda dan biaya total
					// //lihat selisih jatuh tempo dengan tgl sekarang, jika >0 maka denda mulai dihitung
					

					?>

					<h4>Detail Tagihan</h4>
					<p>
					<strong>Id sewa : </strong><?php echo $tagihan['id_sewa'] ?> <br/>
					<strong>Jatuh Tempo : </strong><?php echo $tagihan['tgl_jatuhtempo'] ?> <br/>
					<strong>Masa Sewa : </strong><?php echo $tagihan['tgl_sewa'].' s/d '.$tagihan['tgl_kembali'] ?> <br/>
					<strong>Lama Sewa : </strong><?php echo $tagihan['lama'] ?> hari <br/>
					<strong>Status Pembayaran : 
					<?php 
					//jika 0 belum lunas, jika 1 lunas
					switch ($tagihan['status']) {
						case '0':
							echo '<strong style="color:red">Belum Lunas</strong>';
							break;
						case '1' :
							echo '<strong style="color:green">Lunas</strong>';
							break;
						default:
							echo "Belum lunas";
							break;
					}?> </strong>
					</p>
				</div>

				<div class="col-md-6">
					<h4>Data Pelanggan</h4>
					<p>
						<strong>Id user : </strong> <?php echo $user['id_user'].'-'.$user['username']?><br/>
						<strong>Nama lengkap : </strong> <?php echo $user['nama_leng']?><br/>
						<strong>Kota / kabupaten: </strong> <?php echo $user['kota']?><br/>
						<strong>Alamat lengkap : </strong> <?php echo $user['alamat_leng']?><br/>
						<strong>Email : </strong> <?php echo $user['email']?><br/>
					</p>
				</div>
			</div>

			<div class="row">
				<div class="col-md-12">
					
					<table class="table">
						<thead>
							<tr>
								<td>No.</td>
								<td>Barang</td>
								<td>Jumlah</td>
								<td>Subtotal</td>
								<td>Status Barang</td>
							</tr>
						</thead>
						<tbody>	
							<?php $i =1; $bayar = 0; ?>
							<?php $s = $tagihan['id_sewa']?>
							<?php foreach ($dettagihan as $dt) { ?>
							<tr>
								<td><?php echo $i;?></td>
								<td><?php echo $dt['nama_barang'];?></td>
								<td><?php echo $dt['jumlah_brg'];?></td>
								<td>Rp. <?php echo $dt['subtotal'];?>,00</td>
								<td>
									<?php 
									//jika yang buka adalah admin
									if (isset($this->session->userdata['status_admin'])) {
										//jika yang buka adalah pelanggan
										switch ($dt['status']) {

											case '0': //hanya berlaku satu kali , karena case ini tidak mengurangi atau menambah jumlah barang yang dipinjam di tabel barang
											echo '<p>DIGUDANG <a href="'.site_url().'/admin/dashboard/ubah_statusbarang?usr='.$user['id_user'].'&id='.$s.'&status=1&brg='.$dt['id_barang'].'&count='.$dt['jumlah_brg'].'"> ubah</a></p>';
											break;

											case '1': //hanya berlaku satu kali , karena case ini tidak mengurangi atau menambah jumlah barang yang dipinjam di tabel barang
											echo '<p>DIPINJAM <a href="'.site_url().'/admin/dashboard/ubah_statusbarang?usr='.$user['id_user'].'&id='.$s.'&status=2&brg='.$dt['id_barang'].'&count='.$dt['jumlah_brg'].'"> ubah</a></p>';
											break;	

											case '2': //merubah link sekaligus jumlah barang terpinjam di tabel barang
											echo '<p>DIGUDANG <a href="'.site_url().'/admin/dashboard/ubah_statusbarang?usr='.$user['id_user'].'&id='.$s.'&status=3&brg='.$dt['id_barang'].'&count='.$dt['jumlah_brg'].'"> ubah</a></p>';
											break;

											case '3': //merubah link sekaligus jumlah barang terpinjam di tabel barang
											echo '<p>DIPINJAM <a href="'.site_url().'/admin/dashboard/ubah_statusbarang?usr='.$user['id_user'].'&id='.$s.'&status=2&brg='.$dt['id_barang'].'&count='.$dt['jumlah_brg'].'"> ubah</a></p>';
											break;										
											
											default:
											echo '<p>TIDAK ADA STATUS</p>';
											break;
										}
									} else {
										//jika yang buka adalah pelanggan
										switch ($dt['status']) {
											case '0':
											echo '<p>DIGUDANG</p>';
											break;

											case '1':
											echo '<p>DIPINJAM</p>';
											break;

											case '2':
											echo '<p>DIGUDANG</p>';
											break;

											case '3':
											echo '<p>DIPINJAM</p>';
											break;
											
											default:
											echo '<p>TIDAK ADA STATUS</p>';
											break;
										}
									}
									?>
								</td>
							</tr>
							<?php $i++; $bayar = $bayar + $dt['subtotal'];  ?>
							<?php } ?>
						</tbody>
					</table>
					<div style="float:right">
						<h4>Sewa Barang : Rp. <?php echo $tagihan['harga_sewa']?>,00 x <?php echo $tagihan['lama']?> hari</h4>
						<h4>Denda : Rp. <?php echo  $tagihan['denda']?>,00</h4>
						<h4>---------------------------------------------------------------------- +</h4>
						<h4>Total Bayar : Rp. <?php echo  $tagihan['harga_total']?>,00</h4>
					</div>
				</div>
			</div>
		</div>
	</body>

	<footer>
		<div class="container">
		<div class="row">
		<center><p class="col-md-12" style="border-top :1px solid rgb(209, 209, 209)">Terimakasih atas kepercayaan anda kepada kami</p></center>
		</div>
		</div>
	</footer>
</html>