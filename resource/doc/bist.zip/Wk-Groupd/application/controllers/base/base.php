<?php 

if ( ! defined('BASEPATH')) 
	exit('No direct script access allowed');

//membuat sebuah class untuk base
class base extends CI_Controller {
	//membuat construktor
	public function __construct() {
		parent::__construct();
        //load model m_barang agar bisa dipakai disemua controller lain
		$this->load->model('m_barang');
		$this->load->model('m_kategori');
		$this->load->model('m_user');
		$this->load->model('m_tagihan');
		$this->load->model('m_post');
		$this->load->model('m_footer');//data footer
		$this->load->model('m_admin'); //khusus untuk admin

	}

	//membuat sebuah fungsi display untuk digunakan sebagai base view untuk display
	public function display ($view_anak = "", $data=""){
		$tgl = date('d');
		$minutes = date('m');
		$second = date('s');
		$key = $tgl * $minutes * $second ;
		//urusan captcha
		$vals = array(
			'word' => $key,
	        'img_path'   => './captcha/',
	        'img_url'    => base_url().'captcha/',
	        'img_width'  => '200',
	        'img_height' => 30,
	        'border' => 0,
	        'expiration' => 7200
        );
  		// create captcha image
        $cap = create_captcha($vals);
		// store image html code in a variable
        $data['image'] = $cap['image'];
        // store the captcha word in a session
        $this->session->set_userdata('mycaptcha', $cap['word']);
		//memasukkan nilai yang ada di $view_anak kedalam sebuah array $data['template_anak'] sehingga ketika di view dipanggil template_anak
		$data['template_anak'] = $view_anak;
		//membuat data yang berisi hasil select kategori dari database
		$data['kat'] = $this->m_kategori->get_kat();
		//mengambil untuk data di social network
		$data['sosmed'] = $this->m_footer->sosmed();
		//mengambil data kontak
		$data['kontak']= $this->m_footer->kontak();
		//mengambil data bank
		$data['bank']= $this->m_footer->bank();
		//memanggil view base yaitu "base_view" dengan menambahkan parameter $data
		$this->load->view('display/base/base_view', $data);
	}

	//membuat sebuah fungsi displayadmin yang akan digunakan untuk base view untuk admin dengan parameter $view_admin dan $data
	public function displayadmin ($view_admin = "", $data=""){
		//membuat array yang akan digunakan untuk memanggil parameter dan dimasukkan kedalam view base dariadmin	
		$data['template_admin'] = $view_admin;
		//memanggil view base_admin yang akan menampilkan base view dari admin dengan menambahkan parameter $data
		$this->load->view('base/base_admin', $data);
	}
}