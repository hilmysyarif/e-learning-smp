<?php if (!defined('BASEPATH')) exit ('No direct script allowed');

//memanggil file base yang digunakan untuk menurunkan 
require_once 'application/controllers/base/base.php';

class dashboard extends base {

	//membuat construktor
	public function __construct() {
		parent::__construct();
        //memanggil library form_validation
		$this->load->library('form_validation');
		$this->m_tagihan->lewat_batas();//merubah tanggal sekarang - selisih denda
		$this->m_barang->cek_sisa();//cek sisa barang
	}

	//
	//view line
	//

	function index() {
		
		$this->displayadmin('admin/login');
	}

	function welcome() {
		if($this->session->userdata('status_admin')== 'banned') {
			echo ("<SCRIPT LANGUAGE='JavaScript'>
			window.alert('Anda telah dibanned');
			window.location.href='".site_url('admin/dashboard/logout')."';
			</SCRIPT>");
		} else {
			if(empty($this->session->userdata['status_admin'])) {
				$this->displayadmin('admin/login');
			} else {
				$data['slidder'] = $this->m_post->get_slidder();		
				$this->displayadmin('admin/dashboard', $data);
			}	  	
		}
		
	}

	function barang() {
		if(empty($this->session->userdata['status_admin'])) {
			$this->displayadmin('admin/login');
		} else {
			if(isset($_POST['btn_search'])) {
				$keyword = $this->input->post('keyword');
				//membuat data yang berisi hasil select kategori dari db
				$data['kat'] = $this->m_kategori->get_kat();
				$data['view'] = $this->m_barang->search_barang($keyword);
				$this->displayadmin('admin/search/search-barang', $data);
				
			} else {
				//membuat data yang berisi hasil select kategori dari db
				$data['kat'] = $this->m_kategori->get_kat();
				//membuat data yang berisi hasil select barang dari db
				$data['view'] = $this->m_barang->get_brg(1000000,0);
				//tampilan view
				$this->displayadmin('admin/menu/barang',$data);
			}
		}
	}

	function tagihan(){
		if(empty($this->session->userdata['status_admin'])) {
			$this->displayadmin('admin/login');
		} else {

			if(isset($_POST['btn_search'])) {
				$keyword = $this->input->post('keyword');
				$data['view'] = $this->m_tagihan->search_tagihan($keyword);
				//membuat data yang berisi hasil select kategori dari db
				$this->displayadmin('admin/search/search-tagihan', $data);

			} else {
				//daftar user belum lunas
				$data['belumlunas'] = $this->m_admin->get_belumlunas();
				//daftar yang sudah lunas
				$data['sudahlunas'] = $this->m_admin->get_sudahlunas();
				$this->displayadmin('admin/menu/tagihan', $data);
			}
			
		}
	}

	function post(){
		if(empty($this->session->userdata['status_admin'])) {
			$this->displayadmin('admin/login');
		} else {

			$data['kategori'] = $this->m_post->get_kat_post();
			$data['draft'] = $this->m_post->get_draft_post();
			$data['aktif'] = $this->m_post->get_active_post();
			$this->displayadmin('admin/menu/post', $data);
		}
	}

	function addpostcategory(){
		//get post data
		$nama = $this->input->post('nama');
		if($this->m_post->add_category($nama)) { //jika berhsil memasukan data
			echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('Sukses Tambah Kategori');
					window.location.href='../dashboard/post';
				</SCRIPT>");
		} else { //jika gagal memasukan data
			echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('Gagal Tambah Kategori');
					window.location.href='../dashboard/post';
				</SCRIPT>");
		}	

	}

	//edit kategori berita
	function editpostcategory(){
		$id = $this->input->post('id'); //get kategori id
		$name = $this->input->post('nama'); //get category name
		$params = array($name, $id);
		if($this->m_post->edit_category($params)) { //jika berhsil memasukan data
			echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('Sukses Sukses Kategori');
					window.location.href='../dashboard/post';
				</SCRIPT>");
		} else { //jika gagal memasukan data
			echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('Gagal Edit Kategori');
					window.location.href='../dashboard/post';
				</SCRIPT>");
		}	
			

	}

	//delete kategori berita
	function deletepostcategory(){
		$id = $this->input->get('id');
		if($this->m_post->del_kat_berita($id)) { //jika berhsil memasukan data
			echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('Sukses Hapus Kategori');
					window.location.href='../dashboard/post';
				</SCRIPT>");
		} else { //jika gagal memasukan data
			echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('Gagal Hapus Kategori');
					window.location.href='../dashboard/post';
				</SCRIPT>");
		}		
	}

	function bukutamu() {
		if(empty($this->session->userdata['status_admin'])) {
			$this->displayadmin('admin/login');
		} else {
			$data['terbaca'] = $this->m_post->get_guestbook(1);
			$data['blmterbaca'] = $this->m_post->get_guestbook(0);
			$this->displayadmin('admin/menu/guestbook', $data);
		}
	}

	function user() { //lihat list admin
		if(empty($this->session->userdata['status_admin'])) {
			$this->displayadmin('admin/login');
		} else {
			$data['aktif'] = $this->m_user->get_admin_status('aktif');
			$data['banned'] = $this->m_user->get_admin_status('banned');
			$this->displayadmin('admin/menu/user', $data);
		}
	}

	function pelanggan(){
		if(empty($this->session->userdata['status_admin'])) {
			$this->displayadmin('admin/login');
		} else {
			if(isset($_POST['btn_search'])) {
				$this->displayadmin('admin/search/pelanggan', $data);
			} else {
				$data['aktif'] = $this->m_user->get_user_status('aktif');
				$data['banned'] = $this->m_user->get_user_status('banned');
				$this->displayadmin('admin/menu/pelanggan', $data);
			}
		}
	}

	function footer() {
		if(empty($this->session->userdata['status_admin'])) {
			$this->displayadmin('admin/login');
		} else {
			$data['sosmed'] = $this->m_footer->sosmed();
			$data['kontak'] = $this->m_footer->kontak();
			$data['bank'] = $this->m_footer->bank();
			//tampilsn admin
			$this->displayadmin('admin/menu/footer', $data);			
		}
	}

	// 
	//  proces line 
	// -------------------------------------------------------------------------------------------------------
	// -------------------------------------------------------------------------------------------------------
	// -------------------------------------------------------------------------------------------------------
	//

	//delete guestbook
	function delete_guestbook(){
		$id = $this->input->get('id');//get the guestbook id
		if($this->m_admin->delete_guestbook($id)) {
		echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('Delete Success');
					window.location.href='".site_url('admin/dashboard/bukutamu')."';
				</SCRIPT>");
		} else { //jika gagal memasukan data
			echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('Delete Error');
					window.location.href='".site_url('admin/dashboard/bukutamu')."';
				</SCRIPT>");
		}
	}

	//edit sosmed
	function edit_sosmed(){	
		if(!isset($_POST['btn'])) { //jika tidak menekan tombol btn
			redirect(site_url('admin/dashboard/footer'));
		} else { //jika menekan	
			//grap data
			$id = $this->input->post('id');
			$des = $this->input->post('des');
			$link = $this->input->post('link');
			$params = array($des,$link,$id);
			//perintah query
			if($this->m_footer->edit_data($params)) {
				redirect(site_url('admin/dashboard/footer'));
			} else {
				echo "telah terjadi kesalahan, silahkan coba lagi";
			}
		}
	}

	//edit kontak
	function edit_kontak(){
		if(!isset($_POST['btn'])) { //jika tidak menekan tombol btn
			redirect(site_url('admin/dashboard/footer'));
		} else { //jika menekan
			//grap data
			$id = $this->input->post('id');
			$des = $this->input->post('des');
			$link = $this->input->post('link');
			$params = array($des,$link,$id);
			//perintah query
			if($this->m_footer->edit_data($params)) {
				redirect(site_url('admin/dashboard/footer'));
			} else {
				echo "telah terjadi kesalahan, silahkan coba lagi";
			}
		}
	}

	//edit pembayaran
	function edit_pembayaran(){
		if(!isset($_POST['btn'])) { //jika tidak menekan tombol btn
			redirect(site_url('admin/dashboard/footer'));
		} else { //jika menekan
			//grap data
			$id = $this->input->post('id');
			$des = NULL;
			$link = $this->input->post('link');
			$params = array($des,$link,$id);
			//perintah query
			if($this->m_footer->edit_data($params)) {
				redirect(site_url('admin/dashboard/footer'));
			} else {
				echo "telah terjadi kesalahan, silahkan coba lagi";
			}
		}
	}

	//update slidder
	function update_slidder(){
		if(empty($this->session->userdata['status_admin'])) {
			$this->displayadmin('admin/login');
		} else {
			//load model m_admin
			$this->load->model('m_admin');
			//measukan hasil input
			$id = $this->input->post('id');
			$content = $this->input->post('content');
			$url = $this->input->post('url');
			$img = $_FILES['img'];
			$pic_upload = str_replace(" ", "_", $img['name']);
			//menyimpan hasil input di $params
			$params = array($content, $url,$pic_upload, $id);
			//jika berhasil menambah ke data base
			if($this->m_admin->update_slidder($params)) {
				//memanggil library upload CI
				$config['upload_path'] = 'images/slidder';
				//konfigurasi file apa saja yang bisa diupload
				$config['allowed_types'] = 'jpeg|jpg|png';
				//jika ada file dengan nama yang sama maka langsung direplace
				$config['overwrite'] = true;
				//memasukkan konfigurasi ke fungsi initialize untuk dicek kebenarannya
				$this->upload->initialize($config);
				//memanggil fungsi do_upload yang akan meng-upload file gambar_besar
				$this->upload->do_upload('img');
				//jika upload gagal makal menampilkan error
				echo $this->upload->display_errors();

				$data['berhasil']['tambah'] = "berhasil disimpan";
				//redirect ke fungsi admin/tambah_barang jika barang berhasil ditambahkan
				redirect('/admin/dashboard/welcome' );
			} else {
				echo "gagal disimpan";
			}
		}
	}

	//menambah post
	function create_post(){
		if(empty($this->session->userdata['status_admin'])) {
			$this->displayadmin('admin/login');
		} else {
			//mengambil data
			$title = $this->input->post('title');
			$kategori = $this->input->post('kategori');
			$content = $this->input->post('content');
			$draft = $this->input->post('draft');
			$publish = $this->input->post('publish');
			$id= $this->session->userdata('id');

			//yang ditekan tombol draft atau publish
			if(isset($_POST['draft'])) { //jka tombol draft ditekan
				$params = array ('title' => $title, 'content' => $content, 'username' => $id, 'kat' => $kategori, 'status' => 0);
				$this->m_post->add_post($params);
				redirect(site_url('admin/dashboard/post'));
			} else if (isset($_POST['publish'])) { //jka tombol publish ditekan
				$params = array ('title' => $title, 'content' => $content, 'username' => $id, 'kat' => $kategori, 'status' => 1);
				$this->m_post->add_post($params);
				redirect(site_url('admin/dashboard/post'));

			} else {
				echo "tidak ada respon, silahkan ulangi lagi";
			}
		}
	}

	function edit_post(){
		if(empty($this->session->userdata['status_admin'])) {
			$this->displayadmin('admin/login');
		} else {
			//mengambil data
			$title = $this->input->post('title');
			$kategori = $this->input->post('kategori');
			$content = $this->input->post('content');			
			$id_post= $this->input->post('id_berita');
			$id = $this->session->userdata('id_admin');

			//yang ditekan tombol draft atau publish
			if(isset($_POST['draft'])) { //jka tombol draft ditekan
				$params = array ('title' => $title, 'content' => $content, 'username' => $id, 'kat' => $kategori, 'status' => 0, 'id_post' => $id_post);
				$this->m_post->edit_post($params);
				redirect(site_url('admin/dashboard/post'));
			} else if (isset($_POST['publish'])) { //jka tombol publish ditekan
				$params = array ('title' => $title, 'content' => $content, 'username' => $id, 'kat' => $kategori, 'status' => 1, 'id_post' => $id_post);
				$this->m_post->edit_post($params);
				redirect(site_url('admin/dashboard/post'));
			} else {
				echo "tidak ada respon, silahkan ulangi lagi";
			}
		}
	}

	function del_post(){
		$id = $_GET['id'];
		$this->m_post->del_post($id);
		redirect(site_url('admin/dashboard/post'));
	}


	//delete category barang
	public function delcatbrg(){
		$id = $this->input->get('id');//ambil id kategori
		if($this->m_barang->delkatbrg($id)) {
			echo ("<SCRIPT LANGUAGE='JavaScript'>
						window.alert('Berhasil Delete Kategori');
						window.location.href='".site_url('admin/dashboard/barang')."';
					</SCRIPT>");
		} else {
			echo ("<SCRIPT LANGUAGE='JavaScript'>
						window.alert('Gagal Delete Kategori');
						window.location.href='".site_url('admin/dashboard/barang')."';
					</SCRIPT>");
		}
	}

	//ubah status barang ditagihan
	public function ubah_statusbarang(){
		$id_user = $_GET['usr']; //memanggil id usr
		$id_sewa = $_GET['id']; //id sewa
		$status = $_GET['status']; //status barang
		$id_brg = $_GET['brg']; //id barang
		$count = $_GET['count']; //jumlah barang yang dipinjam
		//model untuk merubah status barang
		$params = array('status' => $status, 'id_sewa' => $id_sewa, 'id_brg' => $id_brg); //parameter untuk ubah status barang		
		$this->m_barang->ubah_status_brg($params);//merubah status barang di tabel sewa
		//print_r($this->m_barang->ubah_status_brg($params));
		//mengembalkan sisa barang di tabel barang
		$parameter = array('count' => $count, 'id_brg' => $id_brg); //parameter untuk ubah stok_sisa barang
		switch ($status) {
			case '2': //barang kembali ke gudang
			$this->m_barang->kurang_sewa_brg($parameter);
				//kembali ke halaman tagihan
			redirect(site_url('pelanggan/pelanggan/detailtagihan_adm?id=' .$id_sewa.'&id_user='.$id_user));
			break;

			case '3': //barang disewa oleh user
			$this->m_barang->tambah_sewa_brg($parameter);
				//kembali ke halaman tagihan
			redirect(site_url('pelanggan/pelanggan/detailtagihan_adm?id=' .$id_sewa.'&id_user='.$id_user));
			break;
			
			default:
				//jika status = 0 or 1
				//kembali ke halaman tagihan
			redirect(site_url('pelanggan/pelanggan/detailtagihan_adm?id=' .$id_sewa.'&id_user='.$id_user));
			break;
		}

		
	}

	//membuat validasi apakah data yang diinputkan benar atau tidak
	public function login_validation(){
		//memanggil library form_validation
		$this->load->library('form_validation');
		//membuat sebuah rule untuk username, seperti required, penulisan yang benar, dan menggunakan database untuk cek
		//$this->form_validation->set_rules('username', 'Username', 'required|trim|xss_clean|callback_validate_admin');
		$this->form_validation->set_rules('username', 'Username', 'required|trim|xss_clean|callback_validate_admin');
		//membuah sebuah rule untuk password seperti required, menggunakan md5
		$this->form_validation->set_rules('password', 'Password', 'required|md5|trim');
		//membuat sebuah struktur kendali jika form_validation berhasil berjalan
		if ($this->form_validation->run()){
			$username =  $this->input->post('username');
			$password = $this->input->post('password');
			$ad = $this->m_admin->can_logged_in($username, $password);
			//print_r($ad);
			$now = date('Y-m-d H:i:s');
			$param = array($now, $ad['id_user']);
			//$this->m_admin->last_login($param); //lihat kapan terakhir kali admin login
			//membuat sebuah array dari data yang diinputkan
			$data = array (
				'id_admin' => $ad['id_user'],
				'username_admin' => $ad['username'],
				'level_admin' => $ad['level'],
				'status_admin' => $ad['status'],
				'is_logged_in_admin' =>1
				);
			//memasukkan data array kedalam session userdata
			$this->session->set_userdata($data);
			//print_r($this->session->userdata);
			redirect(site_url('admin/dashboard/welcome'));
		} else{
			//jika gagal maka kembali masuk ke halaman login
			$this->displayadmin('admin/login');
		}

	}

	//admin login
	function validate_admin() {
		$username =  $this->input->post('username');
		$password = md5($this->input->post('password'));
		if ($this->m_admin->can_logged_in($username, $password)) {
			return true;
		} else {
			//jika gagal, maka menampilkan pesan "Incorrect username/password"
			$this->form_validation->set_message('validate_admin', "username/password salah");
			return false;
		}
		
	}

	//admin logout
	public function logout() {
		//fungsi yang digunakan untuk menghapus session
		$this->session->sess_destroy();
		//output
		redirect(site_url('admin/dashboard'));
		//output
		echo ("<SCRIPT LANGUAGE='JavaScript'>
			window.alert('Admin berhasil Logout');
			window.location.href='".site_url()."';
		</SCRIPT>");
	}

	// fungsi untuk menambah barang
	function add_brg(){
		if(empty($this->session->userdata['status_admin'])) {
			$this->displayadmin('admin/login');
		} else {
			//load model m_admin
			$this->load->model('m_admin');
			//measukan hasil input

			$nama_brg = $this->input->post('nama_brg');
			$des_brg = $this->input->post('des_brg');
			$stok_total = $this->input->post('stok_total');
			$kat = $this->input->post('kat');
			$harga = $this->input->post('harga');
			$pic = $_FILES['pic_brg'];
			$pic_upload = str_replace(" ", "_", $pic['name']);
			//menyimpan hasil input di $params
			
			$params = array($nama_brg, $des_brg, $kat, $stok_total, $stok_total, $harga, $pic_upload);
			//jika berhasil menambah ke data base
			if($this->m_admin->add_brg($params)) {
				//memanggil library upload CI
				$config['upload_path'] = './images/barang';
					//konfigurasi file apa saja yang bisa diupload
				$config['allowed_types'] = 'gif|jpg|png|jpeg';
					//jika ada file dengan nama yang sama maka langsung direplace
				$config['overwrite'] = true;
					//memasukkan konfigurasi ke fungsi initialize untuk dicek kebenarannya
				$this->upload->initialize($config);
					//memanggil fungsi do_upload yang akan meng-upload file gambar_besar
				$this->upload->do_upload('pic_brg');
					//jika upload gagal makal menampilkan error
				echo $this->upload->display_errors();

				$data['berhasil']['tambah'] = "berhasil disimpan";
					//redirect ke fungsi admin/tambah_barang jika barang berhasil ditambahkan
				redirect('/admin/dashboard/barang' );
			} else {
				echo "gagal disimpan";
			}
		}
	}

	//function delete barang
	function del_brg($id_brg) {
		if(empty($this->session->userdata['status_admin'])) {
			$this->displayadmin('admin/login');
		} else {
			$id_brg = $_GET['id_brg'];
			$this->m_barang->del_brg($id_brg);
			redirect(site_url('admin/dashboard/barang'));
		}
	}

	//function update barang
	function upd_brg() {	
		if(empty($this->session->userdata['status_admin'])) {
			$this->displayadmin('admin/login');
		} else {		
			
			$gambar = $_FILES['gambar'];
			$gambar_lama = $this->input->post('gambarlama');
			$nama_brg = $this->input->post('nama_brg');
			$des_brg = $this->input->post('des_brg');
			$id_kat_brg = $this->input->post('kat');
			$stok_total = $this->input->post('stok');
			$disewa = $this->input->post('disewa');
			$harga = $this->input->post('harga');
			//$pic_brg = $this->input->post('pic_brg');
			$id_brg = $_GET['id'];

			//jika upload poster
			$this->load->library('upload');
			//config untuk library upload
			$config['upload_path'] = './images/barang';
			$config['allowed_types'] = 'gif|png|jpg|jpeg|GIF|PNG|JPG|JPEG';
			$config['overwrite'] = true;
			$config['max_size'] = 1000000; //1MB
			$this->upload->initialize($config);
			if($this->upload->do_upload('gambar')) {
				$gambar_nama = str_replace(' ', '_', $gambar['name']); //rename ' ' menjadi '-'
			} else {
				$gambar_nama = $gambar_lama; //post
			}	
			echo $this->upload->display_errors();	


			$params = array($nama_brg,$des_brg,$id_kat_brg,$stok_total, $disewa,$harga,$gambar_nama, $id_brg);
			$this->m_barang->upd_brg($params);
			echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('Update Barang Berhasil');
				window.location.href='../../admin/dashboard/barang';
			</SCRIPT>");
		}
	}

	//function untuk menambah kategori
	function add_kat(){
		//menangkap hasil input dari form
		$nama = $this->input->post('nama_kat');
		$des = $this->input->post('des_kat');
		$params = array('nama' => $nama, 'des' => $des);
		//memanggil fungsi add_kategori dan menambahkan data berdasarkan input form
		$this->m_kategori->add_kat($params);
		//memanggil kategori dari model dan ditampilkan setelah kategori berhasil ditambahkan
		redirect(site_url('admin/dashboard/barang')); //kembali kehalaman barang
	}

	//function update barang
	function upd_kat() {
		if(empty($this->session->userdata['status_admin'])) {
			$this->displayadmin('admin/login');
		} else {
			//mengambil data
			$nama_kat = $this->input->post('nama_kat');
			$des_kat= $this->input->post('des_kat');
			$id_kat = $this->input->post('id');

			$params = array('nama_kat' => $nama_kat, 'des_kat' => $des_kat, 'id_kat' => $id_kat);

			$this->m_kategori->upd_kat($params);
			
			echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('Update Kategori Berhasil');
				window.location.href='../../admin/dashboard/barang';
			</SCRIPT>");
		}
	}

	//menjadi lunas
	function jadi_lunas() {
		if(empty($this->session->userdata['status_admin'])) {
			$this->displayadmin('admin/login');
		} else {
			//mengambil data
			$id_sewa = $_GET['id'];
			$this->m_admin->jadi_lunas($id_sewa);
			echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('Update Status Pembayaran Berhasil');
				window.location.href='../../admin/dashboard/tagihan';
			</SCRIPT>");
		}
	}

	//batal lunas
	function batal_lunas() {
		if(empty($this->session->userdata['status_admin'])) {
			$this->displayadmin('admin/login');
		} else {
			//mengambil data
			$id_sewa = $_GET['id'];
			$this->m_admin->batal_lunas($id_sewa);
			echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('Update Status Pembayaran Berhasil');
				window.location.href='../../admin/dashboard/tagihan';
			</SCRIPT>");
		}
	}

	//delete tagihan
	function deletetagihan(){
		$id = $this->input->get('id');//get id tagihan
		if($this->m_tagihan->deletetagihan($id) && $this->m_tagihan->deletetagihandetail($id)) { //jika berhsil memasukan data
			echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('Success Hapus Tagihan');
					window.location.href='".site_url('admin/dashboard/tagihan')."';
				</SCRIPT>");
		} else { //jika gagal memasukan data
			echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('Gagal Hapus Tagihan');
					window.location.href='".site_url('admin/dashboard/tagihan')."';
				</SCRIPT>");
		}
	}



	//ubah status barang sudah diambil pelanggan
	function status_barang() {
		if(empty($this->session->userdata['status_admin'])) {
			$this->displayadmin('admin/login');
		} else {
			$id_sewa = $_GET['id']; //ambil id sewa
			$status = $_GET['status']; //status barang terbaru
			$params = array('status' => $status, 'id_sewa' => $id_sewa );
			//merubah status barang
			$this->m_admin->status_barang($params); 
			//merubah sisa stok barang
			switch ($status) {
				case '1':
					//$this->m_admin->ubah_stok($id_sewa); //mengurangi stok sisa dengan stok yang disewa
				echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('Update status berhasil \n Stok sisa telah berubah');
					window.location.href='../../admin/dashboard/tagihan';
				</SCRIPT>");
				break;

				case '0':
					//$this->m_admin->ubah_stok($id_sewa); //menambah stok sisa dengan stok yang disewa
				echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('Update status berhasil \n Stok sisa telah berubah');
					window.location.href='../../admin/dashboard/tagihan';
				</SCRIPT>");
				break;
				
				default:
				echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('Update status berhasil \n Stok barang tidak berubah');
					window.location.href='../../admin/dashboard/tagihan';
				</SCRIPT>");
				break;
			}
			
		}
	}

	//hapus user
	function deleteuser(){
		$id = $this->input->get('id'); //get user id
		if($this->m_user->del_user($id)) { //jika berhsil memasukan data
			echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('Success Delete User');
					window.location.href='".site_url('admin/dashboard/pelanggan')."';
				</SCRIPT>");
		} else { //jika gagal memasukan data
			echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('Error Delete User');
					window.location.href='".site_url('admin/dashboard/pelanggan')."';
				</SCRIPT>");
		}

	}

	//ubah status user
	function changeuser(){
		if(empty($this->session->userdata['status_admin'])) {
			$this->displayadmin('admin/login');
		} else {
			$status = $_GET['status'];
			$id = $_GET['id'];
			switch ($status) {
				case 'aktif':
				$params = array($status, $id);
				$this->m_user->change_status($params);
				echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('User telah aktif');
					window.location.href='../../admin/dashboard/pelanggan';
				</SCRIPT>");
				break;

				case 'banned':
				$params = array($status, $id);
				$this->m_user->change_status($params);
				echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('User telah dibanned');
					window.location.href='../../admin/dashboard/pelanggan';
				</SCRIPT>");
				break;
				
				default:
				echo "no status";
				break;
			}

		}
	}

	//ubah status admin
	function changeadmin(){
		if(empty($this->session->userdata['status_admin'])) {
			$this->displayadmin('admin/login');
		} else {
			$status = $_GET['status'];
			$id = $_GET['id'];
			switch ($status) {
				case 'aktif':
				$params = array($status, $id);
				$this->m_user->change_admin($params);
				echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('User telah aktif');
					window.location.href='../../admin/dashboard/user';
				</SCRIPT>");
				break;

				case 'banned':
				$params = array($status, $id);
				$this->m_user->change_admin($params);
				echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('User telah dibanned');
					window.location.href='../../admin/dashboard/user';
				</SCRIPT>");
				break;
				
				default:
				echo "no status";
				break;
			}

		}
	}

	function del_admin(){

		$id = $this->input->get('id');
		if($this->m_user->del_admin($id)) {
			echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('User telah didelete');
				window.location.href='../../admin/dashboard/user';
			</SCRIPT>");
		} else {
			echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('Terjadi kesalahan silahkan ulangi lagi');
				window.location.href='../../admin/dashboard/user';
			</SCRIPT>");
		}
	}

	function update_admin(){
		if(isset($_POST['username'])) {
			$this->load->library('form_validation');
			$this->form_validation->set_rules('username', 'Username', 'is_unique[user.username]');
			$this->form_validation->run();
		} 

		$username = $this->input->post('username');
		$fullname = $this->input->post('fullname');
		$email = $this->input->post('email');
		$id = $this->input->post('id_user');

		if(isset($_POST['new_password'])) {
			$password = md5($this->input->post('new_password'));
		} else {
			$password = $this->input->post('old_password');
		}

		//data yang dimasukan database
		$params = array($username, $password, $email,$fullname, $id);
		if($this->m_user->edit_admin($params)){			
			echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('Update data berhasil');
				window.location.href='".site_url('admin/dashboard/user')."';
			</SCRIPT>");

		} else {
			//memanggil view login_confirm
			echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('Update data gagal ,gunakan username lain');
				window.location.href='".site_url('admin/dashboard/user')."';
			</SCRIPT>");
		}
	}

	function addadmin(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('username', 'Username', 'is_unique[user.username]');
		$this->form_validation->set_rules('password1', 'Password','trim');
		$this->form_validation->set_rules('password1', 'Password','trim}matches[password1]');

		$username = $this->input->post('username');
		$fullname = $this->input->post('fullname');
		$password = md5($this->input->post('password1'));
		$email = $this->input->post('email');
		$params = array($username, $password, $email,$fullname);
		//membuat struktur kendali jika form_validation berjalan atau tidak
		if($this->form_validation->run()){
			//memanggil fungsi dari model m_pelanggan yaitu add_pelanggan
			$this->m_user->add_admin($params);
			//echo "silahkan cek email";
			//memanggil fungsi confirm()jika berhasil register
			$this->confirm_addadmin();
		} else{
			//memanggil view login_confirm
			echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('Registrasi gagal gunakan username yang lain');
				window.location.href='".site_url('admin/dashboard/user')."';
			</SCRIPT>");
		}
	}

	//membuat halaman confirm
	public function confirm_addadmin(){
    	//memanggil view login_confirm
		echo ("<SCRIPT LANGUAGE='JavaScript'>
			window.alert('Register berhasil, silahkan gunakan username dan password untuk login');
			window.location.href='".site_url('admin/dashboard/user')."';
		</SCRIPT>");
	}


}