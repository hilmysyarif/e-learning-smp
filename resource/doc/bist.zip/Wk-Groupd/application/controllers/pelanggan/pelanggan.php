<?php if (!defined('BASEPATH')) exit ('No direct script allowed');

//memanggil file base yang digunakan untuk menurunkan 
require_once 'application/controllers/base/base.php';

class pelanggan extends base {
	//membuat contruktor
	public function __construct() {
		parent::__construct();
		$this->load->library('encrypt'); //enkripsi data
		$this->m_tagihan->lewat_batas();//merubah tanggal sekarang - selisih denda
		$this->m_barang->cek_sisa();//cek sisa barang
	}

	//menampilkan halaman tagihan
	public function tagihan() {
		//jika belum login
		if(empty($this->session->userdata['is_logged_in'])) {
			echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('Anda belum login, silahkan login terlebih dahulu');
				window.location.href='../../public/home';
			</SCRIPT>");
		} else {
			$id = $this->session->userdata['id_user'];
			$data['title'] = 'tagihan | ';
			$data['user'] = $this->m_user->get_det_user($this->session->userdata('id_user'));
			$data['tagihan'] = $this->m_tagihan->get_tagihan_by_id_user($id);			
			$this->display('display/public/tagihan', $data);	
		}		
	}

	//menampilkan detail tagihan untuk pelanggan
	//juga fungsi untuk menghitung denda
	public function detailtagihan() {
		if(empty($this->session->userdata['is_logged_in'])) {
			echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('Anda belum login, silahkan login terlebih dahulu');
				window.location.href='../../public/home';
			</SCRIPT>");
		} else {
			//cek user apakah pemilik tagihan

			//lihat detail tagihan
			//$id = $this->encrypt->decode($_GET['id']); //ambil id sewa
			$id = $_GET['id']; //id sewa
			$id_user = $this->session->userdata['id_user'];//ambil id user
			//menampilkan lewat_batas
			$lb = $this->m_tagihan->get_lewat_batas($id);//lihat lewat batas pelanggan
			//jika lewat batas > 0 , maka denda mulai dihitiung
			if($lb['lewat_batas'] < 0) { //jika hasilnya negatif maka denda tidak dihitung
				$params = array('lb1' => 0, 'id' => $id );
				$this->m_tagihan->update_denda_hargatotal($params);
				//modal untuk menampilkan detail tagihan
				$data['tagihan'] = $this->m_tagihan->get_tagihan_by_id_sewa($id); //lihat sewa
				$data['dettagihan'] = $this->m_tagihan->get_det_tagihan($id); //lihat detail sewa
				$data['user'] = $this->m_user->get_det_user($id_user); //lihat data user lengkap
				$this->load->view('pelanggan/dettagihan', $data);
			} else { //jika hasilnya positif maka denda mulai dihitung
				$params = array('lb1' => $lb['lewat_batas'], 'id' => $id );
				$this->m_tagihan->update_denda_hargatotal($params);
				//modal untuk menampilkan detail tagihan
				$data['tagihan'] = $this->m_tagihan->get_tagihan_by_id_sewa($id); //lihat sewa
				$data['dettagihan'] = $this->m_tagihan->get_det_tagihan($id); //lihat detail sewa
				$data['user'] = $this->m_user->get_det_user($id_user); //lihat data user lengkap
				$this->load->view('pelanggan/dettagihan', $data);
			}			
		}		
		
	}

	//menampilkan detail tagihan untuk admin
	public function detailtagihan_adm() {
		if(empty($this->session->userdata['is_logged_in'])) {
			echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('Anda belum login, silahkan login terlebih dahulu');
				window.location.href='../../public/home';
			</SCRIPT>");
		} else {
			//cek user apakah pemilik tagihan

			//lihat detail tagihan
			$id =  $_GET['id']; //ambil id tagihan
			$id_user = $_GET['id_user'];//ambil id user
			$data['tagihan'] = $this->m_tagihan->get_tagihan_by_id_sewa($id); //lihat sewa
			$data['dettagihan'] = $this->m_tagihan->get_det_tagihan($id); //lihat detail sewa
			$data['user'] = $this->m_user->get_det_user($id_user); //lihat data user lengkap
			$this->load->view('pelanggan/dettagihan', $data);
		}		
		
	}		

	//edit data pelanggan
	public function edit_usr(){
		// isi post('...') sesuai dengan name="..." pada file produk/upload.php 
		$id_user = $this->session->userdata('id_user');
		$nama_leng = $this->input->post('nama_leng');
		$kota = $this->input->post('kota');
		$alamat_leng = $this->input->post('alamat_leng');
		$email = $this->input->post('email');
		$id_bank = $this->input->post('id_bank');
		$no_rek = $this->input->post('no_rek');
		$params = array ($email,$nama_leng, $alamat_leng, $kota,  $id_bank, $no_rek, $id_user);
        //parameter
		if ($this->m_user->edit_usr($params)) {
            //jika berhasil di redirect ke produk
			redirect ('pelanggan/pelanggan/tagihan');
		} else {
            //false
			echo "gagal disimpan";
		}
	}

}
