<?php if (!defined('BASEPATH')) exit ('No direct script allowed');

//memanggil file base yang digunakan untuk menurunkan 
require_once 'application/controllers/base/base.php';

class home extends base {
	//membuat construktor
	public function __construct() {
		parent::__construct();
        //memanggil library form_validation
		$this->load->library('form_validation');
		$this->load->helper('captcha');//captcha di guestbook
		$this->m_barang->cek_sisa();//cek sisa barang
		$this->load->helper('text'); //mengandung fungsi readmore
		if(isset($this->session->userdata['status_admin'])){
			redirect(site_url('admin/dashboard'));
		}


	}

	//show index page 
	public function index() {
		$data['title'] = "";
		//tampilan semua postingan
		$data['post'] = $this->m_post->get_post(3,0);		
		//menamnpilkan 8 barnag di home
		$data['view'] = $this->m_barang->get_brg(8,0);
		//data berisi tentang kami
		$data['kami'] = $this->m_post->get_post_by_id('8');
		//data sldder
		$data['slidder'] = $this->m_post->get_slidder();
		//menampilkan view home
		$this->display('display/public/home', $data);
	}

	//tampilan guestbook
	function bukutamu(){
		$data['title'] = "Guestbook | ";
		$data['kat'] = $this->m_kategori->get_kat();	
		//menampilkan view home
		$this->display('display/public/bukutamu', $data);
	}

	//guestbook
	function guestbook(){
		if ($this->input->post() && ($this->input->post('security_code') == $this->session->userdata('mycaptcha'))) {
			$nama = $this->input->post('nama');
			$email = $this->input->post('email');
			$pesan = $this->input->post('pesan');
			$params = array('n' => $nama, 'e' => $email, 'p' => $pesan);
			$this->m_post->guestbook($params);
			echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('Pesan anda telah terkirim, terimakasih');
				window.location.href='".site_url()."';
			</SCRIPT>");
		}
		else
		{
			echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('kode keamanan salah, silahkan ulangi lagi');
				window.location.href='".site_url()."';
			</SCRIPT>");
		}

	}

	//page hasil search
	function search() {
		$keyword = $_GET['q'];
		$data['title'] = "Pencarian ".$keyword." | ";
		$data['key'] = $keyword;
		$data['view'] = $this->m_barang->search_brg($keyword);//model untuk pencarian keyword
		$this->display('display/public/search', $data); //hasil display
	}

	///////////////////////////// VIEW //////////////////////////////////

	//register proses
	public function register_validation(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('username', 'Username', 'is_unique[klien.username]');
		$this->form_validation->set_rules('password1', 'Password','trim');
		$this->form_validation->set_rules('password1', 'Password','trim}matches[password1]');
		//membuat struktur kendali jika form_validation berjalan atau tidak
		if($this->form_validation->run()){
			//memanggil fungsi dari model m_pelanggan yaitu add_pelanggan
			$this->m_user->add_user();
			//echo "silahkan cek email";
			//memanggil fungsi confirm()jika berhasil register
			$this->confirm();
		} else{
			//memanggil view login_confirm
			echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('Registrasi gagal gunakan username yang lain');
				window.location.href='".site_url()."';
			</SCRIPT>");
		}
	}

	//membuat halaman confirm
	public function confirm(){
    	//memanggil view login_confirm
		echo ("<SCRIPT LANGUAGE='JavaScript'>
			window.alert('Register berhasil, silahkan gunakan username dan password untuk login');
			window.location.href='".site_url()."';
		</SCRIPT>");
	}

	//login proses
	public function login_validation() {
		$this->load->library('form_validation');
		//proses data
		$this->form_validation->set_rules('username', 'Username', 'required|trim|xss_clean|callback_validate_credentials');
		$this->form_validation->set_rules('password', 'Password', 'required|md5|trim');
		//check valid
		if($this->form_validation->run()==true) {
			//ambil data dari method post
			//memasukkan input email kedalam variabel $email
			$username = $this ->input->post('username');
			//memasukkan input password kedalam variabel $password
			$password = $this->input->post('password');
			//cek email dan password ke fungsi can_log_in di database dan memasukkannya kedalam variabel $userdata
			$userdata = $this->m_user->can_log_in($username,$password);
			//jika user tidak kosong
			if(!empty($userdata)){
				//memasukkan isi dari userdata kedalam user data
				$sessionData['id_user'] = $userdata['id_user'];
				$sessionData['username'] = $userdata['username'];
				$sessionData['nama_leng'] = $userdata['nama_leng'];
				$sessionData['alamat_leng'] = $userdata['alamat_leng'];
				$sessionData['kota'] = $userdata['kota'];
				$sessionData['id_bank'] = $userdata['id_bank'];
				$sessionData['status'] = $userdata['status'];
				$sessionData['no_rek'] = $userdata['no_rek'];
				$sessionData['email'] = $userdata['email'];
				$sessionData['is_logged_in'] = 1;
				//set session userdata menggunakan nilai sessionData
				$this->session->set_userdata($sessionData);
				//redirect ke halaman puclic/home/pelanggan jika sukses

				//cek apakah user dibanned
				if($this->session->userdata('status') == 'banned' ) {
					echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('Login Gagal, username ini telah dibbaned');
					window.location.href='".site_url('public/home/logout_banned')."';
					</SCRIPT>");
				} else { //jika tidak dibanned
					echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('Login Sukes, klik ok untuk melanjutkan');
					window.location.href='".site_url('public/home')."';
					</SCRIPT>");
				}			
				
			} 

		} else { //jika data kosong maka
			$data['title'] = '';
			//tampilan semua postingan
			$data['post'] = $this->m_post->get_post(3,0);
			//membuat data yang berisi hasil select kategori dari database
			$data['kat'] = $this->m_kategori->get_kat();	
			//mebuat data yang berisi hasil select barang dari database
			$data['view'] = $this->m_barang->show_brg();
			//data berisi tentang kami
			$data['kami'] = $this->m_post->get_post_by_id('8');
			//data sldder
			$data['slidder'] = $this->m_post->get_slidder();
			//menampilkan view home
			$this->display('display/public/home', $data);
		}
	}


	//validasi login dengan database dan memberikan pesan kesalahan
	public function validate_credentials(){
		$username = $this->input->post('username');
		$password = md5($this->input->post('password'));
		//struktur kendali untuk cek bisa login atau tidak
		if ($this->m_user->can_log_in($username, $password)){
			return true;
		} else {
			//memberikan pesan jika login tidak berhasil
			$this->form_validation->set_message('validate_credentials', 'username/password salah');
			return false;
		}
	}

	//ogout process
	public function logout() {
		//fungsi yang digunakan untuk menghapus session
		$this->session->sess_destroy();
		//output
		echo ("<SCRIPT LANGUAGE='JavaScript'>
			window.alert('Logout Sukes, klik ok untuk melanjutkan');
			window.location.href='".site_url()."';
		</SCRIPT>");
	}

	//ogout process
	public function logout_banned() {
		//fungsi yang digunakan untuk menghapus session
		$this->session->sess_destroy();
		//output
		redirect(site_url());
	}

	/////////////////////// POST /////////////////////////////
	
	//menampilkan item seluruh postingan
	public function news() {
		$data['title'] = "News | ";	

		//menampilkan pagination
		$this->load->library('pagination');

		$config['base_url'] = site_url('public/home/news/');
		$config['total_rows'] = $this->m_post->count_post();
		$config['per_page'] = 6; 
		$config['uri_segment'] = 4;
		$config['num_link'] = 4;
		$config['use_page_number'] = TRUE;
		$uri = $this->uri->segment(4);
		$this->pagination->initialize($config); 
		
		if(!$uri) {
			$uri = 0;
		}

		if($config['total_rows'] < 6) {
			$data['page'] = 1;
		} else {
			$data['page'] = $this->pagination->create_links();
		}
		//tampilan semua postingan
		$data['post'] = $this->m_post->get_post(10,0);
		//membuat data yang berisi hasil select barang dari database
		$data['view'] = $this->m_post->get_post($config['per_page'], $uri);
		//menampilkan view home
		$this->display('display/public/berita.php', $data);
	}	

	//halaman single untuk post
	public function single($id="") {
		$data['title'] = "Post | ";
		//tampilan semua postingan
		$data['post'] = $this->m_post->get_post(10,0);
		//membuat data yang berisi hasil select kategori dari database
		$data['kat'] = $this->m_kategori->get_kat();	
		//menampilkan post berdasarkan id
		$data['view'] = $this->m_post->get_post_by_id($id);
		//halaman view
		$this->display('display/public/single.php', $data);
	}

	/////////////////////// BARANG /////////////////////////////

	//menampilkan item seluruh produk
	public function produk() {
		$data['title'] = "Produk | ";

		//menampilkan pagination
		$this->load->library('pagination');

		$config['base_url'] = site_url('public/home/produk/');
		$config['total_rows'] = $this->m_barang->count_brg();
		$config['per_page'] = 12; 
		$config['uri_segment'] = 4;
		$config['num_link'] = 4;
		$config['use_page_number'] = TRUE;
		$uri = $this->uri->segment(4);
		$this->pagination->initialize($config); 
		
		if(!$uri) {
			$uri = 0;
		}

		if($config['total_rows'] < 10) {
			$data['page'] = 1;
		} else {
			$data['page'] = $this->pagination->create_links();
		}

		//membuat data yang berisi hasil select kategori dari database
		$data['kat'] = $this->m_kategori->get_kat();	
		//mebuat data yang berisi hasil select barang dari database
		$data['view'] = $this->m_barang->get_brg($config['per_page'],$uri);
		//menampilkan view home
		$this->display('display/public/produk.php', $data);
	}

	//membuka single page dengan parameter id
	public function item($id="") {
		
		//mengatur bahwa id itu merupakan uri segmen ketiga
		//membuat sebuah data yang berisi hasil select kategori dari database
		$data['kat'] = $this->m_kategori->get_kat();
		//membuat sebuah data yang berisi hasil select barang dari database
		$data['list'] = $this->m_barang->show_brg();
		
		//menampilkan sebuah data yang berisi hasil select barang berdasar id dari database
		//mebuat data yang berisi hasil select barang dari database
		$data['view'] = $this->m_barang->get_brg_by_id($id);
		$nama = str_replace(' ', '-', $data['view']['nama_barang']);
		$data['title'] = $nama." | ";
		//menampilkan semua data
		$data['all'] = $this->m_barang->get_12brgnew(); //menampilkan 12 barang paling banyak disewa		
		//memasukkan data yang dibuat ke fungsi display untuk diolah dihalaman single_view.php
		$this->display('display/public/item.php', $data);
	}

	//membuat fungsi untuk menampilkan barang berdasarkan kategorinya
	public function kategori($id_kat_brg, $des_kat_brg){
		$data['title'] =  $des_kat_brg." | " ;
		//id_kategori merupakan parameter untuk segment 3 dari url
		$id_kat_brg = $this->uri->segment(4);
		//menampilkan pagination
		$this->load->library('pagination');
		$config['base_url'] = site_url('public/home/kategori/'.$id_kat_brg.'/'.$des_kat_brg);
		$config['total_rows'] = $this->m_barang->count_brg_by_kat($id_kat_brg);
		$config['per_page'] = 10; 
		$config['uri_segment'] = 6;
		$config['num_link'] = 4;
		$config['use_page_number'] = TRUE;
		$uri = $this->uri->segment(6);
		$this->pagination->initialize($config); 
		
		if(!$uri) {
			$uri = 0;
		}

		if($config['total_rows'] < 10) {
			$data['page'] = 1;
		} else {
			$data['page'] = $this->pagination->create_links();
		}

		//menampilkan kategori sekarang
		$data['katnow'] = $this->m_kategori->get_kat_by_id($id_kat_brg);
		//buat load menu kategori di sidebar
		$data['kat'] = $this->m_kategori->get_kat();
		//membuat data hasil dari select barang berdasar id_kategori
		$data['brg'] = $this->m_barang->get_brg_by_kat($config['per_page'],$uri, $id_kat_brg);
		//memasukkan data yang dibuat kefungsi display dan dihalaman kategori_view untuk diolah
		$this->display('display/public/kategori', $data);
	}


	//membuat sebuah fungsi cart barang
	public function cart(){
		//membuat data hasil dari select kategori barang
		$data['kat'] = $this->m_kategori->get_kat();
		//membuat data hasil dari select barang
		$data['view'] = $this->m_barang->show_brg();
		//ketika masuk ke url ini membuka view cart_view
		$this->load->view('pelanggan/cart_view', $data);
	}


	//membuat sebuah fungsi untuk meletakkan barang kedalam cart barang
	public function add_to_cart(){

		//memasukkan input dari id_barang ke variabel idb
		$idb = $this->input->post('id_brg');
		//input jumlah pesan
		
		//menampilkan select barang berdasar id_barang 
		$barang = $this->m_barang->get_brg_by_id($idb);
		//membuat sebuah array yang menampung variable yang akan digunakan dicart
		$insert = array (
			//merupakan id dari setiap barang
			'id' => $this->input->post('id_brg'),
			//jumlah dari barang
			'qty' => $this->input->post('jumlah') ,
			//harga dari barang
			'price' =>$barang['harga'] ,
			//options lain seperti nama barang
			'name' =>$barang['nama_barang'],
			//tanggal kembali
			'kembali' => $this->input->post('kembali') 
			);
		//memasukkan array kedalam fungsi insert cart
		$data = $this->cart->insert($insert);
		//redirect kembali ke halaman home
		redirect('public/home');
	}

		//hapus isi cart
	function remove($rowid) {
		if ($rowid=="all"){
			$this->cart->destroy();
		}else{
			$data = array(
				'rowid'   => $rowid,
				'qty'     => 0
				);

			$this->cart->update($data);
		}
		if(!$this->session->userdata('id_user')) {
			redirect(site_url());
		} else {
			redirect('public/home/pelanggan');
		}
		
	}		

		//ketika mau bayar
	public function pelanggan() {
			//struktur kendali jika pelanggan login atau tidak		
			$data['title'] = "Bayar | ";
			if(!empty($this->session->userdata('id_user'))){ //jika user sudah login
				$this->load->model('m_user');
				$id_user = $this->session->userdata('id_user');
				$data['user'] = $this->m_user->get_det_user('id_user');
				//jika login maka menampilkan fungsi display dengan halaman welcome_pelanggan dengan membawa data
				$this->display('display/public/bayar', $data);
			} else { //jika tidak login
				echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('Untuk melakukan pembayaran, silahkan login terlebih dahulu');
					window.location.href='../..';
				</SCRIPT>");
			}
		}

		//membuat fungsi memasukan cart kedaftar tagihan
		public function save_sewa(){
			if(!empty($this->session->userdata('id_user'))){
				$id = $this->input->post('id_user');
				$tglsewa = $this->input->post('tglsewa');
				$tglkembali = $this->input->post('tglkembali');
				$day = date('Y-m-d H-i-s');
				$sewa = array(
					'tgl_transaksi' => $day,
					'tgl_jatuhtempo' => $tglsewa,
					'tgl_sewa' => $tglsewa,
					'tgl_kembali' => $tglkembali,
					'id_user' 	=> $id
					);
				//mengurangi stok sisa ditabel barang

				//$data['jumlah'] = $this->m_barang->get_jumlah($id);
				$sewa_new = $this->m_barang->insert_sewa($sewa);
				
				$top = $this->m_barang->get_sewa_by_usr($id);

				$id_sewa=  $top['id_sewa'];
				$dibayar = 0;
				if ($cart = $this->cart->contents()):
					foreach ($cart as $item):
						$sewa_detail= array(
							'id_brg' 	=> $item['id'],
							'jumlah' 		=> $item['qty'],
							'subtotal'	=> $item['subtotal'],
							'id_sewa' 		=> $id_sewa
							);
					$params = array (
						'disewa' 		=> $item['qty'],
						'jumlah' 		=> $item['qty'],
						'id_brg' 	=> $item['id']
						);		
					$dibayar = $dibayar + $item['subtotal'];
					$cust_id = $this->m_barang->insert_sewa_detail($sewa_detail);
					$update_stok = $this->m_barang->stok_sekarang($params);
					endforeach;
					endif;
					$data['bayar'] = $this->m_barang->get_bayar($id_sewa);

					//jumlah yang harus dibayar
					$bahan = array('dibayar' => $dibayar, 'dibayar2' => $dibayar, 'id_sewa' => $id_sewa );
					$this->m_tagihan->dibayar($bahan);

					//berhasil
					echo ("<SCRIPT LANGUAGE='JavaScript'>
						window.alert('Silahkan cek halaman tagihan untuk pembayaran');
						window.location.href='../../public/home/destroy';
					</SCRIPT>");
				//$this->display('pelanggan/konfirmasi_pembayaran',$data);

				} else {
					echo ("<SCRIPT LANGUAGE='JavaScript'>
						window.alert('Untuk melakukan pembayaran, silahkan login terlebih dahulu');
						window.location.href='../..';
					</SCRIPT>");
				}


			}

		//membuat fungsi untuk membersihkan cart sebelumnya
			public function destroy() {
		//memanggil fungsi untuk membersihkan cart
				$this->cart->destroy();
		//redirect kembali ke halaman home
				redirect(site_url());
			}
		}
