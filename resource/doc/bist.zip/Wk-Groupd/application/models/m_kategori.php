<?php
	class m_kategori extends CI_Model {


		////////////////////////////////////////////////////////////////////////////
		///////////////////// KATEGORI BARANG /////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////

		//fungsi untuk menambah kategori
		function add_kat($params) {
			//perintah sql
			$sql = "INSERT INTO kat_barang(des_kat_brg, det_kat_brg) VALUES (?,?)";
			//eksekusi perintah sql
			$query = $this->db->query($sql, $params);
		}

		//memanggil kategori dari barang
		function get_kat() {
			//memanggil kategori dari database
			$query = $this->db->query('SELECT * FROM kat_barang ORDER BY des_kat_brg ASC');
			//hasil query menjadi result array
			return $query->result_array();
		}		

		//memanggil sub kategori berdasar masin kategori
		function get_sub_kat($id){
			//memanggil kategori dari database
			$query = $this->db->query('SELECT * FROM sub_kat_brg WHERE id_main_kat = ? ORDER BY sub_kat ASC');
			//hasil query menjadi result array
			return $query->result_array();
		}

		//memanggil kategori berdasarkan id kategori
		function get_kat_by_id($id_kat) {
			//perintah sql untuk mengambil kategori berdasarkan id kategori
			$sql = 'SELECT * FROM kat_barang WHERE id_kat_barang = ? ';
			//eksekusi query
			$query = $this->db->query($sql, $id_kat);
			//hasil dari query = 1 baris
			return $query->row_array(); 
		}

		//update kategori
		function upd_kat($params){
		    //perintah sql untuk update kategori
		    $sql = "UPDATE kat_barang SET des_kat_brg = ?,det_kat_brg = ?  WHERE id_kat_barang =? ";
		    //eksekusi perintah sql
		    $query = $this->db->query($sql, $params);
		    //cek apakah sql bisa berjalan dengan baik atau tidak
		    if($query==true){
		        echo "berhasil update";
		    } else echo "gagal gagal update";
		}

		//fungsi untuk menghapus kategori
		function delete_kat($id_kat){
		    //perintah sql untuk hapus kategori
		    $sql = "DELETE FROM kat_barang WHERE id_kat = ? ";
		    //eksekusi peritnah sql
		    $query = $this->db->query($sql, $id_kat);
		    //cek apakah query berhasil dijalankan atau tidak
		    if($query==true){
		        echo "berhasil delete";
		    } else echo "gagal delete";
		}  

	}