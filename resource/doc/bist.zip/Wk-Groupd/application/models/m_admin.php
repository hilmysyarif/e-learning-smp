<?php 
//membuat class model baru dengan nama m_admin
class m_admin extends CI_Model{
	function __construct() {
		//call the Model constructor
		parent::__construct();
	}

	//membuat fungsi untuk cek login
	public function can_logged_in($user, $pass){
		$this->db->select('*');
		//membuat fungsi where didalam database dengan input username
		$this->db->where('username', $user);
		//$this->db->where('username', $this->input->post('username'));
		//membuat fungsi where didalam database dengan input password yang sudah dienkripsi
		$this->db->where('password',$pass);
		//$this->db->where('password', md5($this->input->post('password')));
		//$sql ="SELECT * FROM admin WHERE username=? AND password=?";
		//$query = $this->db->query($sql, $param);

		$this->db->where('level','admin');
		//eksekusi query ditabel usr
		$query = $this->db->get('user');
		//jika hasilnya adalah 1 baris
		 if ($query->num_rows() > 0) {
            $g_result = $query->row_array();
            $query->free_result();
            return $g_result;
        } else {
            return array();
        }
	}

	//update slidder
	public function update_slidder($params=""){
		$sql = "UPDATE slidder SET content = ?, url=?, img_path=? WHERE id_slidder = ?";
		$this->db->query($sql, $params);
		return true;
	}

	//menambah barang
	public function add_brg($params="") {
		$sql = "INSERT INTO barang (id_barang,nama_barang, des_barang, id_kat_barang, stok_total, disewa, stok_sisa, harga, pic_brg) VALUES (NULL, ?, ?, ?, ?, '0', ?, ?, ?)";
		//eksekusi perintah sql
		return $this->db->query($sql, $params);
	}

	//melihat user yang belum lunas
	function get_belumlunas(){
		$sql = "SELECT id_sewa , user.nama_leng AS 'username', sewa.id_user AS 'id_user', tgl_transaksi, tgl_jatuhtempo,tgl_sewa, tgl_kembali, lama, sewa.status AS 'status', harga_sewa,denda FROM sewa INNER JOIN user ON sewa.id_user=user.id_user WHERE sewa.status = 0";
		$query = $this->db->query($sql);
		//struktur kendali apakah ada data atau tidak
	    if ($query->num_rows() > 0) {
            $tresult = $query->result_array();
            $query->free_result();
            return $tresult;
        } else {
           return array();
        }
	}

	//melihat user yang belum lunas
	function get_sudahlunas(){
		$sql = "SELECT id_sewa, user.nama_leng AS 'username', sewa.id_user AS 'id_user', tgl_transaksi, tgl_jatuhtempo,tgl_sewa, tgl_kembali, lama, sewa.status AS 'status', harga_sewa,denda FROM sewa INNER JOIN user ON sewa.id_user=user.id_user WHERE sewa.status = 1";
		$query = $this->db->query($sql);
		//struktur kendali apakah ada data atau tidak
	    if ($query->num_rows() > 0) {
            $tresult = $query->result_array();
            $query->free_result();
            return $tresult;
        } else {
           return array();
        }
	}
	

	//membuat lunas tagihan 
	//its worked
	public function jadi_lunas($id_sewa) {
		$sql = "UPDATE sewa SET status = 1 WHERE id_sewa = ? ";
		$query = $this->db->query($sql, $id_sewa);
		//status id_tagihan sudah 1 = lunas
	}

	//membatalkan lunas tagihan 
	//its worked
	public function batal_lunas($id_sewa) {
		$sql = "UPDATE sewa SET status = 0 WHERE id_sewa = ? ";
		$query = $this->db->query($sql, $id_sewa);
		//status id_tagihan sudah 1 = lunas
	}

	//////////////////////guestbook/////////////////////

	//delete guest book
	public function delete_guestbook($id) {
		$sql = "DELETE FROM guestbook WHERE id_gb = ?";
		if($this->db->query($sql, $id)) { //if query is work
			return true;
		} else {
			return false;
		}
	}

	
}