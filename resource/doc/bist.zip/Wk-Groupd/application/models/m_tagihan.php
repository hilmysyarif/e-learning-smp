<?php
	class m_tagihan extends CI_Model {
		function __construct() {
			//call the Model constructor
			parent::__construct();
		}

		//fungsi delete tagihan
		function deletetagihan($id) {
			$sql = "DELETE FROM sewa WHERE id_sewa = ?";
			if($this->db->query($sql, $id)) {
				return true;
			} else {
				return false;
			}
		}

		//fungsi delete tagihan detail
		function deletetagihandetail($id) {
			$sql = "DELETE FROM sewa_item WHERE id_sewa = ?";
			if($this->db->query($sql, $id)) {
				return true;
			} else {
				return false;
			}
		}

		//fungsi melihat tagihan berdasarkan id user
		function get_tagihan_by_id_user($id_user) {
			$sql = "SELECT id_sewa, tgl_transaksi, tgl_jatuhtempo,tgl_sewa, tgl_kembali, lama, status FROM sewa WHERE id_user = ? ORDER BY tgl_sewa DESC";
			$query = $this->db->query($sql, $id_user);
			//struktur kendali apakah ada data atau tidak
		    if ($query->num_rows() > 0) {
	            $tresult = $query->result_array();
	            $query->free_result();
	            return $tresult;
	        } else {
	           return array();
	        }
		}

		//fungsi melihat tagihan berdasarkan id sewa
		function get_tagihan_by_id_sewa($id_sewa){
			$sql = "SELECT id_sewa, tgl_jatuhtempo, tgl_sewa, tgl_kembali, lama, harga_sewa, harga_hari, denda, harga_total, status FROM sewa WHERE id_sewa = ?  ORDER BY tgl_sewa DESC";
			$query = $this->db->query($sql, $id_sewa);
			//struktur kendali apakah ada data atau tidak
	        if ($query->num_rows() > 0) {
	            $tresult = $query->row_array();
	            $query->free_result();
	            return $tresult;
	        } else {
	           redirect('../403.html');
	        }
		}

		//searching barang
		function search_tagihan($keyword){
			//pencarian jika id barang sama atau nama mirip
			//menggunakan fungsi dari CI
			 //untuk perintah SELECT
	        $sql = "SELECT id_sewa, user.nama_leng AS 'id_user', tgl_transaksi, tgl_jatuhtempo,tgl_sewa, tgl_kembali, TO_DAYS(tgl_kembali) - TO_DAYS(tgl_sewa) AS 'lama', sewa.status, harga_sewa,denda FROM sewa INNER JOIN user ON user.id_user = sewa.id_user WHERE sewa.id_sewa = '$keyword' OR  user.username LIKE '%$keyword%' OR  user.nama_leng LIKE '%$keyword%'" ;
			$query = $this->db->query($sql);
			//cek data apakah tersedia
			if($query->num_rows() > 0) {
				//jika ada maka dimasukkan kedalam sebuah array
	            $g_result = $query->row_array();
	            $query->free_result();
	            return $g_result;
			} else {
				return array();
			}

		}

		//fungsi melihat detail berang berdasarkan id tagihan
		function get_det_tagihan($id_sewa){
			$sql = "SELECT barang.nama_barang, sewa_item.jumlah_brg, sewa_item.id_barang, sewa_item.subtotal,sewa_item.status  FROM sewa_item INNER JOIN barang ON sewa_item.id_barang = barang.id_barang WHERE id_sewa = ?";
			$query = $this->db->query($sql, $id_sewa);
			//struktur kendali apakah ada data atau tidak
		    if ($query->num_rows() > 0) {
	            $tresult = $query->result_array();
	            $query->free_result();
	            return $tresult;
	        } else {
	           return array();
	        }
		}

		//yang harus ddibayar dipanggil ketika customer save cart ke tagihan
		function dibayar($params){
			$sql = 'UPDATE sewa SET harga_sewa = ?, harga_total = ? * lama WHERE id_sewa = ?';
			$query = $this->db->query($sql, $params);
		}

		//trigger untuk ubah lewat batas
		function lewat_batas(){
			$sql = "UPDATE sewa SET lewat_batas = datediff(CURDATE(), tgl_jatuhtempo)"; //selisih tgl sekarang dengan tgl jatuh tempo
			$query = $this->db->query($sql);
		}

		//menampilkan lewat batas
		function get_lewat_batas($id){ //worked
			$sql = "SELECT lewat_batas FROM sewa WHERE id_sewa = ? LIMIT 0 , 1 "; //selisih tgl sekarang dengan tgl jatuh tempo
			$query = $this->db->query($sql, $id);
			//struktur kendali apakah ada data atau tidak
		    if ($query->num_rows() > 0) {
	            $tresult = $query->row_array();
	            $query->free_result();
	            return $tresult;
	        } else {
	           return array();
	        }
		}

		//trigger untuk update denda dan harga total
		//denda mulai dihitung ketika lewat batas >0
		function update_denda_hargatotal($params){ //parameter  adalah lewat hari dan id sewa
			$sql = "UPDATE sewa SET denda = 20000 * ?, harga_total = (harga_sewa * lama) + denda WHERE id_sewa = ?";
			$query = $this->db->query($sql, $params);
		}



	}