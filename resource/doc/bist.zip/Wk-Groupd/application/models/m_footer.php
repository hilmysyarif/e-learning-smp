<?php
	class m_footer extends CI_Model {
		function __construct() {
			//call the Model constructor
			parent::__construct();
		}

		function sosmed(){ //mengambil data sosial network
			$sql = "SELECT * FROM profile WHERE type='sosmed'";
			$query = $this->db->query($sql);
			//cek data apakah tersedia
			if($query->num_rows() > 0) {
				//jika ada maka dimasukkan kedalam sebuah array
	            $g_result = $query->result_array();
	            $query->free_result();
	            return $g_result;
			} else {
				return array();
			}
		}

	

		function kontak(){ //menampilkan data kontak
			$sql = "SELECT * FROM profile WHERE type='contact'";
			$query = $this->db->query($sql);
			//cek data apakah tersedia, jika ia makan akan ditampilkan 
			if($query->num_rows() > 0) {
				//jika ada maka dimasukkan kedalam sebuah array
	            $g_result = $query->result_array();
	            $query->free_result();
	            return $g_result;
			} else {
				return array();
			}
		}

		function bank(){ //menampilkan data 
			$sql = "SELECT * FROM profile WHERE type='pembayaran'";
			$query = $this->db->query($sql);
			//cek data apakah tersedia, jika ia makan akan ditampilkan 
			if($query->num_rows() > 0) {
				//jika ada maka dimasukkan kedalam sebuah array
	            $g_result = $query->result_array();
	            $query->free_result();
	            return $g_result;
			} else {
				return array();
			}
		}

		//edit sosmed
		function edit_data($params){
			$sql = "UPDATE profile SET deskripsi = ?, link = ? WHERE id_profile = ?";
			if($this->db->query($sql,$params)) {
				return true;
			} else {
				return false;
			}
		}
	}