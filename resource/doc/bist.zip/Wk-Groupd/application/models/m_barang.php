<?php
	class m_barang extends CI_Model {
		function __construct() {
			//call the Model constructor
			parent::__construct();
		}

		//pencarian barang
		function search_brg($q){
			$sql = "SELECT * FROM barang WHERE nama_barang LIKE '%$q%' OR des_barang = '%$q%' OR pic_brg = '%$q%' ORDER BY disewa  DESC ";
			//eksekusi perintah sql
			$query = $this->db->query($sql);
			//cek data apakah tersedia
			if($query->num_rows() > 0) {
				//jika ada maka dimasukkan kedalam sebuah array
	            $g_result = $query->result_array();
	            $query->free_result();
	            return $g_result;
			} else {
				return array();
			}
		}

		//menggambil semua data barang
		function count_brg() {
			$sql = "SELECT * FROM barang";
			//eksekusi perintah sql
			$query = $this->db->query($sql);
			//cek data apakah tersedia
			$result = $query->num_rows();
			return $result;
		}

		//menhitung total barang berdasarkan kategori
		function count_brg_by_kat($id_kat) {
			$sql = "SELECT * FROM barang WHERE id_kat_barang = ?";
			//eksekusi perintah sql
			$query = $this->db->query($sql, $id_kat);
			//cek data apakah tersedia
			$result = $query->num_rows();
			return $result;
		}

		function show_brg(){
			$sql = "SELECT * FROM barang ORDER BY disewa DESC ";
			//eksekusi perintah sql
			$query = $this->db->query($sql);
			//cek data apakah tersedia
			if($query->num_rows() > 0) {
				//jika ada maka dimasukkan kedalam sebuah array
	            $g_result = $query->result_array();
	            $query->free_result();
	            return $g_result;
			} else {
				return array();
			}
		}

		//menampilkan barang dengan offset dan limit
		function get_brg($limit, $offset){
			$sql = "SELECT * FROM barang ORDER BY id_barang DESC LIMIT ".$limit."  OFFSET ".$offset." ";
			//eksekusi perintah sql
			$query = $this->db->query($sql);
			//cek data apakah tersedia
			if($query->num_rows() > 0) {
				//jika ada maka dimasukkan kedalam sebuah array
	            $g_result = $query->result_array();
	            $query->free_result();
	            return $g_result;
			} else {
				return array();
			}
		}

		//menampilkan barang dengan offset dan limit berdasar id kategori
		function get_brg_by_kat($limit, $offset, $id_kat_brg){
			$sql = "SELECT * FROM barang WHERE id_kat_barang = '".$id_kat_brg."' ORDER BY id_barang DESC LIMIT ".$limit."  OFFSET ".$offset." ";
			//eksekusi perintah sql
			$query = $this->db->query($sql);
			//cek data apakah tersedia
			if($query->num_rows() > 0) {
				//jika ada maka dimasukkan kedalam sebuah array
	            $g_result = $query->result_array();
	            $query->free_result();
	            return $g_result;
			} else {
				return array();
			}
		}


		//menggambil 12 barang paling banyak disewa
		function get_12brgnew() {
			$sql = "SELECT * FROM barang ORDER BY disewa DESC LIMIT 0,12";
			//eksekusi perintah sql
			$query = $this->db->query($sql);
			//cek data apakah tersedia
			if($query->num_rows() > 0) {
				//jika ada maka dimasukkan kedalam sebuah array
	            $g_result = $query->result_array();
	            $query->free_result();
	            return $g_result;
			} else {
				return array();
			}
		}

		//searching barang
		function search_barang($keyword){
			//pencarian jika id barang sama atau nama mirip
			//menggunakan fungsi dari CI
			 //untuk perintah SELECTi
	        $query = $this->db->query(" SELECT * FROM barang WHERE id_barang LIKE '%$keyword%' OR nama_barang LIKE '%$keyword%'"); 
			//cek data apakah tersedia
			if($query->num_rows() > 0) {
				//jika ada maka dimasukkan kedalam sebuah array
	            $g_result = $query->result_array();
	            $query->free_result();
	            return $g_result;
			} else {
				return array();
			}

		}

		//mengambil barang berdasarkan id, hasil = 1
		function get_brg_by_id($id_brg) {
			//query
			$sql= "SELECT * FROM barang WHERE id_barang = ?";
			$query = $this->db->query($sql, $id_brg);
			//cek data
			 if ($query->num_rows() > 0) {
	            $g_result = $query->row_array();
	            $query->free_result();
	            return $g_result;
	        } else {
	            return array();
	        }
		} 

		//memanggil barang berdasarkan kategori
		function show_brg_by_kat($id_kat_brg) {
			//fungsi mengambil perintah select
			$this->db->select('*');
			//fungsi mengambil perintah where
			$this->db->where('id_kat_barang', $id_kat_brg);
			//eksekusi query
			$query = $this->db->get('brg');
			return $query->result_array();
		}

		//fungsi untuk update barang dengan parameter
		function upd_brg($params) {
			//query untuk update barang 
			$sql = "UPDATE barang SET nama_barang = ?,des_barang = ?,id_kat_barang=?, stok_total = ?, disewa = ?, stok_sisa = stok_total - disewa, harga = ?, pic_brg = ? WHERE id_barang = ? ";
			//eksekusi query
			$query = $this->db->query($sql, $params);
	        //cek apakah perintah sql berhasil berjalan atau tidak
	        if($query==true){
	           return true;
	        } else return false;
		} 

		//fungsi untuk menghapus barang 
		function del_brg($id_brg) {
			//perintah sql untuk hapus barang
	        $sql = "DELETE FROM barang WHERE id_barang = ? ";
	        //eksekusi untuk perintah sql
	        $query = $this->db->query($sql, $id_brg);
	        //cek apakah perintah sql berhasil dijalankan atau tidak
	        if($query==true){
	            echo "berhasil delete";
	        } else{ echo "gagal delete";}
		}

		//detail barang-barang yang disewa
		function insert_sewa($params) {
			$sql = "INSERT INTO sewa (tgl_transaksi,tgl_jatuhtempo, tgl_sewa,tgl_kembali,lama, id_user) VALUES (?,?,?,?,(TO_DAYS(tgl_kembali) - TO_DAYS(tgl_sewa)) + 1,?)";
			return $this->db->query($sql, $params);
	        $id = $this->db->insert_id();
	        echo $id;	        
	        return (isset($id)) ? $id : FALSE;
		}

		//untuk memasukan ke data sewa
		function insert_sewa_detail($params) {
			$sql = "INSERT INTO sewa_item (id_barang, jumlah_brg, subtotal, id_sewa) VALUES (?,?,?,?)";
			return $this->db->query($sql, $params);
		} 

		function get_sewa_by_usr($id) {
			$sql = "SELECT id_sewa FROM sewa WHERE id_user = ? ORDER BY tgl_transaksi DESC LIMIT 0,1"; //mengurutkan berdasarkan waktu transaksi
			$query = $this->db->query($sql, $id);
	        if ($query->num_rows() > 0) {
	            $g_result = $query->row_array();
	            $query->free_result();
	            return $g_result;
	        } else {
	            return array();
	        }
		}

		function get_jumlah($id) {
			$sql = "SELECT sewa.id_sewa, sewa.id_user, sewa_item.id_barang, jumlah, barang.harga, (harga*jumlah) AS total, SUM(harga*jumlah) AS bayar
			FROM sewa
			INNER JOIN sewa_item ON sewa.id_sewa = sewa_item.id_sewa
			INNER JOIN user ON sewa.id_user = user.id_user
			INNER JOIN barang ON sewa_item.id_barang = barang.id_barang
			WHERE sewa.id_user = ?";
			$query = $this->db->query($sql, $id);
	        if ($query->num_rows() > 0) {
	            $g_result = $query->row_array();
	            $query->free_result();
	            return $g_result;
	        } else {
	            return array();
	        }
		}

		function get_bayar($id) {
			$sql = "SELECT sewa_item.id_sewa, SUM(barang.harga*sewa_item.jumlah_brg) AS bayar FROM sewa_item
			INNER JOIN barang ON sewa_item.id_barang = barang.id_barang WHERE id_sewa = ?";
			$query = $this->db->query($sql, $id);
	        if ($query->num_rows() > 0) {
	            $g_result = $query->row_array();
	            $query->free_result();
	            return $g_result;
	        } else {
	            return array();
	        }
		}

		//stok barang sekarang
		function stok_sekarang($params) {
			$sql = "UPDATE barang SET disewa = disewa + ? ,stok_sisa = stok_sisa - ? WHERE id_barang = ?";
			$query = $this->db->query($sql, $params);
			return $query;
		}

		//trigger merubah stok sisa secara otomatis
		function cek_sisa() {
			$sql = "UPDATE barang SET stok_sisa = stok_total - disewa";
			$query = $this->db->query($sql);
		}

		//merubah status barang di tabel sewa
		function ubah_status_brg($params){
			$sql = "UPDATE sewa_item SET status = ? WHERE sewa_item.id_sewa = ? AND sewa_item.id_barang = ?";
			$query = $this->db->query($sql, $params);
		}

		//menambah barang yang disewa
		function tambah_sewa_brg($params){
			$sql = "UPDATE barang SET disewa = disewa + ? WHERE id_barang = ?"; 
			$query = $this->db->query($sql, $params);
		}

		//mengurangi barang yang disewa
		function kurang_sewa_brg($params){
			$sql = "UPDATE barang SET disewa = disewa - ? WHERE id_barang = ?"; 
			$query = $this->db->query($sql, $params);
		}

		////////////////////////////////KATEGORI/////////////////////////////////////////////
		function delkatbrg($id){
			$sql = "DELETE FROM kat_barang WHERE id_kat_barang = ? ";
			$query = $this->db->query($sql, $id);
			if($this->db->query($sql, $id)) {
				return true;
			} else {
				return false;
			}
		}

	} //end of class