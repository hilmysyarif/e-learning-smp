<?php
class m_post extends CI_Model {
	function __construct() {
			//call the Model constructor
		parent::__construct();

	}
		//////////////////////////////////////////////////////////////////////////////////////////////////////////
		////////////////////// FOR PUBLIC ///////////////////////////////////////////////////////////////////////

		//count post
		function count_post(){
			$sql = "SELECT * FROM berita";
			//eksekusi perintah sql
			$query = $this->db->query($sql);
			//cek data apakah tersedia
			$result = $query->num_rows();
			return $result;
		}

		//mengambl semua data post
		function get_post($limit, $offset) {
			$sql = "SELECT * FROM berita WHERE status = 1 ORDER BY tgl_update DESC LIMIT ".$limit." OFFSET ".$offset." ";
			//eksekusi perintah sql
			$query = $this->db->query($sql);
			//cek data apakah tersedia
			if($query->num_rows() > 0) {
				//jika ada maka dimasukkan kedalam sebuah array
	            $g_result = $query->result_array();
	            $query->free_result();
	            return $g_result;
			} else {
				return array();
			}
		}

		//melihat post berdasarkan id
		function get_post_by_id($id) {
			$sql = "SELECT * FROM berita WHERE id_berita = ?";
			//eksekusi perintah sql
			$query = $this->db->query($sql, $id);
			//cek data apakah tersedia
			if($query->num_rows() > 0) {
				//jika ada maka dimasukkan kedalam sebuah array
	            $g_result = $query->row_array();
	            $query->free_result();
	            return $g_result;
			} else {
				return array();
			}
		}


		//memanggil semua kategori post
		function get_kat_post() {
			//memanggil kategori dari database
			$query = $this->db->query('SELECT * FROM kat_berita ORDER BY id_kat_berita DESC');
			//hasil query menjadi result array
			return $query->result_array();
		}

		//melihat post berdasarkan kategori
		//memanggil barang berdasarkan kategori
		function get_post_by_kat($id_kat_post) {
			//fungsi mengambil perintah select
			$this->db->select('*');
			//fungsi mengambil perintah where
			$this->db->where('id_kat_post', $id_kat_post);
			//eksekusi query
			$query = $this->db->get('post'); //tabel yang digunakan
			return $query->result_array();
		}

		//////////////////////////////////////////////////////////////////////////////////////////////////////////
		////////////////////// ADMIN ONLY ///////////////////////////////////////////////////////////////////////
		
		//perintah untuk UPDATE berita
		function upd_post($params){
			//query untuk update barang 
			$sql = "UPDATE berita SET judul_berita = ?, tgl_update = CURDATE(), berita = ?, id_kat_post = ? WHERE id_berita = ? ";
			//eksekusi query
			$query = $this->db->query($sql, $params);
	        //cek apakah perintah sql berhasil berjalan atau tidak
	        if($query==true){
	           return true;
	        } else { 
	        	return false;
	        }
		}

		//perintah untuk hapus post
		function del_post($id_post) {
			$sql = "DELETE FROM berita WHERE id_berita = ?";
			$this->db->query($sql, $id_post);
			//redirect
		}

		//tambah post
		function add_post($params){
			$sql = "INSERT INTO berita(id_berita, judul_berita, tgl_buat, tgl_update, berita, id_user, id_kat_post, status) VALUES(NULL, ?, CURDATE(), CURDATE(), ?, ? ,?, ?)";
			$this->db->query($sql, $params);
			//redirect
		}

		//tambah post
		function edit_post($params){
			$sql = "UPDATE berita SET judul_berita = ?, tgl_update = CURDATE(), berita = ?, id_user = ?, id_kat_post = ?, status = ? WHERE id_berita = ?";
			$this->db->query($sql, $params);
			//redirect
		}

		//list post draft
		function get_draft_post(){
			$sql = "SELECT * FROM berita WHERE status = 0 ORDER BY tgl_update DESC";
			//eksekusi perintah sql
			$query = $this->db->query($sql);
			//cek data apakah tersedia
			if($query->num_rows() > 0) {
				//jika ada maka dimasukkan kedalam sebuah array
	            $g_result = $query->result_array();
	            $query->free_result();
	            return $g_result;
			} else {
				return array();
			}
		}

		//list post aktif
		function get_active_post(){
			$sql = "SELECT * FROM berita WHERE status = 1 ORDER BY tgl_update DESC";
			//eksekusi perintah sql
			$query = $this->db->query($sql);
			//cek data apakah tersedia
			if($query->num_rows() > 0) {
				//jika ada maka dimasukkan kedalam sebuah array
	            $g_result = $query->result_array();
	            $query->free_result();
	            return $g_result;
			} else {
				return array();
			}
		}

		//memanggil semua slidder
		function get_slidder() {
			$sql = "SELECT * FROM slidder LIMIT 0, 4";
			$query = $this->db->query($sql);
			//cek data apakah tersedia
			if($query->num_rows() > 0) {
				//jika ada maka dimasukkan kedalam sebuah array
	            $g_result = $query->result_array();
	            $query->free_result();
	            return $g_result;
			} else {
				return array();
			}
		}

		//mengirim guestbook
		function guestbook($params) {
			$sql = "INSERT INTO guestbook(nama, email, pesan, tanggal, status ) VALUES (?,?,?, NOW(), 0)";
			$query = $this->db->query($sql, $params);
		}

		//membaca guestbook
		function get_guestbook($status){
			$sql = "SELECT * FROM guestbook WHERE status  = ?";
			$query = $this->db->query($sql, $status);
			//cek data apakah tersedia
			if($query->num_rows() > 0) {
				//jika ada maka dimasukkan kedalam sebuah array
	            $g_result = $query->result_array();
	            $query->free_result();
	            return $g_result;
			} else {
				return array();
			}
		}


		/////////////////////////////////////////////////////////////////////
		/////////////////// KATEGORI BERITA /////////////////////////////////
		/////////////////////////////////////////////////////////////////////

		//menambahkan kategori
		function add_category($nama) {
			$sql ="INSERT INTO kat_berita(kat_berita) VALUES( ? )";
			if($this->db->query($sql, $nama)) {
				return true;
			} else {
				return false;
			}
		}

		//edit kategori berita
		function edit_category($params) {
			$sql ="UPDATE kat_berita SET kat_berita = ? WHERE id_kat_berita = ?";
			if($this->db->query($sql, $params)) {
				return true;
			} else {
				return false;
			}
		}

		//delete kategori berita
		function del_kat_berita($id) {
			$sql = "DELETE FROM kat_berita WHERE id_kat_berita = ?";
			if($this->db->query($sql, $id)) {
				return true;
			} else {
				echo "<h3>Ada berita yang menggunakan kategori ini</h3>";
			}
		}
		
}