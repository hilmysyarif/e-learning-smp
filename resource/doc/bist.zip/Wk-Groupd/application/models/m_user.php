<?php
	class m_user extends CI_Model {
		function __construct() {
			//call the Model constructor
			parent::__construct();
		}

		//manambah user
		function add_user(){
			$data = array (
				'username' => $this->input->post('username'),
				'password' => md5($this->input->post('password1')),
				'email' => $this->input->post('email'),
				'nama_leng' => $this->input->post('nama'),
				'alamat_leng' => $this->input->post('alamat'),
				'kota' => $this->input->post('kota'),
				'id_bank' => $this->input->post('bank'),
				'no_rek' => $this->input->post('rekening'),
				'status'=>'aktif',
				'level'=> 'pelanggan');
			//insert data ke tabel usr
			$query = $this->db->insert('user', $data);
			//cek apakah query sudah berjalan normal atau tidak
	        if ($query){
	            return true;

	        } else {
	            return false;
	        }
		}

		//hapus user
		function del_user($id) {
			$sql = "DELETE FROM user WHERE id_user = ?";
			if($this->db->query($sql, $id)) {
				return true;
			} else {
				return false;
			}
		}

		//membuat sebuah fungsi baru untuk cek login atau tidak
	    public function can_log_in($username, $password){
	        //membuat perintah sql dengan menggunakan fungsi bawaan ci
	        //untuk perintah SELECT
	        $this->db->select('*');
	        //untuk perintah WHERE
	        $this->db->where('username', $username);
	        //untuk perintah WHERE
	        $this->db->where('password', $password);
	        //eksekusi peritah sql
	        $query = $this->db->get('user');
	        //struktur kendali untuk cek apakah data ada atau tidak
	        if($query->num_rows() > 0){
	            //memasukkan hasil eksekusi query kedalam row_array
	            return $query->row_array();
	        }
	    }


		//fungsi untuk memanggil data pelanggan
    	public function get_user(){
	        //perintah sql untuk memanggil data pelanggan
	        $sql = 'SELECT * FROM user';
	        //eksekusi perintah sql
	        $query = $this->db->query($sql);
	        //struktur kendali untuk cek apakah data ada atau tida
	        if ($query->num_rows() > 0) {
	            //jika ada maka dimasukkan kedalam sebuah array
	            $g_result = $query->result_array();
	            $query->free_result();
	            return $g_result;
	        } else {
	            return array();
	        }
	    }

	    //lihat user berdasarkan status
	    function get_user_status($status){
	    	//perintah select
	    	$sql = "SELECT * FROM user WHERE status = ? AND level != 'admin'";
	    	//eksekusi perintah sql
	        $query = $this->db->query($sql, $status);
	        //struktur kendali untuk cek apakah data ada atau tida
	        if ($query->num_rows() > 0) {
	            //jika ada maka dimasukkan kedalam sebuah array
	            $g_result = $query->result_array();
	            $query->free_result();
	            return $g_result;
	        } else {
	            return array();
	        }
	    }

	    //lihat user berdasarkan status
	    function get_admin_status($status){
	    	//perintah select
	    	$sql = "SELECT * FROM user WHERE status = ? AND level = 'admin' AND id_user != 2";
	    	//eksekusi perintah sql
	        $query = $this->db->query($sql, $status);
	        //struktur kendali untuk cek apakah data ada atau tida
	        if ($query->num_rows() > 0) {
	            //jika ada maka dimasukkan kedalam sebuah array
	            $g_result = $query->result_array();
	            $query->free_result();
	            return $g_result;
	        } else {
	            return array();
	        }
	    }

	    //fungsi untuk memanggil semua data pelanggan
	    public function get_det_user($id_user){
	        //perintah sql untuk memanggil semua data pelanggan berdasarkan id_pelanggan
	        $sql = 'SELECT * FROM user WHERE id_user = ?';
	        //eksekusi perintah sql untuk memanggil data pelanggan
	        $query = $this->db->query($sql, $id_user);
	        //struktur kendali untuk cek apakah data ada atau tida
	        if ($query->num_rows() > 0) {
	            $result = $query->row_array();
	            $query->free_result();
	            return $result;
	        } else {
	            return array();
	        }
	    }

	    //fungsi untuk mengedit data pelanggan
	    public function edit_usr($params){
	    	$sql = "UPDATE user SET email = ?, nama_leng = ?, alamat_leng = ?, kota = ?, id_bank = ?, no_rek = ? WHERE id_user = ?";
			//eksekusi perintah sql
        	$this->db->query($sql, $params);
        	return true;
		}

		//ubah status user
		function change_status($params){
			$sql = "UPDATE user SET status = ? WHERE id_user = ?";
			//eksekusi perintah sql
        	$this->db->query($sql, $params);
        	return true;
		}	   

		//ubah status admin
		function change_admin($params){
			$sql = "UPDATE user SET status = ? WHERE id_user = ?";
			//eksekusi perintah sql
        	$this->db->query($sql, $params);
        	return true;
		}	    

		//menambah admin baru
		function add_admin($params) {
			$sql = "INSERT INTO user(username, password,email, nama_leng, status, level, id_bank) VALUES(?,?,?,?,'aktif','admin',1) ";
			$this->db->query($sql, $params);
        	return true;
		}

		//update data admin
		function edit_admin($params) {
			$sql = "UPDATE user SET username = ?, password = ?, email = ?, nama_leng = ? WHERE id_user = ?";
			//eksekusi perintah sql
        	$this->db->query($sql, $params);
        	return true;
		}

		//delete admin
		function del_admin($id) {
			$sql = "DELETE FROM user WHERE id_user = ?";
			//eksekusi perintah sql
        	if($this->db->query($sql, $id)) {
        		return true;
        	} else {
        		return false;
        	}
        	
        	
		}
 

}
